﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.EntityClient;
using RGEDomain;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System.IO;
using System.Transactions;
using System.Globalization;
using RGELog;
using System.Data.Entity.Validation;
using System.Reflection;
using System.Data.Entity.Infrastructure;

namespace RGEDal
{
    public class DLInventory
    {

        string strPCSNo = "";

        #region Methods

        #region Inventory
        #region FetchCompartmentData
        /// <summary>
        /// Fetching the compartment data with hardcoded parameters (for testing purpose)
        /// </summary>
        /// <returns></returns>
        public List<ClsCompartment> FetchCompartmentData()
        {
            List<ClsCompartment> lstCompartment = new List<ClsCompartment>();
            //string imgURL = ConfigurationSettings.AppSettings["ImageURL"];

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Inv_FetchCompartmentDetails("PMA06", "TEE", Convert.ToDateTime("1-Aug-2015"), 180);
                foreach (var s in compData)
                {
                    ClsCompartment obj = new ClsCompartment();
                    //obj.COMPNO = s.CompNo;
                    //obj.CompSlno = s.Comp_Slno;
                    //obj.Estate = s.Estate;
                    //obj.Sector = s.Sector;
                    //obj.SpeciesID = s.SpeciesID;
                    //obj.Tot_HA = Convert.ToDecimal(s.Tot_HA);
                    //obj.CompImage = s.CompartmentImage;
                    lstCompartment.Add(obj);
                }

            }
            return lstCompartment;
        }
        #endregion FetchCompartmentData

        #region FetchCompDataByInvType
        /// <summary>
        /// Fetching the compartment data by passing the inventoryType,sector and inventoryDate
        /// </summary>
        /// <param name="inventoryType"></param>
        /// <param name="sector"></param>
        /// <param name="inventoryDate"></param>
        /// <returns></returns>
        public List<ClsCompartment> FetchCompDataByInvType(string inventoryType, string sector, DateTime inventoryDate)
        {
            // Log.Writelog(" In the  FetchCompDataByInvType of DL Layer ");

            //InsertLogTable("Writing log from FetchCompDataByInvType DAL" + DateTime.Now.ToString());
            List<ClsCompartment> lstCompartment = new List<ClsCompartment>();
            // string imgURL = ConfigurationSettings.AppSettings["ImageURL"];
            try
            {

                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    //Modified by Jemmy for age validation on 5 June 2018
                    int age = 1000;
                    try
                    {
                        age = int.Parse(inventoryType.ToUpper().Replace("PMA", "").Replace("P", ""));
                    }
                    catch { }

                    //switch (inventoryType.ToUpper())
                    //{
                    //    case "PMA06":
                    //        age = 6;
                    //        break;
                    //    case "PMA18":
                    //        age = 18;
                    //        break;
                    //    case "PMA30":
                    //        age = 30;
                    //        break;
                    //    case "PMA42":
                    //        age = 42;
                    //        break;
                    //    case "PMA54":
                    //        age = 54;
                    //        break;
                    //    case "PMA66":
                    //        age = 66;
                    //        break;
                    //    case "PMA78":
                    //        age = 78;
                    //        break;
                    //}

                    //     Log.Writelog(" Invoking the stored procedure");
                    //   Log.Writelog(" ctx.SP_Inv_FetchCompartmentDetails( '" + inventoryType + "' , '" + sector + "' , '" + inventoryDate + "' , '"+age + "'");

                    var compData = ctx.SP_Inv_FetchCompartmentDetails(inventoryType, sector, inventoryDate, age);
                    foreach (var s in compData)
                    {
                        ClsCompartment obj = new ClsCompartment();
                        obj.COMPNO = s.COMPNO;
                        obj.CompSlno = s.Comp_Slno.ToString();
                        obj.Estate = s.ESTATE;
                        obj.Sector = s.SECTOR;
                        obj.SpeciesID = s.SPECIESID;
                        obj.Tot_HA = s.TOT_HA.ToString();
                        obj.CompImage = s.CompImage;
                        obj.FeatID = s.FEATID;

                        obj.TreeMapHistories = FetchTreeMapData(s.FEATID);

                        lstCompartment.Add(obj);
                    }

                    // Log.Writelog("Total number of rows retrieved  --- " + lstCompartment.Count().ToString());

                }
            }
            catch (Exception e)
            {
                // InsertLogTable("Writing log from FetchCompDataByInvType CATCH DAL" + DateTime.Now.ToString());
                Log.Writelog(e.Message, "INVENTORY");
                Log.Writelog(e.InnerException.ToString(), "INVENTORY");
            }

            return lstCompartment;

        }
        #endregion FetchCompDataByInvType

        #region FetchTreeMapData
        /// <summary>
        /// Fetching the tree map data for each compartment
        /// </summary>
        /// <returns></returns>
        public List<TreeMapHeader> FetchTreeMapData(string featID)
        {
            var lstTreeMap = new List<TreeMapHeader>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                var treeMapData = ctx.SP_Inv_FetchTreeMap(featID);
                foreach (var s in treeMapData)
                {
                    TreeMapHeader header = new TreeMapHeader()
                    {
                        PlotNo = s.PlotSerialNo,
                        StartFrom = s.StartFrom.GetValueOrDefault(),
                        AverageBRI = s.AverageBRI.HasValue ? s.AverageBRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty,
                        AverageIRI = s.AverageIRI.HasValue ? s.AverageIRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty,
                        InvType = s.InventoryType,
                        Flooding = s.Flooding,
                        MaintenanceStatus = s.Maintainence_Status,
                        SoilSampleCollected = s.SoilSampleCollected,
                        Details = new List<TreeMapDetail>()
                    };

                    var spacingData = ctx.SP_Inv_FetchTreeMapPlotSpacing(s.Survey_Slno);
                    int idx = 0;
                    foreach (var spacing in spacingData)
                    {
                        if (idx == 0)
                        {
                            header.BRI1 = spacing.BRI.HasValue ? spacing.BRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            header.BRITrees1 = spacing.BRITREES;
                            header.IRI1 = spacing.IRI.HasValue ? spacing.IRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            header.IRITrees1 = spacing.IRITREES;
                            header.SpacingRemarks1 = spacing.TREEREMARKS;
                        }
                        else if (idx == 1)
                        {
                            header.BRI2 = spacing.BRI.HasValue ? spacing.BRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            header.BRITrees2 = spacing.BRITREES;
                            header.IRI2 = spacing.IRI.HasValue ? spacing.IRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            header.IRITrees2 = spacing.IRITREES;
                            header.SpacingRemarks2 = spacing.TREEREMARKS;
                        }
                        else if (idx == 2)
                        {
                            header.BRI3 = spacing.BRI.HasValue ? spacing.BRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            header.BRITrees3 = spacing.BRITREES;
                            header.IRI3 = spacing.IRI.HasValue ? spacing.IRI.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            header.IRITrees3 = spacing.IRITREES;
                            header.SpacingRemarks3 = spacing.TREEREMARKS;
                            break;
                        }
                        idx++;
                    }

                    var plotDinstanceData = ctx.SP_Inv_FetchTreeMapPlotCenterDistance(s.Survey_Slno);
                    idx = 0;
                    foreach (var plotDistance in plotDinstanceData)
                    {
                        if (idx == 0)
                        {
                            header.PcdTreeNumber1 = plotDistance.TreeNo.GetValueOrDefault().ToString();
                            header.PcdDistance1 = plotDistance.Distance.HasValue ? plotDistance.Distance.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                        }
                        else if (idx == 1)
                        {
                            header.PcdTreeNumber2 = plotDistance.TreeNo.GetValueOrDefault().ToString();
                            header.PcdDistance2 = plotDistance.Distance.HasValue ? plotDistance.Distance.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                        }
                        else if (idx == 2)
                        {
                            header.PcdTreeNumber3 = plotDistance.TreeNo.GetValueOrDefault().ToString();
                            header.PcdDistance3 = plotDistance.Distance.HasValue ? plotDistance.Distance.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                        }
                        else if (idx == 3)
                        {
                            header.PcdTreeNumber4 = plotDistance.TreeNo.GetValueOrDefault().ToString();
                            header.PcdDistance4 = plotDistance.Distance.HasValue ? plotDistance.Distance.GetValueOrDefault().ToString("0.00").Replace(".00", String.Empty) : string.Empty;
                            break;
                        }
                        idx++;
                    }

                    var detail = ctx.SP_Inv_FetchTreeMapDetails(s.TreeMap_Slno);
                    foreach (var d in detail)
                    {
                        var exists = (from c in header.Details
                                      where c.TreeNumber == d.TreeNumber
                                      select c).Any();
                        if (!exists)
                        {
                            TreeMapDetail item = new TreeMapDetail()
                            {
                                Top = d.TopPosition,
                                Left = d.LeftPosition,
                                TreeNumber = d.TreeNumber.GetValueOrDefault(),
                                DamageDetails = new List<TreeMapDamageDetail>()
                            };
                            var damageDetail = ctx.SP_Inv_FetchTreeMapDamageDetails(featID, s.PlotSerialNo, d.TreeNumber.GetValueOrDefault());
                            foreach (var i in damageDetail)
                            {
                                TreeMapDamageDetail damage = new TreeMapDamageDetail()
                                {
                                    InventoryType = i.Inventory_Type,
                                    Damages = i.PropertyList.Split(',').ToList()
                                };
                                item.DamageDetails.Add(damage);
                            }
                            header.Details.Add(item);
                        }
                    }
                    lstTreeMap.Add(header);
                }
            }
            return lstTreeMap;
        }
        #endregion FetchTreeMapData

        #region Insert TreeMap
        public InventoryResponseClass InsertOrUpdateInventoryTreeMap(List<TreeMapHeader> headers, string compartmentNo, string featID)
        {
            InventoryResponseClass objInvResponse = new InventoryResponseClass();
            InventoryResponseMessage objInvRespMessage = new InventoryResponseMessage();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                Log.Writelog("In data layer of  InsertOrUpdateInventoryTreeMap ", "INVENTORY");

                //Transaction
                using (TransactionScope ts = new TransactionScope())
                {
                    bool success = false;
                    try
                    {
                        foreach (TreeMapHeader header in headers)
                        {
                            var estDate = (from item in ctx.COMPREGs
                                           where item.FEATID == featID
                                           select item.EST_DATE).FirstOrDefault();

                            var treeMap = (from item in ctx.T_INV_TREEMAP_HEADER
                                           where item.FeatID == featID && item.EstDate == estDate
                                           && item.PlotNo == header.PlotNo && item.InventoryType == header.InvType
                                           select item).FirstOrDefault();
                            if (treeMap == null)
                            {
                                T_INV_TREEMAP_HEADER obj = new T_INV_TREEMAP_HEADER();
                                obj.EstDate = estDate.GetValueOrDefault();
                                obj.FeatID = featID;
                                obj.PlotNo = header.PlotNo;
                                obj.InventoryType = header.InvType;
                                obj.StartFrom = header.StartFrom;
                                ctx.T_INV_TREEMAP_HEADER.Add(obj);
                                ctx.SaveChanges();
                            }

                            treeMap = (from item in ctx.T_INV_TREEMAP_HEADER
                                       where item.FeatID == featID && item.EstDate == estDate
                                       && item.PlotNo == header.PlotNo && item.InventoryType == header.InvType
                                       select item).FirstOrDefault();

                            if (treeMap != null)
                            {
                                var details = (from item in ctx.T_INV_TREEMAP_DETAIL
                                               where item.TreeMap_Slno == treeMap.TreeMap_Slno
                                               select item).ToList();
                                foreach (var item in details)
                                {
                                    ctx.T_INV_TREEMAP_DETAIL.Remove(item);
                                    ctx.SaveChanges();
                                }

                                foreach (var item in header.Details)
                                {
                                    T_INV_TREEMAP_DETAIL obj = new T_INV_TREEMAP_DETAIL();
                                    obj.TreeMap_Slno = treeMap.TreeMap_Slno;
                                    obj.TopPosition = item.Top;
                                    obj.LeftPosition = item.Left;
                                    obj.TreeNumber = item.TreeNumber;
                                    ctx.T_INV_TREEMAP_DETAIL.Add(obj);
                                    ctx.SaveChanges();
                                }
                            }
                        }
                        success = true;
                    }
                    catch (Exception ex)
                    {
                        success = false;
                        Log.Writelog(ex.Message, "INVENTORY");
                        Log.Writelog(ex.InnerException.ToString(), "INVENTORY");
                    }
                    if (success)
                    {
                        ts.Complete();
                        objInvRespMessage.CompartmentNo = compartmentNo;
                        objInvRespMessage.Status = "Success";
                        objInvRespMessage.InvType = "";
                        objInvRespMessage.FeatID = featID;
                        objInvRespMessage.CompSlNo = "";
                        objInvRespMessage.ErrorMessage = "";
                        objInvResponse.ResponseMessage = objInvRespMessage;
                    }
                    else
                    {
                        Log.Writelog("The Transaction could not be completed", "INVENTORY");
                        objInvRespMessage.CompartmentNo = compartmentNo;
                        objInvRespMessage.Status = "Error";
                        objInvRespMessage.InvType = "";
                        objInvRespMessage.FeatID = featID;
                        objInvRespMessage.CompSlNo = "";
                        objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                        objInvResponse.ResponseMessage = objInvRespMessage;
                    }
                }
            }
            return objInvResponse;
        }
        #endregion

        //Smrithy Added
        #region GetInventoryReferenceData
        /// <summary>
        /// GetInventoryReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsInvTeam> GetInventoryReferenceData(string sector)
        {
            List<clsInvTeam> lstTeamDet = new List<clsInvTeam>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Inv_GetInventoryReferenceData_v2(sector);
                foreach (var s in compData)
                {
                    clsInvTeam objTeamDet = new clsInvTeam();
                    objTeamDet.TEAMCODE = s.TEAM_CODE;
                    objTeamDet.TEAMNAME = s.TEAM_NAME;
                    lstTeamDet.Add(objTeamDet);
                }

            }
            return lstTeamDet;
        }
        #endregion GetInventoryReferenceData


        #region GetSectorData
        /// <summary>
        /// GetSectorData
        /// </summary>
        /// <returns></returns>
        public List<clsSector> GetSectorData()
        {
            List<clsSector> listOfSector = new List<clsSector>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var sectorData = ctx.SP_GetSectorData();
                foreach (var s in sectorData)
                {
                    clsSector objOfSector = new clsSector();
                    objOfSector.Sector = s.SECTOR;
                    objOfSector.MAN_ID = s.MAN_ID;
                    listOfSector.Add(objOfSector);
                }

            }
            return listOfSector;
        }
        #endregion GetSectorData

        #region GetSectorData
        /// <summary>
        /// GetSectorData
        /// </summary>
        /// <returns></returns>
        public List<clsUserSector> GetUserSectorList(string AppName)
        {
            List<clsUserSector> listOfSector = new List<clsUserSector>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var sectorData = ctx.SP_GetUserSectorList(AppName);
                foreach (var s in sectorData)
                {
                    clsUserSector objOfSector = new clsUserSector();
                    objOfSector.Sector = s.SECTOR;
                    objOfSector.UserID = s.USERID;
                    listOfSector.Add(objOfSector);
                }

            }
            return listOfSector;
        }
        #endregion GetSectorData

        #region GetDamageType
        public List<clsDamageType> GetDamageType()
        {
            List<clsDamageType> listOfDamageType = new List<clsDamageType>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var damageType = ctx.SP_GetDamageType();
                foreach (var dt in damageType)
                {
                    clsDamageType objOfDamageType = new clsDamageType();
                    objOfDamageType.DamageType = dt.DAMAGE_TYPE;
                    objOfDamageType.IsDead = dt.IS_DEAD;
                    objOfDamageType.PMA06 = dt.PMA06;
                    listOfDamageType.Add(objOfDamageType);
                }

            }
            return listOfDamageType;
        }
        #endregion GetDamageTypeData

        #region GetDBHType
        public List<clsDBHType> GetDBHType()
        {
            List<clsDBHType> listOfDBHType = new List<clsDBHType>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var damageType = ctx.SP_INV_GETDBHMASTER();
                foreach (var dt in damageType)
                {
                    clsDBHType objOfDBHType = new clsDBHType();
                    objOfDBHType.Sector = dt.SECTOR;
                    objOfDBHType.InventoryType = dt.INVENTORYTYPE;
                    objOfDBHType.MINHeight = dt.MINHeight;
                    objOfDBHType.MAXHeight = dt.MAXHeight;
                    objOfDBHType.MINDBH = dt.MINDBH;
                    objOfDBHType.MAXDBH = dt.MAXDBH;
                    listOfDBHType.Add(objOfDBHType);
                }

            }
            return listOfDBHType;
        }
        #endregion GetDBHType

        #region GetInventoryTypes
        public List<clsInventoryType> GetInventoryTypes()
        {
            List<clsInventoryType> lstInvTypes = new List<clsInventoryType>();
            List<string> excludedTypes = new List<string>() { "PHI", "MRI", "PH3", "OTH" };

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                lstInvTypes = (from invType in ctx.INV_TYPE_MAS
                               where !excludedTypes.Contains(invType.INV_TYPE)
                               select new clsInventoryType
                               {
                                   InventoryType = invType.INV_TYPE,
                                   AppGroup = invType.APP_GROUP
                               }).ToList();
            }

            return lstInvTypes;
        }
        #endregion GetInventoryTypes

        #region InsertInventoryDetails
        /// <summary>
        /// InsertInventoryDetails
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstPlotSurvey"></param>
        /// <param name="strSave"></param>
        /// <returns></returns>
        /// 
        public int InsertInventoryCompartment(clsComparmentDet objCompartment)
        {
            int compSlno = 0;
            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                Log.Writelog("in data layer of  InsertInventoryCompartment ", "INVENTORY");

                //Transaction
                using (TransactionScope ts = new TransactionScope())
                {
                    bool success = false;
                    try
                    {
                        var varsurveynumber = ctx.SP_Inv_FetchSurveyNumber(objCompartment.FeatID);
                        string strSurveyNoForComp = string.Empty;
                        foreach (var s in varsurveynumber)
                        {

                            strSurveyNoForComp = s.SURVEYNUMBER;
                        }

                        // Log.Writelog("Suvey number is---" + strSurveyNoForComp);
                        // Insert to T_inv_compartment

                        T_INV_COMPARTMENT compObj = new T_INV_COMPARTMENT();
                        compObj.COMPNO = objCompartment.COMPNO;
                        compObj.FeatID = objCompartment.FeatID;
                        compObj.SURVEY_NO = strSurveyNoForComp;
                        compObj.Sector = "0";
                        compObj.Estate = "0";
                        compObj.CRT_DATE = DateTime.Now;
                        ctx.T_INV_COMPARTMENT.Add(compObj);
                        ctx.SaveChanges();
                        success = true;

                        Log.Writelog("T_Inv_compartment table is inserted with feature id - " + objCompartment.FeatID, "INVENTORY");

                        var slno = ctx.T_INV_COMPARTMENT.Max(x => x.Comp_Slno);
                        compSlno = Convert.ToInt32(slno);
                    }
                    catch (Exception ex)
                    {
                        success = false;
                        Log.Writelog(ex.Message, "INVENTORY");
                        Log.Writelog(ex.InnerException.ToString(), "INVENTORY");
                    }
                    if (success)
                    {
                        ts.Complete();

                    }
                    else
                    {
                        Log.Writelog("The Transaction could not be completed", "INVENTORY");

                    }
                }

            }
            return compSlno;
        }

        public bool ValidateDuplicateSurvey(string featID, string validateCompno, string validateInvType)
        {
            //validate if duplicate survey is there
            //11-oct-2015
            int i = 0;
            bool varIsDuplicate = true;
            // validateCompno = "002";
            //validateInvType = "P18";
            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                // Uma - Jan - 06 -2015
                // The feat id is passed in argument 
                Log.Writelog("SP_ValidateDuplicateSurvey(" + featID + " , " + validateCompno + " , " + validateInvType, "INVENTORY");
                var countofrows = ctx.SP_ValidateDuplicateSurvey(featID, validateCompno, validateInvType);
                foreach (var s in countofrows)
                {
                    i = s.Column1.Value;
                    if (i == 0)
                    {
                        varIsDuplicate = false;
                    }
                }
            }

            return varIsDuplicate;

        }

        public InventoryResponseClass SyncCompartment(CompartmentDetail objCompartment)
        {
            InventoryResponseClass objInvResponse = new InventoryResponseClass();
            InventoryResponseMessage objInvRespMessage = new InventoryResponseMessage();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                ((IObjectContextAdapter)ctx).ObjectContext.CommandTimeout = 0;
                using (TransactionScope ts = CreateTransactionScope(TimeSpan.FromMinutes(60)))
                {
                    try
                    {
                        if (objCompartment.CompartmentID.GetValueOrDefault() != Guid.Empty)
                        {
                            var compartment = (from item in ctx.T_INV_COMPARTMENT
                                               where item.CompartmentID == objCompartment.CompartmentID
                                               select item).FirstOrDefault();

                            if (compartment != null)
                            {
                                ts.Complete();
                                objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                objInvRespMessage.Status = "Success";
                                objInvRespMessage.InvType = string.Empty;
                                objInvRespMessage.FeatID = objCompartment.FeatID;
                                objInvRespMessage.CompSlNo = compartment.Comp_Slno.ToString();
                                objInvRespMessage.ErrorMessage = string.Empty;
                                objInvResponse.ResponseMessage = objInvRespMessage;
                                return objInvResponse;
                            }
                        }

                        var varsurveynumber = ctx.SP_Inv_FetchSurveyNumber(objCompartment.FeatID);
                        string strSurveyNoForComp = string.Empty;
                        foreach (var s in varsurveynumber)
                        {
                            strSurveyNoForComp = s.SURVEYNUMBER;
                        }

                        T_INV_COMPARTMENT compObj = new T_INV_COMPARTMENT();
                        compObj.COMPNO = objCompartment.CompNo;
                        compObj.FeatID = objCompartment.FeatID;
                        compObj.SURVEY_NO = strSurveyNoForComp;
                        compObj.Sector = "0";
                        compObj.Estate = "0";
                        compObj.CRT_DATE = DateTime.Now;
                        compObj.CompartmentID = objCompartment.CompartmentID;
                        ctx.T_INV_COMPARTMENT.Add(compObj);
                        ctx.SaveChanges();

                        objCompartment.CompSlno = (from item in ctx.T_INV_COMPARTMENT
                                                   where item.CompartmentID == objCompartment.CompartmentID
                                                   select item.Comp_Slno).FirstOrDefault();

                        if (objCompartment.StratumDetails != null)
                        {
                            foreach (var stratum in objCompartment.StratumDetails)
                            {
                                try
                                {
                                    T_INV_STRATUM objStratum = new T_INV_STRATUM();

                                    objStratum.SurveyNo = strSurveyNoForComp;
                                    objStratum.FeatID = objCompartment.FeatID;
                                    objStratum.StratumNo = stratum.StratumNo;
                                    objStratum.StratumHA = stratum.StratumHA;
                                    if (stratum.IsBlankSpot.GetValueOrDefault())
                                        objStratum.IsBlankSpot = "T";
                                    else
                                        objStratum.IsBlankSpot = "F";
                                    objStratum.NoOfPlots = stratum.NoOfPlots;
                                    ctx.SaveChanges();
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "T_INV_STRATUM", "INVENTORY");
                                        }
                                    }
                                    objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = string.Empty;
                                    objInvRespMessage.FeatID = objCompartment.FeatID;
                                    objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                    return objInvResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                               "T_INV_STRATUM", "INVENTORY");
                                    throw ex;
                                }
                            }
                        }

                        if (objCompartment.SurveyDetails != null)
                        {
                            foreach (var survey in objCompartment.SurveyDetails)
                            {
                                try
                                {
                                    T_INV_SURVEYDETAILS objSurveyList = new T_INV_SURVEYDETAILS();

                                    objSurveyList.Survey_Date = survey.SurveyDate;
                                    objSurveyList.Comp_slno = objCompartment.CompSlno;
                                    objSurveyList.Inventory_Type = survey.InventoryType;
                                    objSurveyList.COMPLETE = survey.Complete;
                                    objSurveyList.TEAM_CODE = survey.TeamCode;
                                    objSurveyList.Survey_LineNo = survey.SurveyLineNo;
                                    objSurveyList.AzimuthPlotLine = survey.AzimuthPlotLine;
                                    objSurveyList.Remarks = survey.Remarks;
                                    objSurveyList.Maintainence_Status = survey.MaintenanceStatus;
                                    objSurveyList.Flooding = survey.Flooding;
                                    objSurveyList.SoilSampleCollected = survey.SoilSampleCollected;
                                    objSurveyList.Name = survey.Name;
                                    objSurveyList.Keyed_in_by = "3";
                                    objSurveyList.CRT_USERID = survey.SCreatedBy;
                                    objSurveyList.CRT_DATE = survey.SCreatedDate;
                                    objSurveyList.Total_LiveYellow = survey.TotalLiveYellow;
                                    objSurveyList.Total_Dead = survey.TotalDead;
                                    objSurveyList.Total_Healthy = survey.TotalHealthy;
                                    objSurveyList.Error_SurveySlno = survey.ErrorSurveySlno;
                                    objSurveyList.GPS_Lat = survey.GpsLatitude;
                                    objSurveyList.GPS_Long = survey.GpsLongitude;
                                    objSurveyList.PlotSerialNo = survey.PlotSerialNo.Trim();
                                    ctx.T_INV_SURVEYDETAILS.Add(objSurveyList);

                                    ctx.SaveChanges();

                                    survey.SurveySlno = (from item in ctx.T_INV_SURVEYDETAILS
                                                         where item.Comp_slno == objCompartment.CompSlno &&
                                                         item.Inventory_Type == survey.InventoryType &&
                                                         item.PlotSerialNo == survey.PlotSerialNo.Trim()
                                                         select item.Survey_Slno).FirstOrDefault();

                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "T_INV_SURVEYDETAILS", "INVENTORY");
                                        }
                                    }
                                    objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = string.Empty;
                                    objInvRespMessage.FeatID = objCompartment.FeatID;
                                    objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                    return objInvResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                               "T_INV_SURVEYDETAILS", "INVENTORY");
                                    throw ex;
                                }

                                try
                                {
                                    if (survey.StratumNo.HasValue && survey.StratumNo >= 0)
                                    {
                                        T_INV_STRATUM_DETAILS objStratumList = new T_INV_STRATUM_DETAILS();

                                        objStratumList.StratumNo = survey.StratumNo.GetValueOrDefault();
                                        objStratumList.Survey_Slno = survey.SurveySlno;

                                        ctx.T_INV_STRATUM_DETAILS.Add(objStratumList);
                                        ctx.SaveChanges();
                                    }
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "T_INV_STRATUM_DETAILS", "INVENTORY");
                                        }
                                    }
                                    objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = string.Empty;
                                    objInvRespMessage.FeatID = objCompartment.FeatID;
                                    objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                    return objInvResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                               "T_INV_STRATUM_DETAILS", "INVENTORY");
                                    throw ex;
                                }

                                try
                                {
                                    T_INV_PLOT objPlot = new T_INV_PLOT();
                                    objPlot.PlotNo = survey.PlotNo;
                                    objPlot.Survey_Slno = survey.SurveySlno;

                                    objPlot.Plot_Radius = survey.PlotRadius;
                                    objPlot.Plotcenter_lat = survey.GpsLatitude;
                                    objPlot.Plotcenter_long = survey.GpsLongitude;

                                    if (objPlot.Plotcenter_lat > 0)
                                    {
                                        objPlot.PlotCenter_Ydirection = "N";
                                    }
                                    else
                                    {
                                        objPlot.PlotCenter_Ydirection = "S";
                                    }

                                    if (objPlot.Plotcenter_long > 0)
                                    {
                                        objPlot.PlotCenter_XDirection = "E";
                                    }
                                    else
                                    {
                                        objPlot.PlotCenter_XDirection = "W";
                                    }

                                    objPlot.Sample_Percentage = survey.SamplePercentage;
                                    objPlot.CRT_USERID = survey.PCreatedBy;
                                    objPlot.CRT_DATE = survey.PCreatedDate;

                                    ctx.T_INV_PLOT.Add(objPlot);
                                    ctx.SaveChanges();
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "T_INV_PLOT", "INVENTORY");
                                        }
                                    }
                                    objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = string.Empty;
                                    objInvRespMessage.FeatID = objCompartment.FeatID;
                                    objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                    return objInvResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                               "T_INV_PLOT", "INVENTORY");
                                    throw ex;
                                }

                                survey.PlotSlno = (from item in ctx.T_INV_PLOT
                                                   where item.Survey_Slno == survey.SurveySlno &&
                                                   item.PlotNo == survey.PlotNo
                                                   select item.Plot_Slno).FirstOrDefault();

                                if (survey.PlotSpacingDetails != null)
                                {
                                    foreach (var spacing in survey.PlotSpacingDetails)
                                    {
                                        try
                                        {
                                            T_INV_PLOTSPACING objPlotspacing = new T_INV_PLOTSPACING();
                                            objPlotspacing.Plot_Slno = survey.PlotSlno;
                                            objPlotspacing.BRI = spacing.BRI;
                                            objPlotspacing.IRI = spacing.IRI;
                                            objPlotspacing.BRITREES = spacing.BRITrees;
                                            objPlotspacing.IRITREES = spacing.IRITrees;
                                            objPlotspacing.TREEREMARKS = spacing.Remarks;
                                            ctx.T_INV_PLOTSPACING.Add(objPlotspacing);
                                            ctx.SaveChanges();
                                        }
                                        catch (DbEntityValidationException ex)
                                        {
                                            foreach (var error in ex.EntityValidationErrors)
                                            {
                                                foreach (var message in error.ValidationErrors)
                                                {
                                                    Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                        message.PropertyName + " in table " +
                                                        "T_INV_PLOTSPACING", "INVENTORY");
                                                }
                                            }
                                            objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                            objInvRespMessage.Status = "Error";
                                            objInvRespMessage.InvType = string.Empty;
                                            objInvRespMessage.FeatID = objCompartment.FeatID;
                                            objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                            objInvResponse.ResponseMessage = objInvRespMessage;
                                            return objInvResponse;
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "T_INV_PLOTSPACING", "INVENTORY");
                                            throw ex;
                                        }
                                    }
                                }

                                if (survey.WeedCoverageDetails != null)
                                {
                                    foreach (var weed in survey.WeedCoverageDetails)
                                    {
                                        try
                                        {
                                            T_INV_TREE_WEED_COVERAGE objPlotWeedCoverage = new T_INV_TREE_WEED_COVERAGE();
                                            objPlotWeedCoverage.Plot_Slno = survey.PlotSlno;
                                            objPlotWeedCoverage.COL = weed.Col;
                                            objPlotWeedCoverage.VAL = weed.Val;
                                            ctx.T_INV_TREE_WEED_COVERAGE.Add(objPlotWeedCoverage);
                                            ctx.SaveChanges();
                                        }
                                        catch (DbEntityValidationException ex)
                                        {
                                            foreach (var error in ex.EntityValidationErrors)
                                            {
                                                foreach (var message in error.ValidationErrors)
                                                {
                                                    Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                        message.PropertyName + " in table " +
                                                        "T_INV_TREE_WEED_COVERAGE", "INVENTORY");
                                                }
                                            }
                                            objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                            objInvRespMessage.Status = "Error";
                                            objInvRespMessage.InvType = string.Empty;
                                            objInvRespMessage.FeatID = objCompartment.FeatID;
                                            objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                            objInvResponse.ResponseMessage = objInvRespMessage;
                                            return objInvResponse;
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "T_INV_TREE_WEED_COVERAGE", "INVENTORY");
                                            throw ex;
                                        }
                                    }
                                }

                                if (survey.LeaveAreaIndexDetails != null)
                                {
                                    foreach (var lai in survey.LeaveAreaIndexDetails)
                                    {
                                        try
                                        {
                                            T_INV_TREE_LAI objPlotLai = new T_INV_TREE_LAI();
                                            objPlotLai.Plot_Slno = survey.PlotSlno;
                                            objPlotLai.Col = lai.Col;
                                            objPlotLai.Val = lai.Val;
                                            ctx.T_INV_TREE_LAI.Add(objPlotLai);
                                            ctx.SaveChanges();
                                        }
                                        catch (DbEntityValidationException ex)
                                        {
                                            foreach (var error in ex.EntityValidationErrors)
                                            {
                                                foreach (var message in error.ValidationErrors)
                                                {
                                                    Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                        message.PropertyName + " in table " +
                                                        "T_INV_TREE_LAI", "INVENTORY");
                                                }
                                            }
                                            objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                            objInvRespMessage.Status = "Error";
                                            objInvRespMessage.InvType = string.Empty;
                                            objInvRespMessage.FeatID = objCompartment.FeatID;
                                            objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                            objInvResponse.ResponseMessage = objInvRespMessage;
                                            return objInvResponse;
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "T_INV_TREE_LAI", "INVENTORY");
                                            throw ex;
                                        }
                                    }
                                }

                                if (survey.PlotCenterDistanceDetails != null)
                                {
                                    foreach (var distance in survey.PlotCenterDistanceDetails)
                                    {
                                        try
                                        {
                                            T_Inv_PlotCenterDistance objPlotCenterDistance = new T_Inv_PlotCenterDistance();
                                            objPlotCenterDistance.Plot_slno = survey.PlotSlno;
                                            objPlotCenterDistance.TreeNo = distance.TreeNo;
                                            objPlotCenterDistance.Distance = distance.Distance;
                                            ctx.T_Inv_PlotCenterDistance.Add(objPlotCenterDistance);
                                            ctx.SaveChanges();
                                        }
                                        catch (DbEntityValidationException ex)
                                        {
                                            foreach (var error in ex.EntityValidationErrors)
                                            {
                                                foreach (var message in error.ValidationErrors)
                                                {
                                                    Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                        message.PropertyName + " in table " +
                                                        "T_Inv_PlotCenterDistance", "INVENTORY");
                                                }
                                            }
                                            objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                            objInvRespMessage.Status = "Error";
                                            objInvRespMessage.InvType = string.Empty;
                                            objInvRespMessage.FeatID = objCompartment.FeatID;
                                            objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                            objInvResponse.ResponseMessage = objInvRespMessage;
                                            return objInvResponse;
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "T_Inv_PlotCenterDistance", "INVENTORY");
                                            throw ex;
                                        }
                                    }
                                }

                                if (survey.TreeDetails != null)
                                {
                                    foreach (var tree in survey.TreeDetails)
                                    {
                                        try
                                        {
                                            T_INV_TREE_SURVEYDETAILS objTreeSurvey = new T_INV_TREE_SURVEYDETAILS();
                                            int i = 0;
                                            objTreeSurvey.Survey_Slno = survey.SurveySlno;
                                            objTreeSurvey.Plot_slno = survey.PlotSlno;
                                            objTreeSurvey.Compno = objCompartment.CompNo;
                                            objTreeSurvey.Plot_no = survey.PlotNo;
                                            objTreeSurvey.Tree_No = tree.TreeNo;
                                            objTreeSurvey.DBH = tree.DBH;
                                            objTreeSurvey.HCB = tree.HCB;
                                            decimal? topHeight = tree.TopHeight;
                                            if (topHeight.GetValueOrDefault() > 0)
                                            {
                                                objTreeSurvey.TOP_HEIGHT = "T";
                                            }
                                            else
                                            {
                                                objTreeSurvey.TOP_HEIGHT = "F";
                                            }

                                            objTreeSurvey.Height = tree.Height;
                                            objTreeSurvey.X = tree.X;
                                            objTreeSurvey.Y = tree.Y;
                                            objTreeSurvey.StemCode = tree.StemCode;
                                            objTreeSurvey.TreeRemarks = tree.TreeRemarks;
                                            objTreeSurvey.Inventory_Type = survey.InventoryType;
                                            objTreeSurvey.PropertyList = tree.PropertyList;
                                            ctx.T_INV_TREE_SURVEYDETAILS.Add(objTreeSurvey);
                                            ctx.SaveChanges();

                                            tree.TreeSlno = (from item in ctx.T_INV_TREE_SURVEYDETAILS
                                                             where item.Survey_Slno == survey.SurveySlno &&
                                                             item.Plot_slno == survey.PlotSlno &&
                                                             item.Compno == objCompartment.CompNo &&
                                                             item.Plot_no == survey.PlotNo &&
                                                             item.Tree_No == tree.TreeNo
                                                             select item.Tree_Slno).FirstOrDefault();

                                            if (tree.TreeImageDetails != null)
                                            {
                                                foreach (var image in tree.TreeImageDetails)
                                                {
                                                    try
                                                    {
                                                        //Avoid Duplication
                                                        var exists = (from item in ctx.T_INV_TREE_IMAGES
                                                                      where item.Tree_Image == image.ImageName
                                                                      select item).Any();
                                                        if (!exists)
                                                        {
                                                            T_INV_TREE_IMAGES objTreeImages = new T_INV_TREE_IMAGES();
                                                            objTreeImages.Tree_Slno = tree.TreeSlno;
                                                            objTreeImages.Tree_Image = image.ImageName;
                                                            objTreeImages.Description = image.Description;
                                                            objTreeImages.CRT_USERID = survey.SCreatedBy;
                                                            objTreeImages.CRT_DATE = DateTime.Now;
                                                            ctx.T_INV_TREE_IMAGES.Add(objTreeImages);
                                                            ctx.SaveChanges();
                                                        }
                                                    }
                                                    catch (DbEntityValidationException ex)
                                                    {
                                                        foreach (var error in ex.EntityValidationErrors)
                                                        {
                                                            foreach (var message in error.ValidationErrors)
                                                            {
                                                                Log.Writelog("Error : " + message.ErrorMessage +
                                                                    " happened for " + message.PropertyName + " in table " +
                                                                    "T_INV_TREE_IMAGES", "INVENTORY");
                                                            }
                                                        }
                                                        objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                                        objInvRespMessage.Status = "Error";
                                                        objInvRespMessage.InvType = string.Empty;
                                                        objInvRespMessage.FeatID = objCompartment.FeatID;
                                                        objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                                        objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                                        objInvResponse.ResponseMessage = objInvRespMessage;
                                                        return objInvResponse;
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                       "T_INV_TREE_IMAGES", "INVENTORY");
                                                        throw ex;
                                                    }
                                                }
                                            }
                                        }
                                        catch (DbEntityValidationException ex)
                                        {
                                            foreach (var error in ex.EntityValidationErrors)
                                            {
                                                foreach (var message in error.ValidationErrors)
                                                {
                                                    Log.Writelog("Error : " + message.ErrorMessage +
                                                        " happened for " + message.PropertyName + " in table " +
                                                        "T_INV_TREE_SURVEYDETAILS", "INVENTORY");
                                                }
                                            }
                                            objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                            objInvRespMessage.Status = "Error";
                                            objInvRespMessage.InvType = string.Empty;
                                            objInvRespMessage.FeatID = objCompartment.FeatID;
                                            objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                            objInvResponse.ResponseMessage = objInvRespMessage;
                                            return objInvResponse;
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "T_INV_TREE_SURVEYDETAILS", "INVENTORY");
                                            throw ex;
                                        }
                                    }
                                }
                                try
                                {
                                    if (survey.StartFrom.HasValue)
                                    {
                                        var estDate = (from item in ctx.COMPREGs
                                                       where item.FEATID == objCompartment.FeatID
                                                       select item.EST_DATE).FirstOrDefault();

                                        T_INV_TREEMAP_HEADER objHeader = new T_INV_TREEMAP_HEADER();

                                        objHeader.EstDate = estDate.GetValueOrDefault();
                                        objHeader.Survey_Slno = survey.SurveySlno;
                                        objHeader.FeatID = objCompartment.FeatID;
                                        objHeader.PlotNo = survey.PlotSerialNo;
                                        objHeader.InventoryType = survey.InventoryType;
                                        objHeader.StartFrom = survey.StartFrom;
                                        objHeader.TreeMap_Image = survey.TreeMap_Image;

                                        ctx.T_INV_TREEMAP_HEADER.Add(objHeader);
                                        ctx.SaveChanges();

                                        survey.TreeMapSlno = (from item in ctx.T_INV_TREEMAP_HEADER
                                                              where item.Survey_Slno == survey.SurveySlno
                                                              select item.TreeMap_Slno).FirstOrDefault();

                                        if (survey.SurveyTreeMapDetails != null)
                                        {
                                            foreach (var treeMapDetail in survey.SurveyTreeMapDetails)
                                            {
                                                try
                                                {
                                                    T_INV_TREEMAP_DETAIL objDetail = new T_INV_TREEMAP_DETAIL();
                                                    objDetail.TreeMap_Slno = survey.TreeMapSlno;
                                                    objDetail.TopPosition = treeMapDetail.Top;
                                                    objDetail.LeftPosition = treeMapDetail.Left;
                                                    objDetail.TreeNumber = treeMapDetail.TreeNumber;
                                                    ctx.T_INV_TREEMAP_DETAIL.Add(objDetail);
                                                    ctx.SaveChanges();
                                                }
                                                catch (DbEntityValidationException ex)
                                                {
                                                    foreach (var error in ex.EntityValidationErrors)
                                                    {
                                                        foreach (var message in error.ValidationErrors)
                                                        {
                                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                                message.PropertyName + " in table " +
                                                                "T_INV_TREEMAP_DETAIL", "INVENTORY");
                                                        }
                                                    }
                                                    objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                                    objInvRespMessage.Status = "Error";
                                                    objInvRespMessage.InvType = string.Empty;
                                                    objInvRespMessage.FeatID = objCompartment.FeatID;
                                                    objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                                    return objInvResponse;
                                                }
                                                catch (Exception ex)
                                                {
                                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "T_INV_TREEMAP_DETAIL", "INVENTORY");
                                                    throw ex;
                                                }
                                            }
                                        }
                                    }
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "T_INV_TREEMAP_HEADER", "INVENTORY");
                                        }
                                    }
                                    objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = string.Empty;
                                    objInvRespMessage.FeatID = objCompartment.FeatID;
                                    objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                    return objInvResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                               "T_INV_TREEMAP_HEADER", "INVENTORY");
                                    throw ex;
                                }
                            }
                        }
                        ts.Complete();
                        objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                        objInvRespMessage.Status = "Success";
                        objInvRespMessage.InvType = string.Empty;
                        objInvRespMessage.FeatID = objCompartment.FeatID;
                        objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                        objInvRespMessage.ErrorMessage = string.Empty;
                    }
                    catch (DbEntityValidationException ex)
                    {
                        foreach (var error in ex.EntityValidationErrors)
                        {
                            foreach (var message in error.ValidationErrors)
                            {
                                Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                    message.PropertyName + " in table " +
                                    "T_INV_COMPARTMENT", "INVENTORY");
                            }
                        }
                        objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                        objInvRespMessage.Status = "Error";
                        objInvRespMessage.InvType = string.Empty;
                        objInvRespMessage.FeatID = objCompartment.FeatID;
                        objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                        objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                    }
                    catch (Exception ex)
                    {
                        Log.Writelog("Compartment data not saved " + ex.Message, "INVENTORY");
                        Exception temp = ex;
                        while (temp.InnerException != null)
                        {
                            Log.Writelog("Compartment data not saved " + temp.InnerException.Message, "INVENTORY");
                            temp = temp.InnerException;
                        }
                        Log.Writelog("Compartment data not saved " + ex.StackTrace, "INVENTORY");

                        objInvRespMessage.CompartmentNo = objCompartment.CompNo;
                        objInvRespMessage.Status = "Error";
                        objInvRespMessage.InvType = string.Empty;
                        objInvRespMessage.FeatID = objCompartment.FeatID;
                        objInvRespMessage.CompSlNo = objCompartment.CompSlno.ToString();
                        objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                    }
                }
            }

            objInvResponse.ResponseMessage = objInvRespMessage;
            return objInvResponse;
        }

        public InventoryResponseClass InsertInventoryDetails(clsComparmentDet objCompartment)
        {
            string strImageDescription = string.Empty;
            string strSave = string.Empty;
            string strCreatedBy = string.Empty;
            int compSlno = 0;
            string strPlotforTree = string.Empty;
            InventoryResponseClass objInvResponse = new InventoryResponseClass();
            InventoryResponseMessage objInvRespMessage = new InventoryResponseMessage();
            string COMPNO = string.Empty;
            string InvType = string.Empty;
            string FeatID = string.Empty;
            List<clsInvPlot> lstinvplot = new List<clsInvPlot>();

            var context = new IFOC_FFE_FAEntities();

            if (objCompartment.CompSlno != null && objCompartment.CompSlno != "")
            {
                int csl = Convert.ToInt32(objCompartment.CompSlno);
                var qData = context.T_INV_COMPARTMENT.Where(x => x.Comp_Slno == csl);
                var data = qData.FirstOrDefault<T_INV_COMPARTMENT>();

                if (data != null)
                {
                    Log.Writelog("FeatID : " + objCompartment.FeatID + " COMPNO : " + objCompartment.COMPNO + " CompSlNo " + data.Comp_Slno + " is already available in staging database", "INVENTORY");
                    objInvRespMessage.CompartmentNo = COMPNO;
                    objInvRespMessage.Status = "Exist";
                    objInvRespMessage.InvType = InvType;
                    objInvRespMessage.FeatID = FeatID;
                    objInvRespMessage.CompSlNo = data.Comp_Slno.ToString();
                    objInvResponse.ResponseMessage = objInvRespMessage;
                    return objInvResponse;
                }
            }

            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    //Transaction
                    using (TransactionScope ts = new TransactionScope())
                    {
                        bool success = false;
                        try
                        {
                            var varsurveynumber = ctx.SP_Inv_FetchSurveyNumber(objCompartment.FeatID);
                            string strSurveyNoForComp = string.Empty;
                            foreach (var s in varsurveynumber)
                            {
                                strSurveyNoForComp = s.SURVEYNUMBER;
                            }

                            T_INV_COMPARTMENT compObj = new T_INV_COMPARTMENT();
                            compObj.COMPNO = objCompartment.COMPNO;
                            compObj.FeatID = objCompartment.FeatID;
                            FeatID = objCompartment.FeatID;
                            compObj.SURVEY_NO = strSurveyNoForComp;
                            compObj.Sector = "0";
                            compObj.Estate = "0";
                            compObj.CRT_DATE = DateTime.Now;
                            Log.Writelog("T_Inv_compartment table is inserting with feature id - " + objCompartment.FeatID + " COMPNO :" + objCompartment.COMPNO + " SURVEY_NO :" + strSurveyNoForComp, "INVENTORY");
                            ctx.T_INV_COMPARTMENT.Add(compObj);
                            ctx.SaveChanges();
                            success = true;

                            Log.Writelog("T_Inv_compartment table is inserted with feature id - " + objCompartment.FeatID, "INVENTORY");

                            var slno = ctx.T_INV_COMPARTMENT.Max(x => x.Comp_Slno);
                            compSlno = Convert.ToInt32(slno);
                        }
                        catch (Exception ex)
                        {
                            success = false;
                            Log.Writelog("Compartment data not saved" + ex.Message, "INVENTORY");
                            objInvRespMessage.CompartmentNo = COMPNO;
                            objInvRespMessage.Status = "Error";
                            objInvRespMessage.InvType = InvType;
                            objInvRespMessage.FeatID = FeatID;
                            objInvRespMessage.CompSlNo = objCompartment.CompSlno;
                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                            objInvResponse.ResponseMessage = objInvRespMessage;
                        }

                        if (success)
                        {
                            ts.Complete();
                            Log.Writelog("Saved T_INV_COMPARTMENT with compslno " + compSlno, "INVENTORY");
                            objInvRespMessage.CompartmentNo = COMPNO;
                            objInvRespMessage.Status = "Success";
                            objInvRespMessage.InvType = InvType;
                            objInvRespMessage.FeatID = FeatID;
                            objInvRespMessage.CompSlNo = compSlno.ToString();
                            objInvRespMessage.ErrorMessage = "";
                            objInvResponse.ResponseMessage = objInvRespMessage;
                        }
                        else
                        {
                            Log.Writelog("The Transaction could not be completed", "INVENTORY");
                            objInvRespMessage.CompartmentNo = COMPNO;
                            objInvRespMessage.Status = "Error";
                            objInvRespMessage.InvType = InvType;
                            objInvRespMessage.FeatID = FeatID;
                            objInvRespMessage.CompSlNo = objCompartment.CompSlno;
                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                            objInvResponse.ResponseMessage = objInvRespMessage;
                        }
                    } //using ts
                } //using ctx
            } //try
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "INVENTORY");
                objInvRespMessage.CompartmentNo = COMPNO;
                objInvRespMessage.Status = "Error";
                objInvRespMessage.InvType = InvType;
                objInvRespMessage.FeatID = FeatID;
                objInvRespMessage.CompSlNo = objCompartment.CompSlno;
                objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                objInvResponse.ResponseMessage = objInvRespMessage;
            }
            return objInvResponse;
        }
        #endregion InsertInventoryDetails

        #region InsertInventoryDetails
        public InventoryResponseClass InsertInventoryPlots(List<clsPlotSurveyDet> lstPlotSurveys, List<clsPlotSpacing> lstPlotSpacing,
           List<clsTreeSurvey> lstTreeSurvey, List<clsTreeImage> lstTreeImages, List<clsPlotCenterDistance> lstPlotDistance, List<clsWeedCoverage> lstWeedCoverage, string compSlNo, List<clsLAI> lstLai)
        {
            string strImageDescription = string.Empty;
            string strSave = string.Empty;
            string strCreatedBy = string.Empty;
            string strPlotforTree = string.Empty;
            InventoryResponseClass objInvResponse = new InventoryResponseClass();
            InventoryResponseMessage objInvRespMessage = new InventoryResponseMessage();
            string COMPNO = string.Empty;
            string InvType = string.Empty;
            string FeatID = string.Empty;
            int plotslno = 0;
            int surveySlno = 0;
            int comp_Slno = 0;
            bool success = false;
            List<clsInvPlot> lstinvplot = new List<clsInvPlot>();
            T_INV_COMPARTMENT CompartmentData = new T_INV_COMPARTMENT();

            if (compSlNo != String.Empty && compSlNo != "null")
            {
                comp_Slno = Convert.ToInt32(compSlNo);

                var context = new IFOC_FFE_FAEntities();
                var qCompartmentData = context.T_INV_COMPARTMENT.Where(x => x.Comp_Slno == comp_Slno);
                CompartmentData = qCompartmentData.FirstOrDefault<T_INV_COMPARTMENT>();
                if (CompartmentData == null)
                {
                    Log.Writelog("Invalid Compartment Serial Number --" + comp_Slno, "INVENTORY");
                    success = false;
                    objInvRespMessage.Status = "Error";
                    objInvRespMessage.CompartmentNo = "";
                    objInvRespMessage.InvType = "";
                    objInvRespMessage.FeatID = "";
                    objInvRespMessage.CompSlNo = "";
                    objInvRespMessage.ErrorMessage = "Invalid Compartment Serial Number";
                    objInvResponse.ResponseMessage = objInvRespMessage;
                    return objInvResponse;
                }

                var plotNo = lstPlotSurveys[0].PlotNo;

                var surveyDetails = from survey in context.T_INV_SURVEYDETAILS
                                    join plot in context.T_INV_PLOT on survey.Survey_Slno equals plot.Survey_Slno
                                    where (survey.Comp_slno == comp_Slno) && (plot.PlotNo == plotNo)
                                    select new { Survey_Slno = survey.Survey_Slno };
                var surveyDetailList = surveyDetails.ToList();
                if (surveyDetailList.Count > 0)
                {
                    Log.Writelog("PlotNo " + plotNo + " Compartment SLNO " + comp_Slno + " is already available in staging database", "INVENTORY");
                    success = false;
                    objInvRespMessage.Status = "Exist";
                    objInvRespMessage.CompSlNo = compSlNo;
                    objInvRespMessage.CompartmentNo = "";
                    objInvRespMessage.InvType = "";
                    objInvRespMessage.FeatID = "";
                    objInvRespMessage.ErrorMessage = "PlotNo " + plotNo + " Compartment SLNO " + comp_Slno + " is already available in staging database";
                    objInvResponse.ResponseMessage = objInvRespMessage;
                    return objInvResponse;
                }
            }
            else
            {
                Log.Writelog("The Compartment Serial No is empty", "INVENTORY");
                success = false;
                objInvRespMessage.Status = "Error";
                objInvRespMessage.CompSlNo = compSlNo;
                objInvRespMessage.CompartmentNo = "";
                objInvRespMessage.InvType = "";
                objInvRespMessage.FeatID = "";
                objInvRespMessage.ErrorMessage = "The Compartment Serial No is empty";
                objInvResponse.ResponseMessage = objInvRespMessage;
                return objInvResponse;
            }

            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    using (TransactionScope ts = new TransactionScope())
                    {
                        int ctrplotsurvey = 0;
                        ctrplotsurvey = lstPlotSurveys.Count;
                        var cSlno = Convert.ToInt32(compSlNo);

                        if (lstPlotSurveys.Count > 0)
                        {
                            for (int i = 0; i < ctrplotsurvey; i++)
                            {
                                try
                                {
                                    T_INV_SURVEYDETAILS objSurveyList = new T_INV_SURVEYDETAILS();

                                    objSurveyList.Survey_Date = Convert.ToDateTime(lstPlotSurveys[i].SurveyDate);
                                    objSurveyList.Comp_slno = cSlno;
                                    objSurveyList.Inventory_Type = lstPlotSurveys[i].SInventoryType;
                                    objSurveyList.COMPLETE = lstPlotSurveys[i].COMPLETE;
                                    objSurveyList.TEAM_CODE = lstPlotSurveys[i].TeamCode;
                                    objSurveyList.Survey_LineNo = lstPlotSurveys[i].SurveyLineNo;
                                    objSurveyList.AzimuthPlotLine = lstPlotSurveys[i].AzimuthPlotLine;
                                    objSurveyList.Remarks = lstPlotSurveys[i].SRemarks;
                                    objSurveyList.Maintainence_Status = lstPlotSurveys[i].MaintainenceStatus;
                                    objSurveyList.Flooding = lstPlotSurveys[i].Flooding;
                                    objSurveyList.SoilSampleCollected = lstPlotSurveys[i].SoilSampleCollected;
                                    objSurveyList.UUID = lstPlotSurveys[i].UUID;
                                    objSurveyList.Name = lstPlotSurveys[i].Name;
                                    //objSurveyList.SAPID = lstPlotSurveys[i].SAPID;
                                    objSurveyList.SAPID = string.Empty;
                                    objSurveyList.Keyed_in_by = "3";
                                    objSurveyList.CRT_USERID = lstPlotSurveys[i].SCreatedBy;
                                    strCreatedBy = lstPlotSurveys[i].SCreatedBy;
                                    objSurveyList.CRT_DATE = Convert.ToDateTime(lstPlotSurveys[i].SCreatedDate);
                                    objSurveyList.Total_LiveYellow = Convert.ToInt32(lstPlotSurveys[i].TotalLiveYellow);
                                    objSurveyList.Total_Dead = Convert.ToInt32(lstPlotSurveys[i].TotalDead);
                                    objSurveyList.Total_Healthy = Convert.ToInt32(lstPlotSurveys[i].TotalHealthy); ;
                                    objSurveyList.Error_SurveySlno = Convert.ToInt32(lstPlotSurveys[i].ErrorSurveySlno);
                                    objSurveyList.GPS_Lat = Convert.ToDecimal(lstPlotSurveys[i].SurGPSLat);
                                    objSurveyList.GPS_Long = Convert.ToDecimal(lstPlotSurveys[i].SurGPSLong);
                                    try
                                    {
                                        if (lstPlotSurveys[i].PlotSerialNo != null)
                                        {
                                            if (lstPlotSurveys[i].PlotSerialNo.Trim().Length > 0)
                                            {
                                                objSurveyList.PlotSerialNo = lstPlotSurveys[i].PlotSerialNo;
                                            }
                                        }
                                    }
                                    catch (Exception ex) { Log.Writelog(ex.Message, "INVENTORY"); }
                                    ctx.T_INV_SURVEYDETAILS.Add(objSurveyList);

                                    ctx.SaveChanges();
                                    success = true;
                                    objSurveyList = null;
                                    var s = ctx.T_INV_SURVEYDETAILS.Max(x => x.Survey_Slno);
                                    surveySlno = Convert.ToInt32(s);
                                    strSave = "Successfully saved survey details with survey slno = " + surveySlno;

                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog(ex.Message, "INVENTORY");
                                    Log.Writelog(ex.InnerException.ToString(), "INVENTORY");
                                    success = false;
                                    objInvRespMessage.CompartmentNo = COMPNO;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = InvType;
                                    objInvRespMessage.FeatID = FeatID;
                                    objInvRespMessage.CompSlNo = cSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                }

                                try
                                {
                                    if (lstPlotSurveys[i].StratumNo >= 0)
                                    {
                                        var invStratumDetails = ctx.SP_INV_STRATUM_DETAILS(surveySlno, lstPlotSurveys[i].StratumNo, lstPlotSurveys[i].StratumHa, lstPlotSurveys[i].StratumIsBlankSpot);
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog(ex.Message, "INVENTORY");
                                    Log.Writelog(ex.InnerException.ToString(), "INVENTORY");
                                    success = false;
                                    objInvRespMessage.CompartmentNo = COMPNO;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = InvType;
                                    objInvRespMessage.FeatID = FeatID;
                                    objInvRespMessage.CompSlNo = cSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                }

                                try
                                {
                                    T_INV_PLOT objPlot = new T_INV_PLOT();
                                    objPlot.PlotNo = lstPlotSurveys[i].PlotNo;
                                    strPlotforTree = lstPlotSurveys[i].PlotNo;
                                    Log.Writelog("suvey slno is " + surveySlno, "INVENTORY");
                                    objPlot.Survey_Slno = surveySlno;

                                    objPlot.PlotCenter_XDirection = lstPlotSurveys[i].PlotCenterXDirection;
                                    objPlot.PlotCenter_Ydirection = lstPlotSurveys[i].PlotCenterYdirection;
                                    objPlot.Plot_Radius = Convert.ToDecimal(lstPlotSurveys[i].PlotRadius);
                                    objPlot.Plotcenter_lat = Convert.ToDecimal(lstPlotSurveys[i].SurGPSLat);
                                    objPlot.Plotcenter_long = Convert.ToDecimal(lstPlotSurveys[i].SurGPSLong);
                                    decimal plotLatitude = Convert.ToDecimal(lstPlotSurveys[i].SurGPSLat);
                                    decimal plotLongitude = Convert.ToDecimal(lstPlotSurveys[i].SurGPSLong);

                                    if (plotLatitude > 0)
                                    {
                                        objPlot.PlotCenter_Ydirection = "N";
                                    }
                                    else
                                    {
                                        objPlot.PlotCenter_Ydirection = "S";
                                    }

                                    if (plotLongitude > 0)
                                    {
                                        objPlot.PlotCenter_XDirection = "E";
                                    }
                                    else
                                    {
                                        objPlot.PlotCenter_XDirection = "W";
                                    }

                                    objPlot.Sample_Percentage = Convert.ToDecimal(lstPlotSurveys[i].SamplePercentage);
                                    objPlot.CRT_USERID = lstPlotSurveys[i].PCreatedBy;
                                    objPlot.CRT_DATE = Convert.ToDateTime(lstPlotSurveys[i].PCreatedDate);
                                    ctx.T_INV_PLOT.Add(objPlot);
                                    ctx.SaveChanges();
                                    success = true;
                                    Log.Writelog("Plot inserted", "INVENTORY");
                                    objPlot = null;
                                    strSave = strSave + " " + " Saved plot details ";
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog(ex.Message, "INVENTORY");
                                    Log.Writelog(ex.InnerException.ToString(), "INVENTORY");
                                    success = false;
                                    objInvRespMessage.CompartmentNo = COMPNO;
                                    objInvRespMessage.Status = "Error";
                                    objInvRespMessage.InvType = InvType;
                                    objInvRespMessage.FeatID = FeatID;
                                    objInvRespMessage.CompSlNo = cSlno.ToString();
                                    objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objInvResponse.ResponseMessage = objInvRespMessage;
                                }

                                var vplotslno = ctx.T_INV_PLOT.Max(x => x.Plot_Slno);
                                plotslno = Convert.ToInt32(vplotslno.ToString());
                                Log.Writelog("Plot slno is " + plotslno.ToString(), "INVENTORY");
                                clsInvPlot objinvplot = new clsInvPlot();
                                objinvplot.Compslno = cSlno.ToString();
                                objinvplot.Plotslno = plotslno.ToString();
                                objinvplot.Surveyslno = surveySlno.ToString();
                                objinvplot.Plotno = strPlotforTree;
                                lstinvplot.Add(objinvplot);
                                objinvplot = null;

                            } // end of iterating the plots or surveys

                            int ctr = lstPlotSpacing.Count;
                            Log.Writelog("Total count of plotspacing  is " + ctr, "INVENTORY");
                            try
                            {
                                int totalplots = lstinvplot.Count;
                                for (int ctrplots = 0; ctrplots < totalplots; ctrplots++)
                                {
                                    string strPlotnumber = lstinvplot[ctrplots].Plotno;
                                    plotslno = Convert.ToInt32(lstinvplot[ctrplots].Plotslno);

                                    var sCount = from PlotSpacing in lstPlotSpacing
                                                 where PlotSpacing.PlotNo.Contains(strPlotnumber)
                                                 select PlotSpacing;

                                    List<clsPlotSpacing> lstPlotSpacingDetails = sCount.ToList<clsPlotSpacing>();

                                    int j = lstPlotSpacingDetails.Count;
                                    for (int m = 0; m < j; m++)
                                    {
                                        T_INV_PLOTSPACING objPlotspacing = new T_INV_PLOTSPACING();
                                        Log.Writelog("m value is " + m, "INVENTORY");
                                        objPlotspacing.Plot_Slno = plotslno;
                                        if (lstPlotSpacingDetails[m].BRI.Trim().Length > 0)
                                        {
                                            objPlotspacing.BRI = Convert.ToDecimal(lstPlotSpacingDetails[m].BRI);
                                        }
                                        if (lstPlotSpacingDetails[m].IRI.Trim().Length > 0)
                                        {
                                            objPlotspacing.IRI = Convert.ToDecimal(lstPlotSpacingDetails[m].IRI);
                                        }
                                        if (lstPlotSpacingDetails[m].BRITREES.Trim().Length > 0)
                                        {
                                            objPlotspacing.BRITREES = Convert.ToString(lstPlotSpacingDetails[m].BRITREES);
                                        }
                                        if (lstPlotSpacingDetails[m].IRITREES.Trim().Length > 0)
                                        {
                                            objPlotspacing.IRITREES = Convert.ToString(lstPlotSpacingDetails[m].IRITREES);
                                        }
                                        if (lstPlotSpacingDetails[m].TREEREMARKS.Trim().Length > 0)
                                        {
                                            objPlotspacing.TREEREMARKS = Convert.ToString(lstPlotSpacingDetails[m].TREEREMARKS);
                                        }
                                        ctx.T_INV_PLOTSPACING.Add(objPlotspacing);
                                        ctx.SaveChanges();
                                        success = true;
                                        sCount = null;
                                        objPlotspacing = null;
                                        strSave = strSave + " " + " Saved plot spacing details ";
                                    }
                                } // end of ctrplots
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog("error while saving T_INV_PLOTSPACING " + ex.Message, "INVENTORY");
                                objInvRespMessage.CompartmentNo = COMPNO;
                                objInvRespMessage.Status = "Error";
                                objInvRespMessage.InvType = InvType;
                                objInvRespMessage.FeatID = FeatID;
                                objInvRespMessage.CompSlNo = cSlno.ToString();
                                objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                objInvResponse.ResponseMessage = objInvRespMessage;
                            }

                            int ctr3 = 0;
                            ctr3 = lstWeedCoverage.Count;
                            Log.Writelog("Total count of WeedCoverage  is " + ctr3, "INVENTORY");
                            try
                            {
                                int totalplots = lstinvplot.Count;
                                for (int ctrplots = 0; ctrplots < totalplots; ctrplots++)
                                {
                                    string strPlotnumber = lstinvplot[ctrplots].Plotno;
                                    plotslno = Convert.ToInt32(lstinvplot[ctrplots].Plotslno);

                                    var sCount = from WeedCoverage in lstWeedCoverage
                                                 where WeedCoverage.PlotNo.Contains(strPlotnumber)
                                                 select WeedCoverage;

                                    List<clsWeedCoverage> lstWeedCoverageDetails = sCount.ToList<clsWeedCoverage>();

                                    int lwc = lstWeedCoverageDetails.Count;
                                    for (int wc = 0; wc < lwc; wc++)
                                    {
                                        T_INV_TREE_WEED_COVERAGE objPlotWeedCoverage = new T_INV_TREE_WEED_COVERAGE();
                                        // Log.Writelog("wc value wc " + wc, "INVENTORY");
                                        objPlotWeedCoverage.Plot_Slno = plotslno;
                                        if (lstWeedCoverageDetails[wc].Col.Trim().Length > 0)
                                        {
                                            objPlotWeedCoverage.COL = lstWeedCoverageDetails[wc].Col;
                                        }
                                        if (lstWeedCoverageDetails[wc].Val.Trim().Length > 0)
                                        {
                                            objPlotWeedCoverage.VAL = Convert.ToDecimal(lstWeedCoverageDetails[wc].Val);
                                        }
                                        ctx.T_INV_TREE_WEED_COVERAGE.Add(objPlotWeedCoverage);
                                        ctx.SaveChanges();
                                        success = false;
                                        sCount = null;
                                        objPlotWeedCoverage = null;
                                        strSave = strSave + " " + " Saved Weed Coverage ";
                                    }// m -for loop plot spacing                                
                                } // end of ctrplots
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog("error while saving T_INV_TREE_WEED_COVERAGE " + ex.Message, "INVENTORY");
                                objInvRespMessage.CompartmentNo = COMPNO;
                                objInvRespMessage.Status = "Error";
                                objInvRespMessage.InvType = InvType;
                                objInvRespMessage.FeatID = FeatID;
                                objInvRespMessage.CompSlNo = cSlno.ToString();
                                objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                objInvResponse.ResponseMessage = objInvRespMessage;
                            }

                            int ctr4 = 0;
                            ctr4 = lstLai.Count;
                            Log.Writelog("Total count of LAI  is " + ctr4, "INVENTORY");
                            try
                            {
                                int totalplots = lstinvplot.Count;
                                for (int ctrplots = 0; ctrplots < totalplots; ctrplots++)
                                {
                                    string strPlotnumber = lstinvplot[ctrplots].Plotno;
                                    plotslno = Convert.ToInt32(lstinvplot[ctrplots].Plotslno);

                                    var sCount = from lai in lstLai
                                                 where lai.PlotNo.Contains(strPlotnumber)
                                                 select lai;

                                    List<clsLAI> lstLaiDetails = sCount.ToList<clsLAI>();

                                    int countOfLai = lstLaiDetails.Count;
                                    for (int col = 0; col < countOfLai; col++)
                                    {
                                        T_INV_TREE_LAI objPlotLai = new T_INV_TREE_LAI();
                                        // Log.Writelog("lai value lai " + countOfLai, "INVENTORY");
                                        objPlotLai.Plot_Slno = plotslno;
                                        if (lstLaiDetails[col].Col.Trim().Length > 0)
                                        {
                                            objPlotLai.Col = lstLaiDetails[col].Col;
                                        }
                                        if (lstLaiDetails[col].Val.Trim().Length > 0)
                                        {
                                            objPlotLai.Val = Convert.ToDecimal(lstLaiDetails[col].Val);
                                        }
                                        ctx.T_INV_TREE_LAI.Add(objPlotLai);
                                        ctx.SaveChanges();
                                        success = false;
                                        sCount = null;
                                        objPlotLai = null;
                                        strSave = strSave + " " + " Saved LAI ";
                                    }// m -for loop plot spacing                                
                                } // end of ctrplots
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog("error while saving T_INV_TREE_LAI " + ex.Message, "INVENTORY");
                                objInvRespMessage.CompartmentNo = COMPNO;
                                objInvRespMessage.Status = "Error";
                                objInvRespMessage.InvType = InvType;
                                objInvRespMessage.FeatID = FeatID;
                                objInvRespMessage.CompSlNo = cSlno.ToString();
                                objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                objInvResponse.ResponseMessage = objInvRespMessage;
                            }

                            int ctr2 = 0;
                            ctr2 = lstTreeSurvey.Count;
                            int treeSlNo = 0;
                            try
                            {
                                int totalplots = lstinvplot.Count;
                                for (int ctrplots = 0; ctrplots < totalplots; ctrplots++)
                                {
                                    string strPlotnumber = lstinvplot[ctrplots].Plotno;
                                    plotslno = Convert.ToInt32(lstinvplot[ctrplots].Plotslno);
                                    surveySlno = Convert.ToInt32(lstinvplot[ctrplots].Surveyslno);

                                    var sCount = from TreeSurvey in lstTreeSurvey
                                                 where TreeSurvey.PlotNo.Contains(strPlotnumber)
                                                 select TreeSurvey;

                                    List<clsTreeSurvey> lstTreeSurveyDetails = sCount.ToList<clsTreeSurvey>();

                                    int k = 0;
                                    k = lstTreeSurveyDetails.Count;
                                    for (int m = 0; m < k; m++)
                                    {
                                        T_INV_TREE_SURVEYDETAILS objTreeSurvey = new T_INV_TREE_SURVEYDETAILS();
                                        int i = 0;
                                        objTreeSurvey.Compno = lstTreeSurveyDetails[m].COMPNO;
                                        if (lstTreeSurveyDetails[m].DBH.Trim().Length > 0)
                                        {
                                            objTreeSurvey.DBH = Convert.ToDecimal(lstTreeSurveyDetails[m].DBH);
                                        }
                                        if (lstTreeSurveyDetails[m].HCB.Trim().Length > 0)
                                        {
                                            objTreeSurvey.HCB = Convert.ToDecimal(lstTreeSurveyDetails[m].HCB);
                                        }
                                        if (lstTreeSurveyDetails[m].TOPHEIGHT.Trim().Length > 0)
                                        {
                                            decimal varTopHeight = Convert.ToDecimal(lstTreeSurveyDetails[m].TOPHEIGHT.Trim());
                                            if (varTopHeight > 0)
                                            {
                                                objTreeSurvey.TOP_HEIGHT = "T";
                                            }
                                            else
                                            {
                                                objTreeSurvey.TOP_HEIGHT = "F";
                                            }
                                        }

                                        if (lstTreeSurveyDetails[m].TSHeight.Trim().Length > 0)
                                        {
                                            objTreeSurvey.Height = Convert.ToDecimal(lstTreeSurveyDetails[m].TSHeight);
                                        }
                                        objTreeSurvey.Plot_no = lstTreeSurveyDetails[m].PlotNo;
                                        objTreeSurvey.Tree_No = Convert.ToInt32(lstTreeSurveyDetails[m].TreeNo);
                                        if (lstTreeSurvey[m].X.Trim().Length > 0)
                                        {
                                            objTreeSurvey.X = Convert.ToDecimal(lstTreeSurveyDetails[m].X);
                                        }
                                        if (lstTreeSurvey[m].Y.Trim().Length > 0)
                                        {
                                            objTreeSurvey.Y = Convert.ToDecimal(lstTreeSurveyDetails[m].Y);
                                        }

                                        objTreeSurvey.StemCode = lstTreeSurveyDetails[m].StemCode;
                                        //Added by Soumitri on 28/05/2018 for the Remarks column on the Tree Details
                                        objTreeSurvey.TreeRemarks = lstTreeSurveyDetails[m].TreeRemarks;
                                        string strProperties = lstTreeSurveyDetails[m].TreeProperties;
                                        string strImageNames = lstTreeSurveyDetails[m].ImageName;
                                        strImageDescription = lstTreeSurveyDetails[m].ImageDescription;
                                        objTreeSurvey.Inventory_Type = lstPlotSurveys[i].SInventoryType;
                                        objTreeSurvey.Plot_slno = Convert.ToInt32(plotslno);
                                        objTreeSurvey.Survey_Slno = surveySlno;
                                        objTreeSurvey.PropertyList = strProperties;
                                        try
                                        {
                                            ctx.T_INV_TREE_SURVEYDETAILS.Add(objTreeSurvey);
                                            ctx.SaveChanges();
                                            success = true;
                                            objTreeSurvey = null;
                                            strSave = strSave + " " + " Saved Tree  details ";
                                            Log.Writelog("Saved T_INV_TREE_SURVEYDETAILS " + m, "INVENTORY");
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog("error while saving T_INV_TREE_SURVEYDETAILS " + ex.Message, "INVENTORY");
                                            Log.Writelog("error while saving T_INV_TREE_SURVEYDETAILS " + ex.StackTrace, "INVENTORY");
                                            objInvRespMessage.CompartmentNo = COMPNO;
                                            objInvRespMessage.Status = "Error";
                                            objInvRespMessage.InvType = InvType;
                                            objInvRespMessage.FeatID = FeatID;
                                            objInvRespMessage.CompSlNo = cSlno.ToString();
                                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                            objInvResponse.ResponseMessage = objInvRespMessage;
                                        }

                                        if (strImageNames.Trim().Length > 0)
                                        {
                                            string[] strImages = strImageNames.Split(',');
                                            string[] arImageDescription = strImageDescription.Split(',');
                                            var tree = ctx.T_INV_TREE_SURVEYDETAILS.Max(x => x.Tree_Slno);
                                            treeSlNo = Convert.ToInt32(tree);
                                            int treectr = strImages.Length;

                                            for (int a = 0; a < treectr; a++)
                                            {
                                                var imageName = strImages[a];
                                                //Avoid Duplication
                                                var exists = (from item in ctx.T_INV_TREE_IMAGES
                                                              where item.Tree_Image == imageName
                                                              select item).Any();
                                                if (!exists)
                                                {

                                                    // Log.Writelog(" Image number " + a.ToString(), "INVENTORY");
                                                    T_INV_TREE_IMAGES objTreeImages = new T_INV_TREE_IMAGES();
                                                    objTreeImages.Tree_Image = strImages[a];
                                                    objTreeImages.Tree_Slno = treeSlNo;
                                                    objTreeImages.CRT_USERID = strCreatedBy;
                                                    objTreeImages.CRT_DATE = DateTime.Now;
                                                    objTreeImages.Description = arImageDescription[a];
                                                    try
                                                    {
                                                        ctx.T_INV_TREE_IMAGES.Add(objTreeImages);
                                                        ctx.SaveChanges();
                                                        success = true;
                                                        objTreeImages = null;
                                                        strSave = " " + " Saved Image  details ";
                                                        Log.Writelog("Saved T_INV_TREE_IMAGES " + m, "INVENTORY");
                                                    }
                                                    catch (Exception ex)
                                                    {
                                                        Log.Writelog("error while saving T_INV_TREE_IMAGES " + ex.Message, "INVENTORY");
                                                        objInvRespMessage.CompartmentNo = COMPNO;
                                                        objInvRespMessage.Status = "Error";
                                                        objInvRespMessage.InvType = InvType;
                                                        objInvRespMessage.FeatID = FeatID;
                                                        objInvRespMessage.CompSlNo = cSlno.ToString();
                                                        objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                                        objInvResponse.ResponseMessage = objInvRespMessage;
                                                    }

                                                }
                                                else
                                                {
                                                    //Log Duplicate File. Added by soumitri.                                                    
                                                    Log.Writelog("Record Duiplication Image Starts.", "INVENTORY");
                                                    Log.Writelog(imageName, "INVENTORY");
                                                }
                                            }
                                        }
                                    } //m - for loop

                                    //Added By Smrithy-05-11-2015
                                    int ctrPlotDistance = lstPlotDistance.Count;
                                    try
                                    {
                                        var count = from PlotDistance in lstPlotDistance
                                                    where PlotDistance.PlotNo.Contains(strPlotforTree)
                                                    select PlotDistance;

                                        List<clsPlotCenterDistance> lstRWATreeDetails = count.ToList<clsPlotCenterDistance>();

                                        for (int disCount = 0; disCount < lstRWATreeDetails.Count; disCount++)
                                        {
                                            T_Inv_PlotCenterDistance objPlotCenterDistance = new T_Inv_PlotCenterDistance();
                                            objPlotCenterDistance.Plot_slno = Convert.ToInt32(plotslno);
                                            objPlotCenterDistance.TreeNo = Convert.ToInt32(lstRWATreeDetails[disCount].TreeNo);

                                            //Changed to decimal as the field is changed in the db
                                            objPlotCenterDistance.Distance = Convert.ToDecimal(lstRWATreeDetails[disCount].Distance);
                                            ctx.T_Inv_PlotCenterDistance.Add(objPlotCenterDistance);
                                            ctx.SaveChanges();
                                            success = true;
                                            objPlotCenterDistance = null;
                                            strSave = " " + " Saved PlotCenterDistance  details ";
                                            // Log.Writelog("Saved T_Inv_PlotCenterDistance ", "INVENTORY");
                                        }
                                        strSave = "SAVED";
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.Writelog("error while saving T_Inv_PlotCenterDistance " + ex.Message, "INVENTORY");
                                        objInvRespMessage.CompartmentNo = COMPNO;
                                        objInvRespMessage.Status = "Error";
                                        objInvRespMessage.InvType = InvType;
                                        objInvRespMessage.FeatID = FeatID;
                                        objInvRespMessage.CompSlNo = cSlno.ToString();
                                        objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                        objInvResponse.ResponseMessage = objInvRespMessage;
                                    }

                                } // end of iterating the plots

                            }
                            catch (Exception ex)
                            {
                                Log.Writelog(ex.Message, "INVENTORY"); Log.Writelog(ex.InnerException.ToString(), "INVENTORY");
                                strSave = "ERROR";
                                success = false;
                                objInvRespMessage.CompartmentNo = COMPNO;
                                objInvRespMessage.Status = "Error";
                                objInvRespMessage.InvType = InvType;
                                objInvRespMessage.FeatID = FeatID;
                                objInvRespMessage.CompSlNo = cSlno.ToString();
                                objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                                objInvResponse.ResponseMessage = objInvRespMessage;
                            }

                        }

                        if (success)
                        {
                            ts.Complete();
                            objInvRespMessage.CompartmentNo = COMPNO;
                            objInvRespMessage.Status = "Success";
                            objInvRespMessage.InvType = InvType;
                            objInvRespMessage.FeatID = FeatID;
                            objInvRespMessage.CompSlNo = cSlno.ToString();
                            objInvRespMessage.ErrorMessage = "";
                            objInvResponse.ResponseMessage = objInvRespMessage;

                        }
                        else
                        {
                            Log.Writelog("The Transaction could not be completed", "INVENTORY");
                            // strSave = "The Transaction could not be completed";
                            objInvRespMessage.CompartmentNo = COMPNO;
                            objInvRespMessage.Status = "Error";
                            objInvRespMessage.InvType = InvType;
                            objInvRespMessage.FeatID = FeatID;
                            objInvRespMessage.CompSlNo = cSlno.ToString();
                            objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                            objInvResponse.ResponseMessage = objInvRespMessage;
                        }
                    } //using ts
                } //using ctx
            } //try
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "INVENTORY");
                objInvRespMessage.CompartmentNo = COMPNO;
                objInvRespMessage.Status = "Error";
                objInvRespMessage.InvType = InvType;
                objInvRespMessage.FeatID = FeatID;
                objInvRespMessage.CompSlNo = compSlNo;
                objInvRespMessage.ErrorMessage = "The Transaction could not be completed";
                objInvResponse.ResponseMessage = objInvRespMessage;
            }
            return objInvResponse;
        }
        #endregion InsertInventoryDetails
        #endregion Inventory

        #region Wood Supply
        #region GetTripTicketDetailsBySector
        /// <summary>
        /// Fetching the trip truck details by passing the sector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsTripTicket> GetTripTicketDetailsBySector(string sector)
        {
            List<clsTripTicket> lstTripTicket = new List<clsTripTicket>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchTripTicketData_v2(sector);
                foreach (var s in compData)
                {
                    clsTripTicket objTripData = new clsTripTicket();
                    //objTripData.TRIPTICKETNO = s.TRIPTICKETNO;     //Todo: Guaz: to comment out once db is updated to varchar                 
                    objTripData.TRIPTICKETNO = s.STRIPTICKETNO;
                    objTripData.TYPEOFTRUCK = Convert.ToInt16(s.TYPEOFTRUCK);
                    objTripData.DESTINATIONSECTOR = s.DESTINATIONSECTOR;
                    objTripData.DESTINATIONESTATE = s.DESTINATIONESTATE;
                    objTripData.COMPARTMENTNO = s.COMPARTMENTNO;
                    //Changed By Smrithy 18-11-2015 due to Production issue
                    string strYear = s.DISPATCHDATETIME.Year.ToString();
                    string strMonth = s.DISPATCHDATETIME.Month.ToString();
                    string strDay = s.DISPATCHDATETIME.Day.ToString();
                    string strHr = s.DISPATCHDATETIME.Hour.ToString();
                    string strMin = s.DISPATCHDATETIME.Minute.ToString();
                    string strSec = s.DISPATCHDATETIME.Second.ToString();
                    objTripData.DISPATCHDATETIME = strDay + "/" + strMonth + "/" + strYear + " " + strHr + ":" + strMin + ":" + strSec;

                    objTripData.HAULERCONTRACTOR = s.HAULERCONTRACTOR;
                    objTripData.SUPPLIERID = s.SUPPLIERID;
                    objTripData.POLICENO = s.POLICENO;
                    objTripData.STATUS = s.STATUS;
                    if (s.ARRIVALATUKDATETIME != null)
                        objTripData.ARRIVALATUKDATETIME = Convert.ToDateTime(s.ARRIVALATUKDATETIME);
                    if (s.DEPARTUREFROMTUKDATETIME != null)
                        objTripData.DEPARTUREFROMTUKDATETIME = Convert.ToDateTime(s.DEPARTUREFROMTUKDATETIME);
                    objTripData.ESTVOL = s.ESTVOL;
                    objTripData.CONTNAME = s.Name;
                    objTripData.CONTCODE = s.CONT_CODE;
                    //Added By Smrithy 13-11-2015
                    objTripData.TruckDesc = s.TruckDesc;
                    lstTripTicket.Add(objTripData);
                }

            }
            return lstTripTicket;
        }


        #endregion GetTripTicketDetailsBySector

        #region FetchStaticReferenceData
        #region FetchContactorsData
        /// <summary>
        ///  Fetchig all the contractor data
        /// </summary>
        /// <returns></returns>
        public List<clsContactors> FetchContactorsData(string sector)
        {
            List<clsContactors> lstContactors = new List<clsContactors>();
            clsContactors objContractors;

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchContractorData_v2(sector);

                foreach (var s in compData)
                {
                    objContractors = new clsContactors();
                    objContractors.CONTCODE = s.CONT_CODE;
                    // objContractors.CONTTYPE = s.CONT_TYPE;
                    objContractors.NAME = s.NAME;
                    //objContractors.ADDRESS1 = s.ADDRESS1;
                    //objContractors.ADDRESS2 = s.ADDRESS2;
                    //objContractors.POSTBOX = s.POSTBOX;
                    //objContractors.POSTCODE = s.POSTCODE;
                    //objContractors.CITY = s.CITY;
                    //objContractors.STATE = s.CSTATE;
                    //objContractors.TEL = s.TEL;
                    //objContractors.FAX = s.FAX;
                    //objContractors.CONTACT = s.CONTACT;
                    //objContractors.ACTIVE = s.ACTIVE;
                    //objContractors.PCSUSE = s.PCS_USE;
                    //objContractors.SAPCONTCODE = s.SAP_CONT_CODE;
                    //objContractors.WBHAULER = s.WB_HAULER;
                    //objContractors.TAXCODE = s.TAX_CODE;
                    //objContractors.POSTBOX = s.POSTBOX;
                    //objContractors.CRTUSERID = s.CRT_USERID;
                    //objContractors.CRTDATE = Convert.ToDateTime(s.CRT_DATE);
                    //objContractors.MODUSERID = s.MOD_USERID;
                    //objContractors.MODDATE = Convert.ToDateTime(s.MOD_DATE);
                    lstContactors.Add(objContractors);
                }
            }
            return lstContactors;
        }
        #endregion FetchContactorsData

        #region FetchConversionsData
        /// <summary>
        ///  Fetchig all the Conversion data
        /// </summary>
        /// <returns></returns>
        public List<clsConversions> FetchConversionsData(string sector)
        {
            List<clsConversions> lstConversions = new List<clsConversions>();
            clsConversions objConversions;

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                //Conv
                var convData = ctx.SP_Wood_FetchConversionData_v2(sector);
                foreach (var conv in convData)
                {
                    objConversions = new clsConversions();
                    objConversions.CF = conv.CF;
                    objConversions.DESCRIPTION = conv.CONVDESCRIPTION;
                    objConversions.CONVERSION = Convert.ToDecimal(conv.CONVERSION);
                    objConversions.CONVMANID = conv.CONVMANID;
                    objConversions.DEBARKED = conv.DEBARKED;
                    objConversions.CONVACTIVE = conv.CONVACTIVE.Trim();
                    objConversions.CONVCRTUSERID = conv.CONVCRT_USERID;
                    objConversions.CONVCRTDATE = Convert.ToDateTime(conv.CONVCRT_DATE);
                    objConversions.CONVCRTUSERID = conv.CONVMOD_USERID;
                    objConversions.CONVMODDATE = Convert.ToDateTime(conv.CONVMOD_DATE);
                    lstConversions.Add(objConversions);
                }
            }
            return lstConversions;
        }
        #endregion FetchConversionsData

        #region FetchVehicleSwData
        /// <summary>
        ///  Fetchig all the VehicleSVV data
        /// </summary>
        /// <returns></returns>
        public List<clsVehicleSw> FetchVehicleSwData(string sector)
        {
            List<clsVehicleSw> lstVehicleSw = new List<clsVehicleSw>();
            clsVehicleSw objVehicleSw;

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                //Vehicle
                var vehData = ctx.SP_Wood_FetchVehicleData_v2(sector);
                foreach (var veh in vehData)
                {
                    objVehicleSw = new clsVehicleSw();
                    objVehicleSw.TRUCKTYPE = veh.TRUCKTYPE;
                    objVehicleSw.ESTSTACKVOL = veh.EST_STACK_VOL;
                    objVehicleSw.ESTVOL = veh.EST_VOL;
                    objVehicleSw.VEHCRTUSERID = veh.VEHCRT_USERID;
                    objVehicleSw.VEHCRTDATE = Convert.ToDateTime(veh.VEHCRT_DATE);
                    objVehicleSw.VEHCRTUSERID = veh.VEHMOD_USERID;
                    objVehicleSw.VEHMODDATE = Convert.ToDateTime(veh.VEHMOD_DATE);
                    lstVehicleSw.Add(objVehicleSw);
                }
            }
            return lstVehicleSw;
        }
        #endregion FetchVehicleSwData

        #region FetchBargeData
        /// <summary>
        ///  Fetchig all the Barge data
        /// </summary>
        /// <returns></returns>
        public List<clsBarge> FetchBargeData()
        {
            List<clsBarge> lstBarge = new List<clsBarge>();
            clsBarge objBarge;

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                //Barge
                var BarData = ctx.SP_Wood_FetchBargeData();
                foreach (var bar in BarData)
                {
                    objBarge = new clsBarge();
                    objBarge.TYPE = bar.BARGETYPE;
                    objBarge.VOL = Convert.ToDecimal(bar.VOL);
                    objBarge.MANID = bar.BARMAN_ID;
                    objBarge.BARGECRTUSERID = bar.BARCRT_USERID;
                    objBarge.BARGECRTDATE = Convert.ToDateTime(bar.BARCRT_DATE);
                    objBarge.BARGEMODUSERID = bar.BARMOD_USERID;
                    objBarge.BARGEMODDATE = Convert.ToDateTime(bar.BARMOD_DATE);
                    lstBarge.Add(objBarge);
                }
            }
            return lstBarge;
        }
        #endregion FetchBargeData

        #region FetchDepoData
        /// <summary>
        ///  Fetchig all the DEpo data
        /// </summary>
        /// <returns></returns>
        public List<clsDepots> FetchDepoData()
        {
            Log.Writelog("In DL layer Fetching depot data", "WOODSUPPLY");
            List<clsDepots> lstDepots = new List<clsDepots>();
            clsDepots objDepots;

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                //Depot
                try
                {
                    var DepoData = ctx.SP_Wood_FetchDepoData();
                    foreach (var depo in DepoData)
                    {
                        objDepots = new clsDepots();
                        objDepots.DEPOTCODE = depo.DEPOT_CODE;
                        objDepots.SECTOR = depo.SECTOR;
                        objDepots.MILLDIST = Convert.ToDecimal(depo.MILL_DIST);
                        objDepots.DEPODESCRIPTION = depo.DEPODESCRIPTION;
                        lstDepots.Add(objDepots);
                    }
                }
                catch (Exception ex)
                {
                    Log.Writelog(ex.Message, "WOODSUPPLY");
                    Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                }

            }
            return lstDepots;
        }
        #endregion FetchDepoData


        #endregion FetchStaticReferenceData

        #region GetWODetails
        #region GetWODetails
        /// <summary>
        /// Fetching the work order details
        /// </summary>
        /// <returns></returns>
        public List<clsWorkOrder> GetWODetails()
        {

            List<clsWorkOrder> lstWO = new List<clsWorkOrder>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchWODetails("TEE");
                foreach (var s in compData)
                {
                    clsWorkOrder objWOData = new clsWorkOrder();
                    objWOData.WONUMBER = s.WO_NUMBER;
                    objWOData.SECTOR = s.SECTOR;
                    objWOData.ESTATE = s.ESTATE;
                    objWOData.CERTIFICATIONCODE = s.Certification_code;
                    objWOData.NAME = s.NAME;
                    objWOData.CONTCODE = s.CONT_CODE;
                    lstWO.Add(objWOData);
                }

            }
            return lstWO;
        }
        #endregion GetWODetails

        #region GetWODetailsBySector
        /// <summary>
        /// Getting the Work order details by passing sector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsWorkOrder> GetWODetailsBySector(string sector)
        {

            //InsertLogTable("Writing log from GetWODetailsBySector" + DateTime.Now.ToString());
            Log.Writelog(" DL Layer of GetWODetailsBySector", "WOODSUPPLY");

            List<clsWorkOrder> lstWO = new List<clsWorkOrder>();
            try
            {



                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("Accessing the data - SP_Wood_FetchWODetails for sector -- " + sector, "WOODSUPPLY");
                    var compData = ctx.SP_Wood_FetchWODetails(sector);
                    foreach (var s in compData)
                    {
                        clsWorkOrder objWOData = new clsWorkOrder();
                        objWOData.TypeOfWO = s.TypeOfWO;
                        objWOData.WONUMBER = s.WO_NUMBER;
                        objWOData.SECTOR = s.SECTOR;
                        objWOData.ESTATE = s.ESTATE;
                        objWOData.CERTIFICATIONCODE = s.Certification_code;
                        objWOData.NAME = s.NAME;
                        objWOData.CONTCODE = s.CONT_CODE;
                        objWOData.WODATE = s.WO_DATE;
                        objWOData.FOREMANID = s.FOREMAN_ID;
                        objWOData.SPVCODE = s.SPV_CODE;
                        objWOData.COMPNO = s.COMPNO;
                        lstWO.Add(objWOData);
                    }

                }
            }
            catch (Exception ex)
            {
                // InsertLogTable("Writing log from GetWODetailsBySector");
                Log.Writelog(ex.Message, "WOODSUPPLY");

            }
            return lstWO;
        }
        #endregion GetWODetailsBySector
        #endregion GetWODetails

        #region GetLoadingUnloadingWO
        #region GetLoadingWO
        /// <summary>
        /// To fetch all the Loading WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsLoadingWO> GetLoadingWO(string woNumber)
        {
            List<clsLoadingWO> lstLoadData = new List<clsLoadingWO>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchLoadingData(woNumber);
                foreach (var s in compData)
                {
                    clsLoadingWO objLoadData = new clsLoadingWO();
                    objLoadData.WONUMBER = s.WO_NUMBER;
                    objLoadData.JCOC = s.JCOC;
                    objLoadData.SECTOR = s.SECTOR;
                    objLoadData.COMPNO = s.COMP;
                    objLoadData.NAME = s.NAME;
                    objLoadData.CONTCODE = s.CONT_CODE;
                    lstLoadData.Add(objLoadData);
                }

            }
            return lstLoadData;
        }
        #endregion GetLoadingWO

        #region GetUnLoadingWO
        /// <summary>
        /// To fetch all the Unloading WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsUnloadingWO> GetUnLoadingWO(string woNumber)
        {
            List<clsUnloadingWO> lstUnLoadData = new List<clsUnloadingWO>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchUnLoadingData(woNumber);
                foreach (var s in compData)
                {
                    clsUnloadingWO objUnLoadData = new clsUnloadingWO();
                    objUnLoadData.WONUMBER = s.WO_NUMBER;
                    objUnLoadData.JCOC = s.JCOC;
                    objUnLoadData.SECTOR = s.SECTOR;
                    objUnLoadData.COMPNO = s.COMP;
                    objUnLoadData.NAME = s.NAME;
                    objUnLoadData.CONTCODE = s.CONT_CODE;
                    lstUnLoadData.Add(objUnLoadData);
                }

            }
            return lstUnLoadData;
        }
        #endregion GetUnLoadingWO
        #endregion GetLoadingUnloadingWO

        #region GetFellingExtractionWO
        #region GetFellingWO
        /// <summary>
        /// To fetch all the felling WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsFellingData> GetFellingWO(string woNumber)
        {
            List<clsFellingData> lstFellData = new List<clsFellingData>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchFellingData(woNumber);
                foreach (var s in compData)
                {
                    clsFellingData objFellData = new clsFellingData();
                    objFellData.WONUMBER = s.WO_NUMBER;
                    objFellData.JCOC = s.JCOC;
                    objFellData.SECTOR = s.SECTOR;
                    objFellData.COMPNO = s.COMP;
                    objFellData.NAME = s.NAME;
                    objFellData.CONTCODE = s.CONT_CODE;
                    lstFellData.Add(objFellData);
                }

            }
            return lstFellData;
        }
        #endregion GetFellingWO

        #region GetExtractionWO
        /// <summary>
        /// To fetch all the Extraction WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsExtractingData> GetExtractionWO(string woNumber)
        {
            List<clsExtractingData> lstExtractionData = new List<clsExtractingData>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_Wood_FetchExtractingData(woNumber);
                foreach (var s in compData)
                {
                    clsExtractingData objExtractionData = new clsExtractingData();
                    objExtractionData.WONUMBER = s.WO_NUMBER;
                    objExtractionData.JCOC = s.JCOC;
                    objExtractionData.SECTOR = s.SECTOR;
                    objExtractionData.COMPNO = s.COMP;
                    objExtractionData.NAME = s.NAME;
                    objExtractionData.CONTCODE = s.CONT_CODE;
                    lstExtractionData.Add(objExtractionData);
                }

            }
            return lstExtractionData;
        }
        #endregion GetExtractionWO
        #endregion GetFellingExtractionWO

        #region SetArrivedDatetime
        /// <summary>
        /// To update TW_TRIP_TICKET_DATA table with status and arrivedAtUKdatetime
        /// </summary>
        /// <param name="tripTicketNo"></param>
        /// <param name="status"></param>
        /// <param name="arrivedAtUKdatetime"></param>
        /// <returns></returns>
        //public string SetArrivedDatetime(int tripTicketNo, string status, string arrivedAtUKdatetime) //Todo: Guaz: to comment out once db is updated to varchar
        public string SetArrivedDatetime(string tripTicketNo, string status, string arrivedAtUKdatetime, string loadingPoint)
        {
            string str = "SUCCESS";

            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    string strlog = "Calling SP_Wood_SetArriveDateTime_v2 ( '" + tripTicketNo.ToString() + "' , '" + status.ToString() + "' ,'" + arrivedAtUKdatetime.ToString() + "')";
                    Log.Writelog(strlog, "WOODSUPPLY");

                    var s = ctx.SP_Wood_SetArriveDateTime_v2(tripTicketNo, status, arrivedAtUKdatetime, loadingPoint);
                    //foreach (var strcolumn in s)               //Todo: Guaz: to comment out once db is updated to varchar
                    //{
                    //    str = strcolumn.Column1.ToString();
                    //}
                }
            }
            catch (Exception ex)
            {
                str = ex.InnerException.ToString() + ex.Message.ToString();
                Log.Writelog(str, "WOODSUPPLY");
            }
            return str;

        }
        #endregion SetArrivedDatetime

        #region SetLoadedArrivedDatetime
        /// <summary>
        /// To update TW_TRIP_TICKET_DATA table with status and arrivedAtUKdatetime
        /// </summary>
        /// <param name="tripTicketNo"></param>
        /// <param name="status"></param>
        /// <param name="loadedArrivedAtUKdatetime"></param>
        /// <returns></returns>
        //public string SetLoadedArrivedDatetime(int tripTicketNo, string status, string loadedArrivedAtUKdatetime)  //Todo: Guaz: to comment out once db is updated to varchar
        public string SetLoadedArrivedDatetime(string tripTicketNo, string status, string loadedArrivedAtUKdatetime)
        {
            string str = "success";
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    string strlog = "Calling SetLoadedArrivedDatetime_v2 ( '" + tripTicketNo.ToString() + "' , '" + status.ToString() + "' ,'" + loadedArrivedAtUKdatetime.ToString() + "')";
                    Log.Writelog(strlog, "WOODSUPPLY");
                    var s = ctx.SP_WS_SetLoadedArriveDateTime_v2(tripTicketNo, status, loadedArrivedAtUKdatetime);
                }
            }
            catch (Exception ex)
            {
                str = ex.InnerException.ToString() + ex.Message.ToString();
                Log.Writelog(str, "WOODSUPPLY");
            }
            return str;
        }
        #endregion SetLoadedArrivedDatetime

        #region InsertStackWODetails
        /// <summary>
        /// To insert the deatils into Stack tables
        /// </summary>
        /// <param name="lstPlotSurveyTreeList"></param>
        /// <param name="strSave"></param>
        /// <returns></returns>
        /// 


        public ResponseClass InsertStackWODetails(List<clsPCSStack> lstStack, string strSave)
        {
            // public string InsertStackWODetails(List<clsPCSStack> lstStack, string strSave)
            //Application : Woodsupply
            Log.Writelog(" In DL Layer InsertStackWODetails", "WOODSUPPLY");
            string strPCSNO = string.Empty;
            string strStackNO = string.Empty;
            ResponseClass objResponse = new ResponseClass();
            ResponseMessage objResponseMessage = new ResponseMessage();
            try
            {
                if (lstStack.Count == 0)
                {
                    strSave = "PCS number is empty";
                }
                if (lstStack.Count > 0)
                {
                    using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                    {
                        //Transaction
                        using (TransactionScope ts = new TransactionScope())
                        {
                            bool success = false;
                            try
                            {
                                for (int i = 0; i < lstStack.Count; i++)
                                {
                                    Log.Writelog(" Row number " + i.ToString(), "WOODSUPPLY");
                                    strPCSNo = string.Empty;
                                    strStackNO = string.Empty;
                                    TW_PCS_STACK objStack = new TW_PCS_STACK();
                                    // Log.Writelog("L1");
                                    // Log.Writelog(lstStack[i].PCSNO);

                                    objStack.PCS_NO = Convert.ToString(lstStack[i].PCSNO);
                                    strPCSNo = lstStack[i].PCSNO;
                                    Log.Writelog("strPCSNo" + strPCSNo, "WOODSUPPLY");
                                    //Log.Writelog(lstStack[i].STACKNO);
                                    objStack.STACK_NO = Convert.ToInt32(lstStack[i].STACKNO);
                                    Log.Writelog("lstStack[i].STACKNO " + lstStack[i].STACKNO, "WOODSUPPLY");
                                    strStackNO = lstStack[i].STACKNO;

                                    objStack.L = lstStack[i].L;

                                    objStack.H = lstStack[i].H;

                                    objStack.W = lstStack[i].W;
                                    Log.Writelog(" lstStack[i].CF " + lstStack[i].CF, "WOODSUPPLY");
                                    objStack.CF = lstStack[i].CF;

                                    objStack.ProcessDate = DateTime.Now;

                                    ctx.TW_PCS_STACK.Add(objStack);
                                    ctx.SaveChanges();
                                    //Transaction
                                    success = true;
                                    strSave = "Successfully Saved";
                                    Log.Writelog(" Successfully Inserted the data with PCS Number : " + strPCSNo + " Stack number " + strStackNO, "WOODSUPPLY");
                                }

                            }
                            catch (Exception ex)
                            {
                                success = false;
                                Log.Writelog(ex.Message, "WOODSUPPLY");
                                Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                                objResponseMessage.PcsNo = strPCSNo;

                                objResponseMessage.Status = "Error";

                                objResponseMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();

                                objResponse.ResponseMessage = objResponseMessage;
                            }
                            if (success)
                            {
                                ts.Complete();
                                objResponseMessage.PcsNo = strPCSNo;

                                objResponseMessage.Status = "Success";

                                objResponseMessage.ErrorMessage = "";

                                objResponse.ResponseMessage = objResponseMessage;

                            }
                            else
                            {
                                Log.Writelog("The Transaction could not be completed", "WOODSUPPLY");
                                //strSave = "The Transaction could not be completed";
                                objResponseMessage.PcsNo = strPCSNo;

                                objResponseMessage.Status = "Error";

                                objResponseMessage.ErrorMessage = "The Transaction could not be completed";

                                objResponse.ResponseMessage = objResponseMessage;
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "WOODSUPPLY");
                Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");

                //strSave = ex.Message.ToString();
                objResponseMessage.PcsNo = strPCSNo;

                objResponseMessage.Status = "Error";

                objResponseMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();

                objResponse.ResponseMessage = objResponseMessage;

            }

            //return strSave;
            return objResponse;
        }
        #endregion InsertStackWODetails

        #region InsertTransWODetails

        /// <summary>
        /// To insert the pcstrans table
        /// </summary>
        /// <param name="objTrans"></param>
        /// <returns></returns>

        public ResponseClass InsertTransWODetails(clsPCSTrans objTrans)
        {
            //Application : Woodsupply

            ResponseClass objResponse = new ResponseClass();
            ResponseMessage objResponseMessage = new ResponseMessage();
            bool Isduplicatedepot = false;
            string TransDate = string.Empty;
            string strTripTicket = string.Empty;
            Log.Writelog("in DL Layer  InsertTransWODetails", "WOODSUPPLY");
            string strSave = "PCS Number is empty";
            string strPCSNO = string.Empty;
            try
            {
                if (objTrans != null)
                {

                    using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                    {   //pcs number should be the maxiumn pcs number + 1 obtained from the pcs trans table
                        //Transaction

                        using (TransactionScope ts = new TransactionScope())
                        {
                            bool success = false;
                            try
                            {

                                string serialNumber = objTrans.SERIALNO;
                                string depotCode = objTrans.DEPOTCODE;
                                int countrows = 0;
                                var countofrows = ctx.SP_GetCountRows(serialNumber, depotCode);
                                foreach (var s in countofrows)
                                {
                                    countrows = s.COUNTROWS;
                                }

                                //commented the if  condition on 15-oct-2015 as the insert should happen for all the pcstypes

                                if (countrows == 0) //|| (objTrans.PCSTYPE.Trim().ToUpper() == "BR" || objTrans.PCSTYPE.Trim().ToUpper() == "BR1" || objTrans.PCSTYPE.Trim().ToUpper() == "BR2" || objTrans.PCSTYPE.Trim().ToUpper() == "BR3" ))
                                {


                                    try
                                    {



                                        var s = ctx.SP_GetPCSNumber();
                                        foreach (var p in s)
                                        {
                                            strPCSNo = p.ToString();

                                        }


                                    }
                                    catch (Exception ex)
                                    {
                                        Log.Writelog(ex.Message, "WOODSUPPLY");
                                        Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                                    }

                                    Log.Writelog("PCS Number is " + strPCSNo, "WOODSUPPLY");

                                    if (Convert.ToInt32(strPCSNo) > 0)
                                    {
                                        //  Log.Writelog("Processing the insert");

                                        TW_PCS_TRANS objTransDet = new TW_PCS_TRANS();



                                        Log.Writelog("strpcsno is " + strPCSNo, "WOODSUPPLY");
                                        objTransDet.PCS_NO = strPCSNo;


                                        objTransDet.SERIAL_NO = objTrans.SERIALNO;

                                        objTransDet.HAUL_CONT = objTrans.HAULCONT;

                                        objTransDet.REGISTRATION = objTrans.REGISTRATION;

                                        objTransDet.DRIVER = objTrans.DRIVER;


                                        if (objTrans.TRANSDATE != null)
                                        {
                                            if (objTrans.TRANSDATE.Trim().Length > 0)
                                            {

                                                objTransDet.TRANS_DATE = Convert.ToDateTime(objTrans.TRANSDATE);
                                                TransDate = objTrans.TRANSDATE;

                                            }
                                        }

                                        objTransDet.ROAD_NO = objTrans.ROADNO;


                                        objTransDet.LOADER = objTrans.LOADER;

                                        objTransDet.LOAD_CONT = objTrans.LOADCONT;

                                        if (objTrans.LOADSTART != null)
                                        {
                                            if (objTrans.LOADSTART.Trim().Length > 0)
                                            {

                                                objTransDet.LOAD_START = Convert.ToDateTime(objTrans.LOADSTART);

                                            }
                                        }

                                        if (objTrans.LOADSTOP != null)
                                        {
                                            if (objTrans.LOADSTOP.Trim().Length > 0)
                                            {


                                                objTransDet.LOAD_STOP = Convert.ToDateTime(objTrans.LOADSTOP);

                                            }
                                        }


                                        objTransDet.SCALER = objTrans.SCALER;


                                        objTransDet.AGE = objTrans.AGE;


                                        objTransDet.DEPOT_CODE = objTrans.DEPOTCODE;


                                        objTransDet.FAKTUR = objTrans.FAKTUR;


                                        objTransDet.TRIPTICKET = objTrans.TRIPTICKET;
                                        strTripTicket = objTrans.TRIPTICKET;

                                        objTransDet.DEPOT_BLOCK_NO = objTrans.DEPOTBLOCKNO;


                                        objTransDet.MACHINEL_NO = objTrans.MACHINELNO;

                                        if (objTrans.SOLIDVOL != null)
                                        {
                                            if (objTrans.SOLIDVOL.Trim().Length > 0)
                                            {

                                                objTransDet.SOLIDVOL = Convert.ToDecimal(objTrans.SOLIDVOL);
                                            }

                                        }

                                        objTransDet.PCS_TYPE = objTrans.PCSTYPE;


                                        if (objTrans.SOLIDADJ != null)
                                        {
                                            if (objTrans.SOLIDADJ.Trim().Length > 0)
                                            {

                                                objTransDet.SOLID_ADJ = Convert.ToDecimal(objTrans.SOLIDADJ);
                                            }
                                        }



                                        objTransDet.CLOSED = objTrans.CLOSED;

                                        objTransDet.APO_BLOCK_LOC = objTrans.APOBLOCKLOC;



                                        if (objTrans.DATEISSUE != null)
                                        {
                                            if (objTrans.DATEISSUE.Trim().Length > 0)
                                            {

                                                objTransDet.DATE_ISSUE = Convert.ToDateTime(objTrans.DATEISSUE);

                                            }
                                        }


                                        objTransDet.FELL_CONT = objTrans.FELLCONT;


                                        objTransDet.BARGING_CONT = objTrans.BARGINGCONT;


                                        objTransDet.UNLOAD_CONT = objTrans.UNLOADCONT;

                                        if (objTrans.UNLOADEQMTTOT != null)
                                        {
                                            if (objTrans.UNLOADEQMTTOT.Trim().Length > 0)
                                            {

                                                objTransDet.UNLOAD_EQMT_TOT = Convert.ToDecimal(objTrans.UNLOADEQMTTOT);
                                            }
                                        }
                                        if (objTrans.UNLOADSTART != null)
                                        {
                                            if (objTrans.UNLOADSTART.Trim().Length > 0)
                                            {

                                                objTransDet.UNLOAD_START = Convert.ToDateTime(objTrans.UNLOADSTART);

                                            }
                                        }
                                        if (objTrans.UNLOADSTOP != null)
                                        {
                                            if (objTrans.UNLOADSTOP.Trim().Length > 0)
                                            {

                                                objTransDet.UNLOAD_STOP = Convert.ToDateTime(objTrans.UNLOADSTOP);

                                            }
                                        }

                                        objTransDet.EXTRACTION_CONT = objTrans.EXTRACTIONCONT;

                                        if (objTrans.EXTRACTIONEQMTTOT != null)
                                        {
                                            if (objTrans.EXTRACTIONEQMTTOT.Trim().Length > 0)
                                            {

                                                objTransDet.EXTRACTION_EQMT_TOT = Convert.ToDecimal(objTrans.EXTRACTIONEQMTTOT);
                                            }
                                        }


                                        if (objTrans.LOADEQMTTOT != null)
                                        {
                                            if (objTrans.LOADEQMTTOT.Trim().Length > 0)
                                            {

                                                objTransDet.LOAD_EQMT_TOT = Convert.ToDecimal(objTrans.LOADEQMTTOT);
                                            }
                                        }


                                        objTransDet.DEBARKED = objTrans.DEBARKED;


                                        objTransDet.SVV_STACK = objTrans.SVVSTACK;


                                        objTransDet.SVV_VOL = objTrans.SVVVOL;


                                        objTransDet.SVV_TRUCK_TYPE = objTrans.SVVTRUCKTYPE;


                                        objTransDet.SVV_EST_STACK_VOL = objTrans.SVVESTSTACKVOL;


                                        objTransDet.SVV_EST_VOL = objTrans.SVVESTVOL;

                                        if (objTrans.EMPTYDEPART != null)
                                        {
                                            if (objTrans.EMPTYDEPART.Trim().Length > 0)
                                            {

                                                objTransDet.EMPTY_DEPART = Convert.ToDateTime(objTrans.EMPTYDEPART);

                                            }
                                        }

                                        if (objTrans.EMPTYARRIVAL != null)
                                        {
                                            if (objTrans.EMPTYARRIVAL.Trim().Length > 0)
                                            {

                                                objTransDet.EMPTY_ARRIVAL = Convert.ToDateTime(objTrans.EMPTYARRIVAL);

                                            }

                                        }

                                        if (objTrans.EMPTYBARGELOADED != null)
                                        {
                                            if (objTrans.EMPTYBARGELOADED.Trim().Length > 0)
                                            {

                                                objTransDet.EMPTY_BARGE_LOADED = Convert.ToDecimal(objTrans.EMPTYBARGELOADED);

                                            }
                                        }

                                        objTransDet.EMPTY_BARGE_TYPE = "1";
                                        if (objTrans.EMPTYTOTVOL != null)
                                        {
                                            if (objTrans.EMPTYTOTVOL.Trim().Length > 0)
                                            {

                                                objTransDet.EMPTY_TOT_VOL = Convert.ToDecimal(objTrans.EMPTYTOTVOL);

                                            }
                                        }


                                        if (objTrans.EMPTYBARGEEMPTY != null)
                                        {
                                            if (objTrans.EMPTYBARGEEMPTY.Trim().Length > 0)
                                            {

                                                objTransDet.EMPTY_BARGE_EMPTY = Convert.ToDecimal(objTrans.EMPTYBARGEEMPTY);
                                            }
                                        }
                                        if (objTrans.EMPTYBARGEVOL != null)
                                        {
                                            if (objTrans.EMPTYBARGEVOL.Trim().Length > 0)
                                            {

                                                objTransDet.EMPTY_BARGE_VOL = Convert.ToDecimal(objTrans.EMPTYBARGEVOL);
                                            }
                                        }
                                        if (objTrans.LOADEDDEPART != null)
                                        {
                                            if (objTrans.LOADEDDEPART.Trim().Length > 0)
                                            {

                                                objTransDet.LOADED_DEPART = Convert.ToDateTime(objTrans.LOADEDDEPART);

                                            }
                                        }

                                        if (objTrans.LOADEDARRIVAL != null)
                                        {
                                            if (objTrans.LOADEDARRIVAL.Trim().Length > 0)
                                            {

                                                objTransDet.LOADED_ARRIVAL = Convert.ToDateTime(objTrans.LOADEDARRIVAL);

                                            }
                                        }


                                        if (objTrans.LOADEDNOOFBARGE != null)
                                        {
                                            if (objTrans.LOADEDNOOFBARGE.Trim().Length > 0)
                                            {

                                                objTransDet.LOADED_NO_OF_BARGE = Convert.ToDecimal(objTrans.LOADEDNOOFBARGE);
                                            }
                                        }




                                        objTransDet.LOADED_BARGE_TYPE = "1";

                                        if (objTrans.LOADEDTOTVOL != null)
                                        {
                                            if (objTrans.LOADEDTOTVOL.Trim().Length > 0)
                                            {

                                                objTransDet.LOADED_TOT_VOL = Convert.ToDecimal(objTrans.LOADEDTOTVOL);
                                            }
                                        }


                                        if (objTrans.LOADEDBARGEVOL != null)
                                        {
                                            if (objTrans.LOADEDBARGEVOL.Trim().Length > 0)
                                            {

                                                objTransDet.LOADED_BARGE_VOL = Convert.ToDecimal(objTrans.LOADEDBARGEVOL);
                                            }
                                        }


                                        objTransDet.CANAL_NO = objTrans.CANALNO;


                                        objTransDet.TUGBOAT_OPR = objTrans.TUGBOATOPR;


                                        objTransDet.TUGBOAT_ID = objTrans.TUGBOATID;

                                        objTransDet.NOTES = objTrans.NOTES;

                                        if (objTrans.KMIN != null)
                                        {
                                            if (objTrans.KMIN.Trim().Length > 0)
                                            {

                                                objTransDet.KM_IN = Convert.ToDecimal(objTrans.KMIN);
                                            }
                                        }

                                        if (objTrans.KMOUT != null)
                                        {
                                            if (objTrans.KMOUT.Trim().Length > 0)
                                            {

                                                objTransDet.KM_OUT = Convert.ToDecimal(objTrans.KMOUT);
                                            }
                                        }

                                        objTransDet.MACHINEU_NO = objTrans.MACHINEUNO;



                                        objTransDet.CRT_USERID = objTrans.CRTUSERID;

                                        objTransDet.CRT_DATE = DateTime.Now;

                                        // UMA - October 15 2015 - DEFECT 39 , 40

                                        objTransDet.MOD_USERID = objTrans.CRTUSERID;
                                        objTransDet.MOD_DATE = DateTime.Now;

                                        if (objTrans.NETWEIGHT != null)
                                        {
                                            if (objTrans.NETWEIGHT.Trim().Length > 0)
                                            {
                                                //      Log.Writelog(" objTrans.NETWEIGHT " + objTrans.NETWEIGHT);
                                                objTransDet.NET_WEIGHT = Convert.ToDecimal(objTrans.NETWEIGHT);
                                            }
                                        }

                                        objTransDet.DESTINATION = objTrans.DESTINATION;

                                        objTransDet.PORT_ID = objTrans.PORTID;

                                        objTransDet.WO_LOADING = objTrans.WOLOADING;

                                        objTransDet.WO_UNLOAD = objTrans.WOUNLOAD;

                                        objTransDet.WO_EXTRACTION = objTrans.WOEXTRACTION;

                                        objTransDet.WO_FELLING = objTrans.WOFELLING;



                                        objTransDet.WO_LANGSIR = objTrans.WOLANGSIR;


                                        objTransDet.WO = objTrans.WO;

                                        if (objTrans.FELLDATE != null)
                                        {
                                            if (objTrans.FELLDATE.Trim().Length > 0)
                                            {

                                                objTransDet.FELL_DATE = Convert.ToDateTime(objTrans.FELLDATE);
                                            }
                                        }


                                        objTransDet.LANGSIR_CONT = objTrans.LANGSIRCONT;


                                        objTransDet.TICKET_BARGING = objTrans.TICKETBARGING;


                                        objTransDet.FAKTUR_AIR = objTrans.FAKTURAIR;


                                        objTransDet.DIAMETER_TYPE = objTrans.DIAMETERTYPE;



                                        objTransDet.MUATAN_KAYU = objTrans.MUATANKAYU;

                                        objTransDet.DICEK_BY = objTrans.DICEKBY;

                                        if (objTrans.TANGGALDATE != null)
                                        {
                                            if (objTrans.TANGGALDATE.Trim().Length > 0)
                                            {

                                                objTransDet.TANGGAL_DATE = Convert.ToDateTime(objTrans.TANGGALDATE);
                                            }
                                        }


                                        objTransDet.REMARK = objTrans.REMARK;


                                        objTransDet.KEY_IN = "3";

                                        //Added By Smrithy-06-11-2015
                                        if (objTrans.Loadingforeman != null)
                                        {
                                            objTransDet.loading_foreman = objTrans.Loadingforeman;
                                        }
                                        if (objTrans.Checkedbydispatcher != null)
                                        {
                                            objTransDet.checked_by_dispatcher = objTrans.Checkedbydispatcher;
                                        }
                                        if (objTrans.Loadingoperator != null)
                                        {
                                            objTransDet.loading_operator = objTrans.Loadingoperator;
                                        }

                                        try
                                        {
                                            ctx.TW_PCS_TRANS.Add(objTransDet);
                                            ctx.SaveChanges();

                                            success = true;


                                            Log.Writelog("Completed the saving of PCSTrans details with the pcs number" + strPCSNo, "WOODSUPPLY");
                                            try
                                            {
                                                Log.Writelog("updating the transdate in 24 hour format", "WOODSUPPLY");
                                                if (strPCSNo.Trim().Length > 0)
                                                {
                                                    if (TransDate.Trim().Length > 0)
                                                    {
                                                        ctx.SP_UPDATETRANSDATE(strPCSNo, TransDate);
                                                        Log.Writelog("updated transdate " + TransDate + " for pcs " + strPCSNo + " in tw_pcs_trans", "WOODSUPPLY");

                                                    }
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                Log.Writelog(ex.Message, "WOODSUPPLY");
                                                Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                                                success = false;
                                            }

                                            objResponseMessage.PcsNo = strPCSNo;

                                            objResponseMessage.Status = "Success";
                                            objResponseMessage.WO = objTrans.WO;
                                            objResponseMessage.ErrorMessage = "";

                                            objResponse.ResponseMessage = objResponseMessage;



                                            if (strTripTicket.Trim().Length > 0)
                                            {
                                                try
                                                {
                                                    Log.Writelog("Updating tw_trip_ticket_data - " + strTripTicket, "WOODSUPPLY");
                                                    //int tripticketnumber = Convert.ToInt32(strTripTicket.Trim());
                                                    TW_TRIP_TICKET_DATA tobj = ctx.TW_TRIP_TICKET_DATA.First(i => i.STRIPTICKETNO == strTripTicket);

                                                    if (tobj.STRIPTICKETNO != null)
                                                    {
                                                        if (tobj.STRIPTICKETNO.Length > 0)
                                                        {
                                                            tobj.STATUS = "Departed";
                                                            //reduced one hour for JKT time
                                                            DateTime dt = new DateTime();
                                                            DateTime dt2 = new DateTime();
                                                            dt = DateTime.Now;
                                                            dt2 = DateTime.Now;
                                                            dt2 = dt.AddHours(-1);
                                                            tobj.DEPARTUREFROMTUKDATETIME = dt2;
                                                            ctx.SaveChanges();
                                                            Log.Writelog("updated tw_trip_ticket_data - departurefromtukdatetime  with " + dt2.ToString() + " " + " for trip ticket number " + strTripTicket, "WOODSUPPLY");
                                                            success = true;

                                                        }

                                                    }

                                                }
                                                catch (Exception ex)
                                                {
                                                    Log.Writelog("Error setting the status of trip ticket " + strTripTicket, "WOODSUPPLY");
                                                    Log.Writelog(ex.Message, "WOODSUPPLY");
                                                    if (ex.InnerException != null)
                                                    {
                                                        Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                                                    }
                                                    success = false;
                                                }
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            strSave = "0";
                                            Log.Writelog(ex.Message + ex.InnerException.ToString(), "WOODSUPPLY");
                                            success = false;

                                        }




                                    } //pcs number
                                } //this if countrows is 0
                                else
                                {
                                    Isduplicatedepot = true;
                                    objResponseMessage.PcsNo = "";
                                    objResponseMessage.Status = "Error";
                                    objResponseMessage.WO = objTrans.WO;
                                    objResponseMessage.ErrorMessage = "The serial number and depot code should be unique";
                                    objResponse.ResponseMessage = objResponseMessage;
                                    success = false;

                                }
                            }
                            //Transaction
                            catch (Exception ex)
                            {


                                Log.Writelog(ex.Message, "WOODSUPPLY");
                                Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                                success = false;
                            }


                            if (success)
                            {
                                ts.Complete();

                            }
                            else
                            {
                                if (Isduplicatedepot == true)
                                {
                                    Log.Writelog("The serial number and depot code should be unique", "WOODSUPPLY");
                                    objResponseMessage.PcsNo = "";
                                    objResponseMessage.Status = "Error";
                                    objResponseMessage.WO = objTrans.WO;
                                    objResponseMessage.ErrorMessage = "The serial number and depot code should be unique";
                                    objResponse.ResponseMessage = objResponseMessage;
                                }
                                else
                                {
                                    Log.Writelog("The Transaction could not be completed", "WOODSUPPLY");
                                    objResponseMessage.PcsNo = "";
                                    objResponseMessage.Status = "Error";
                                    objResponseMessage.WO = objTrans.WO;
                                    objResponseMessage.ErrorMessage = "The Transaction could not be completed";
                                    objResponse.ResponseMessage = objResponseMessage;
                                }

                            }
                        }
                    }

                }


            }
            catch (Exception ex)
            {
                strSave = "0";
                Log.Writelog(ex.Message, "WOODSUPPLY");
                Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");
                Log.Writelog("PCS number is " + strSave, "WOODSUPPLY");
            }

            return objResponse;
        }
        #endregion InsertTransWODetails

        #region GetRktLicenses
        public List<clsRktLicense> GetRktLicensesBySector(string sector)
        {
            Log.Writelog(" DL Layer of GetRktLicensesBySector", "WOODSUPPLY");
            List<clsRktLicense> lstRktLicense = new List<clsRktLicense>();
            clsRktLicense objRktLicense = new clsRktLicense();
            objRktLicense.RKT_LIC_NO = "- Select -";
            objRktLicense.BLOCK = "";
            lstRktLicense.Add(objRktLicense);
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("Accessing the data - SP_WS_GET_RKT_LICENSES for sector -- " + sector, "WOODSUPPLY");
                    var tempData = ctx.SP_WS_GET_RKT_LICENSES(sector);
                    foreach (var s in tempData)
                    {
                        objRktLicense = new clsRktLicense();
                        objRktLicense.RKT_LIC_NO = s.RKT_LIC_NO;
                        objRktLicense.BLOCK = s.BLOCK;
                        lstRktLicense.Add(objRktLicense);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "WOODSUPPLY");
            }
            return lstRktLicense;
        }
        #endregion GetRktLicenses

        #region GetRoadConditions
        public List<clsRoad> GetRoadConditions()
        {
            Log.Writelog(" DL Layer of GetRoadConditions", "WOODSUPPLY");
            List<clsRoad> lstRoad = new List<clsRoad>();
            clsRoad objRoad = new clsRoad();
            objRoad.ID_ROAD = -1;
            objRoad.ROAD = "- Select -";
            lstRoad.Add(objRoad);

            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("Accessing the data - SP_WS_GET_TWM_ROAD ", "WOODSUPPLY");
                    var tempData = ctx.SP_WS_GET_TWM_ROAD();
                    foreach (var s in tempData)
                    {
                        objRoad = new clsRoad();
                        objRoad.ID_ROAD = s.ID_ROAD;
                        objRoad.ROAD = s.ROAD;
                        lstRoad.Add(objRoad);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "WOODSUPPLY");
            }
            return lstRoad;
        }
        #endregion GetRoadConditions

        #region GetWeather
        public List<clsWeather> GetWeatherConditions()
        {
            Log.Writelog(" DL Layer of GetWeatherConditions", "WOODSUPPLY");
            List<clsWeather> lstWeather = new List<clsWeather>();
            clsWeather objWeather = new clsWeather();
            objWeather.ID_WEATHER = -1;
            objWeather.WEATHER = "- Select -";
            lstWeather.Add(objWeather);
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("Accessing the data - SP_WS_GET_TWM_WEATHER ", "WOODSUPPLY");
                    var tempData = ctx.SP_WS_GET_TWM_WEATHER();
                    foreach (var s in tempData)
                    {
                        objWeather = new clsWeather();
                        objWeather.ID_WEATHER = s.ID_WEATHER;
                        objWeather.WEATHER = s.WEATHER;
                        lstWeather.Add(objWeather);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "WOODSUPPLY");
            }
            return lstWeather;
        }
        #endregion GetWeather

        #region GetTripTicketWithoutLoadedTime
        public List<clsTripTicketNoLoadedTime> GetTripTicketWithoutLoadedTime(String sector)
        {
            Log.Writelog(" DL Layer of GetTripTicketWithoutLoadedTime", "WOODSUPPLY");
            List<clsTripTicketNoLoadedTime> lstTripTicketNoLoadedTime = new List<clsTripTicketNoLoadedTime>();
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("Accessing the data - SP_WS_GET_TRIPTICKET_WITHOUT_LOADEDTIME_v2 sector:" + sector, "WOODSUPPLY");
                    var tempData = ctx.SP_WS_GET_TRIPTICKET_WITHOUT_LOADEDTIME_v2(sector);

                    foreach (var s in tempData)
                    {
                        clsTripTicketNoLoadedTime objTripTicket = new clsTripTicketNoLoadedTime();
                        objTripTicket.TRIPTICKETNO = s.STRIPTICKETNO.ToString();     //Todo: Guaz: to comment out once db is updated to varchar                 

                        Log.Writelog("result: " + s.STRIPTICKETNO.ToString(), "WOODSUPPLY");
                        objTripTicket.TrukType = s.TruckType;
                        objTripTicket.HAULERCONTRACTOR = s.HAULERCONTRACTOR;
                        objTripTicket.POLICENO = s.POLICENO;
                        objTripTicket.ARRIVALATUKDATETIME = Convert.ToDateTime(s.ARRIVALATUKDATETIME);
                        objTripTicket.ESTATE = s.DESTINATIONESTATE;
                        objTripTicket.COMPNO = s.COMPARTMENTNO;
                        if (s.ARRIVALATUKLOADEDDATETIME != null)
                        {
                            Log.Writelog("result: " + s.ARRIVALATUKLOADEDDATETIME.ToString(), "WOODSUPPLY");
                            objTripTicket.LOADEDTIME = s.ARRIVALATUKLOADEDDATETIME.ToString();
                            //objTripTicket.ARRIVALATUKLOADEDDATETIME = Convert.ToDateTime(s.ARRIVALATUKLOADEDDATETIME);
                        }

                        lstTripTicketNoLoadedTime.Add(objTripTicket);
                    }
                    Log.Writelog("Accessing the data - SP_WS_GET_TRIPTICKET_WITHOUT_LOADEDTIME sector:" + sector, "WOODSUPPLY");
                }
            }
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "WOODSUPPLY");
            }
            return lstTripTicketNoLoadedTime;
        }
        #endregion GetTripTicketWithoutLoadedTime

        #region SetLhpStock
        public string SetLhpStock(string sector, string depot, string license, string block, string species,
            int lhp, string createdDateTime, string user, string deviceId)
        {
            string str = "success";
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    var s = ctx.SP_WS_SetLHP(license, depot, createdDateTime, lhp, species, user, deviceId);
                }
            }
            catch (Exception ex)
            {
                str = ex.InnerException.ToString() + ex.Message.ToString();
                Log.Writelog(str, "WOODSUPPLY");
            }
            return str;
        }
        #endregion SetLhpStock

        #region SetEnviromentalValues
        public string SetEnviromentalValues(string sector, string depot, string weather, string road,
            int equipGood, int equipBad, string createdDateTime, string user, string deviceId)
        {
            string str = "success";
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    var s = ctx.SP_WS_SetEvnValues(depot, road, weather, equipGood, equipBad, user, createdDateTime);
                }
            }
            catch (Exception ex)
            {
                str = ex.InnerException.ToString() + ex.Message.ToString();
                Log.Writelog(str, "WOODSUPPLY");
            }
            return str;
        }
        #endregion SetEnviromentalValues

        #region GetArriveNotArrivedata
        /// <summary>
        /// Getting Arrive Not Arrive Data for Truck
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsStockLoading> GetArriveNotArrivedata(string sector)
        {

            //InsertLogTable("Writing log from GetArriveNotArrivedata" + DateTime.Now.ToString());
            Log.Writelog(" DL Layer of GetArriveNotArrivedata", "WOODSUPPLY");

            List<clsStockLoading> lstStock = new List<clsStockLoading>();
            try
            {



                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("Accessing the data - SP_Wood_FetchStockDetails for Stock -- ", "WOODSUPPLY");
                    var stockData = ctx.SP_Wood_FetchStockDetails(sector);
                    foreach (var s in stockData)
                    {
                        clsStockLoading _objStock = new clsStockLoading();
                        _objStock.COMPARTMENT = s.Compartment;
                        _objStock.STOCK = s.Stock;
                        _objStock.TPK = s.Tpk;
                        lstStock.Add(_objStock);
                    }

                }
            }
            catch (Exception ex)
            {
                // InsertLogTable("Writing log from GetArriveNotArrivedata");
                Log.Writelog(ex.Message, "WOODSUPPLY");

            }
            return lstStock;
        }
        #endregion GetArriveNotArrivedata

        #region GetOneDayTripTicketData
        /// <summary>
        /// To fetch all the Unloading WO data from WO_register
        /// </summary>
        /// <param name="Sector"></param>
        /// <returns></returns>
        public List<clsLoadingOneDayTripTicketData> GetOneDayTripTicketData(string Sector)
        {
            List<clsLoadingOneDayTripTicketData> lstLoadData = new List<clsLoadingOneDayTripTicketData>();


            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_FetchTripTicketData_OneDay(Sector);
                foreach (var s in compData)
                {
                    clsLoadingOneDayTripTicketData objLoadData = new clsLoadingOneDayTripTicketData();
                    objLoadData.TRIPTICKETNO = s.TRIPTICKETNO;
                    objLoadData.LOADINGPOINT = s.LOADINGPOINT;
                    objLoadData.STATUS = s.STATUS;
                    lstLoadData.Add(objLoadData);
                }

            }
            return lstLoadData;
        }
        #endregion GetOneDayTripTicketData

        #endregion Wood Supply

        #region UAV
        #region GetEstateForSector
        /// <summary>
        /// GetEstateForSector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsGetEstateForSector> GetEstateForSector(string sector)
        {
            List<clsGetEstateForSector> lsEstate = new List<clsGetEstateForSector>();
            Log.Writelog("in DL layer of GetEstateForSector " + sector, "UAV");
            try
            {

                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    Log.Writelog("calling SP_UAV_GetEstateForSector -- " + sector, "UAV");
                    var compData = ctx.SP_UAV_GetEstateForSector(sector);
                    foreach (var s in compData)
                    {
                        //uma
                        clsGetEstateForSector objEstate = new clsGetEstateForSector();
                        objEstate.Estate = s.ToString();
                        lsEstate.Add(objEstate);
                    }

                }
            }
            catch (Exception ex) { Log.Writelog(ex.Message, "UAV"); }
            return lsEstate;
        }
        #endregion GetEstateForSector

        #region GetCompartmentNoForEstate
        /// <summary>
        /// GetCompartmentNoForEstate
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="estate"></param>
        /// <returns></returns>
        public List<clsGetCompartNoforEstate> GetCompartmentNoForEstate(string sector, string estate)
        {
            Log.Writelog(" In dal layer of GetCompartmentNoForEstate", "UAV");

            List<clsGetCompartNoforEstate> lsCompNo = new List<clsGetCompartNoforEstate>();
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_UAV_GetCompartmentNoForEstate(sector, estate);
                    foreach (var s in compData)
                    {
                        clsGetCompartNoforEstate objComp = new clsGetCompartNoforEstate();
                        objComp.Compartment = s.Compartment;
                        objComp.FEATID = s.FEATID;

                        lsCompNo.Add(objComp);
                    }

                }
            }
            catch (Exception ex) { Log.Writelog(ex.Message, "UAV"); }
            return lsCompNo;
        }
        #endregion GetCompartmentNoForEstate

        #region GetImagesForFlightFilter
        /// <summary>
        /// GetImagesForFlightFilter
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public List<clsUAVFlight> GetImagesForFlightFilter(string featid, DateTime flightStartdate, DateTime flightEnddate)
        {
            List<clsUAVFlight> lstFlight = new List<clsUAVFlight>();
            Log.Writelog("In DAL of GetImagesForFlightFilter featid=" + featid + " flightStartDate=" + flightStartdate + " flightEnddate=" + flightEnddate, "UAV");

            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_UAV_GetImagesForFilter(featid, flightStartdate, flightEnddate);

                    foreach (var s in compData)
                    {
                        clsUAVFlight objFlight = new clsUAVFlight();

                        DateTime dtFlightDate = DateTime.ParseExact(s.FlightDate.ToString(), "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                        DateTime dtEST_DATE = DateTime.ParseExact(s.EST_DATE.ToString(), "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                        string FlightDate = dtFlightDate.ToString("dd/MM/yyyy");
                        string EST_DATE = dtEST_DATE.ToString("dd/MM/yyyy");

                        objFlight.FlightID = s.FlightID;
                        objFlight.Flightdate = FlightDate;
                        objFlight.FEATID = s.FEATID;
                        objFlight.Species = s.Species;
                        objFlight.TreeCount = Convert.ToDecimal(s.Tree_Count);
                        objFlight.AreaSize = Convert.ToDouble(s.AreaSize);
                        objFlight.Stocking = Convert.ToDouble(s.Stocking);
                        objFlight.ProcessedImagePath = s.ProcessedImagePath;
                        objFlight.KMLFilePath = s.KMLFilePath;
                        objFlight.ExecID = s.Exec_ID;
                        objFlight.Starttime = s.Starttime;
                        objFlight.Endtime = s.Endtime;
                        objFlight.ESTDATE = EST_DATE;
                        objFlight.Age = s.Age;
                        objFlight.Contractor = s.Contractor;
                        objFlight.Assisten = s.Assisten;
                        objFlight.SEEDLOTID = s.SEEDLOTID;
                        objFlight.SPACING = Convert.ToDecimal(s.SPACING);
                        objFlight.EastCord = Convert.ToDouble(s.EastCord);
                        objFlight.WestCord = Convert.ToDouble(s.WestCord);
                        objFlight.NorthCord = Convert.ToDouble(s.NorthCord);
                        objFlight.SouthCord = Convert.ToDouble(s.SouthCord);
                        objFlight.ImageType = s.Flight_Type;
                        objFlight.LowTreshold = s.LowTreshold;
                        objFlight.HighTreshold = s.HighTreshold;

                        lstFlight.Add(objFlight);
                    }

                }
            }
            catch (Exception ex) { Log.Writelog(ex.Message, "UAV"); }
            return lstFlight;
        }

        #endregion GetImagesForFlightFilter


        #region GetUAVDensityRefData
        /// <summary>
        /// GetUAVDensityRefData
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public List<clsUAVDensityColorIndex> GetUAVDensityRefData(string featid, DateTime flightStartdate, DateTime flightEnddate)
        {
            List<clsUAVDensityColorIndex> lstDensityColorIndex = new List<clsUAVDensityColorIndex>();
            Log.Writelog(" DAL of GetUAVDensityRefData ", "UAV");
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_UAV_DensityReferenceData(featid, flightStartdate, flightEnddate);
                    foreach (var s in compData)
                    {
                        clsUAVDensityColorIndex objDensity = new clsUAVDensityColorIndex();
                        objDensity.ExecID = s.ExecID;

                        objDensity.IndexValue = s.IndexValue;
                        objDensity.ColorCode = s.ColorCode;
                        objDensity.MeanstockingValue = Convert.ToInt32(s.MeanstockingValue);
                        lstDensityColorIndex.Add(objDensity);
                    }

                }
            }
            catch (Exception ex) { Log.Writelog(ex.Message, "UAV"); }
            return lstDensityColorIndex;
        }
        #endregion GetUAVDensityRefData




        #region GetUAVAlertData
        /// <summary>
        /// GetUAVAlertData
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public List<clsUAVAlert> GetUAVAlertData(string featid, DateTime flightStartdate, DateTime flightEnddate)
        {
            List<clsUAVAlert> lstAlert = new List<clsUAVAlert>();
            Log.Writelog("Alert data", "UAV");
            Log.Writelog("In DAL of GetUAVAlertData featid=" + featid + " flightStartDate=" + flightStartdate + " flightEnddate=" + flightEnddate, "UAV");

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_UAV_GetUAVAlert(featid, flightStartdate, flightEnddate);
                foreach (var s in compData)
                {
                    clsUAVAlert objAlert = new clsUAVAlert();
                    objAlert.AlertID = s.AlertID;
                    objAlert.AlertType = s.AlertType;
                    objAlert.AlertDescription = s.AlertDescription;
                    objAlert.GPSLat = Convert.ToDouble(s.GPSLat);
                    objAlert.GPSLong = Convert.ToDouble(s.GPSLon);
                    objAlert.ExecID = s.ExecID;

                    //added by Ryan
                    objAlert.Featid = s.Featid;
                    objAlert.Status = s.Status;
                    objAlert.Remark = s.Remark;

                    if (s.Start_Date != null)
                    {
                        DateTime dtStart_date = DateTime.ParseExact(s.Start_Date.ToString(), "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                        string startdate = dtStart_date.ToString("yyyy-MM-dd");
                        objAlert.Startdate = startdate;
                    }

                    lstAlert.Add(objAlert);
                }

            }
            return lstAlert;
        }
        #endregion GetUAVAlertData

        #region GetUAVReferenceData
        /// <summary>
        /// GetUAVReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsUAVAlertColorIndex> GetUAVReferenceData()
        {
            List<clsUAVAlertColorIndex> lstAlertColorIndex = new List<clsUAVAlertColorIndex>();
            Log.Writelog(" DAL of GetUAVReferenceData ", "UAV");
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_UAV_GetUAVReferenceData();
                    foreach (var s in compData)
                    {
                        clsUAVAlertColorIndex objAlertFlight = new clsUAVAlertColorIndex();
                        objAlertFlight.AlertCode = s.AlertCode;
                        objAlertFlight.ColorCode = s.ColorCode;
                        objAlertFlight.IndexValue = s.IndexValue;
                        lstAlertColorIndex.Add(objAlertFlight);
                    }

                }
            }
            catch (Exception ex) { Log.Writelog(ex.Message, "UAV"); }
            return lstAlertColorIndex;
        }
        #endregion GetUAVReferenceData

        public List<clsUAVAlertOthers> GetUAVAlertOthersData(string featid)
        {
            List<clsUAVAlertOthers> lstAlert = new List<clsUAVAlertOthers>();
            Log.Writelog("Alert others data", "UAV");
            Log.Writelog("In DAL of GetUAVAlertOthersData featid=" + featid, "UAV");

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var compData = ctx.SP_UAV_GetUAVAlertOthers(featid);
                foreach (var s in compData)
                {
                    clsUAVAlertOthers objAlert = new clsUAVAlertOthers();

                    objAlert.AlertType = s.AlertType;

                    //added by Ryan
                    objAlert.Featid = s.Featid;
                    objAlert.Status = s.Status;
                    objAlert.Remark = s.Remark;
                    objAlert.Age = s.Age;
                    objAlert.Value = s.Value;

                    if (s.Start_Date != null)
                    {
                        DateTime dtStart_date = DateTime.ParseExact(s.Start_Date.ToString(), "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                        string startdate = dtStart_date.ToString("yyyy-MM-dd");
                        objAlert.Startdate = startdate;
                    }


                    lstAlert.Add(objAlert);
                }

            }
            return lstAlert;
        }

        public ResponseClass CloseAlert(clsCloseAlert closeAlert)
        {
            bool success = true;
            ResponseClass obj = new ResponseClass();
            ResponseMessage objResponseMessage = new ResponseMessage();
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    string strlog = "Calling SP_UAV_SetAlert( '" + closeAlert.ToString() + ")";
                    Log.Writelog(strlog, "UAV");


                    using (TransactionScope ts = new TransactionScope())
                    {
                        var s =

                        ctx.SP_UAV_SetAlert
                       (closeAlert.Alert_type, closeAlert.Featid, closeAlert.Start_date
                       , closeAlert.Gps_lat, closeAlert.Gps_lon, closeAlert.Exec_id
                       , closeAlert.Remark, closeAlert.ImageName, closeAlert.Crt_userid, closeAlert.Mod_userid, closeAlert.DeviceID
                       , closeAlert.Status);


                        success = true;
                        foreach (var strcolumn in s)
                        {

                            objResponseMessage.Status = strcolumn.Column1.ToString();
                            objResponseMessage.ErrorMessage = strcolumn.Column2.ToString();
                            //objResponseMessage.Geocode = closeAlert.Gps_lat + " " + closeAlert.Gps_lon;
                            //objResponseMessage.Alerttype = closeAlert.Alert_type;

                        }

                        obj.ResponseMessage = objResponseMessage;
                        if (success) ts.Complete();
                    }


                }

            }
            catch (Exception ex)
            {
                success = false;
                objResponseMessage.ErrorMessage = "";
                objResponseMessage.Status = "error";
                obj.ResponseMessage = objResponseMessage;
                Log.Writelog(ex.Message, "UAV");
                Log.Writelog(ex.InnerException.ToString(), "UAV");
            }



            return obj;

        }
        #endregion UAV

        #region PQA
        #region GetPQAWorkOrders
        /// <summary>
        /// GetPQAWorkOrders
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="dtReqStartDate"></param>
        /// <param name="dtReqEndDate"></param>
        /// <returns></returns>
        public List<clsPQAGetWorkOrders> GetPQAWorkOrders(string sector, DateTime dtReqStartDate, DateTime dtReqEndDate, string deviceID)
        {
            List<clsPQAGetWorkOrders> lsPQAWO = new List<clsPQAGetWorkOrders>();
            try
            {
                //#Guaz - capture the parameters used to query the PQA WO.
                Log.Writelog(deviceID, "GetPQAWorkOrders - SP[SP_PQA_GetWorkOrders]", "PQA");

                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_PQA_GetWorkOrders(sector, dtReqStartDate, dtReqEndDate);

                    int count = 0;
                    foreach (var s in compData)
                    {
                        count++;
                        clsPQAGetWorkOrders objPQAWO = new clsPQAGetWorkOrders();
                        objPQAWO.TypeOfAssessment = s.TypeOfAssessment;
                        objPQAWO.WONUMBER = s.WO_NUMBER;
                        objPQAWO.ESTATE = s.ESTATE;
                        objPQAWO.COMPNO = s.COMPNO;
                        string strYear = s.DateOfIssue.Year.ToString();
                        string strMonth = s.DateOfIssue.Month.ToString();
                        string strDay = s.DateOfIssue.Day.ToString();

                        //objPQAWO.DateOfIssue =   s.DateOfIssue;
                        //objPQAWO.DateOfIssue = strYear + " - " + strMonth + " - " + strDay;
                        objPQAWO.DateOfIssue = strDay + "/" + strMonth + "/" + strYear;
                        //Log.Writelog("printing the data in DL layer - Date of issue is " + s.DateOfIssue.ToString(), "PQA");
                        //Log.Writelog("printing the data in DL layer - objPQAWO.DateOfIssue is " + objPQAWO.DateOfIssue, "PQA");
                        objPQAWO.TOTHA = s.Area;
                        objPQAWO.NAME = s.ContractorName;
                        objPQAWO.SPVCODE = s.PlantationAssistant;
                        objPQAWO.FOREMANID = s.PlantationForeman;
                        objPQAWO.FOREMANNAME = s.FOREMAN_NAME;
                        objPQAWO.SPVNAME = s.SPV_NAME;

                        string strSYear = s.START_DATE.Year.ToString();
                        string strSMonth = s.START_DATE.Month.ToString();
                        string strSDay = s.START_DATE.Day.ToString();

                        objPQAWO.STARTDATE = strSDay + "/" + strSMonth + "/" + strSYear;
                        // Log.Writelog("printing the data in DL layer - start date is " + s.START_DATE.ToString(), "PQA");
                        // Log.Writelog("printing the data in DL layer - objPQAWO.STARTDATE is " + objPQAWO.STARTDATE, "PQA");

                        //Added By Smrithy 04-11-2015-JC/OC
                        objPQAWO.JC = s.JC;
                        objPQAWO.OC = s.OC;
                        objPQAWO.SPECIES = s.SPECIESID;
                        //  Log.Writelog("JC is " + objPQAWO.JC.ToString(), "PQA");
                        //  Log.Writelog("OC is " + objPQAWO.OC.ToString(), "PQA");

                        //Added for Operation Type as Mineral Soil adn Lowland
                        objPQAWO.OperationType = s.OperationType;
                        objPQAWO.WorkOrderSize = s.WorkOrderSize.GetValueOrDefault();

                        lsPQAWO.Add(objPQAWO);
                    }

                    Log.Writelog(deviceID, "GetPQAWorkOrders - Result count: " + count, "PQA");

                }
            }
            catch (Exception ex)
            {
                Log.Writelog(deviceID, "GetPQAWorkOrders - " + ex.Message, "PQA");
                Log.Writelog(deviceID, "GetPQAWorkOrders - " + ex.InnerException.ToString(), "PQA");
            }
            return lsPQAWO;
        }
        #endregion

        public PQAResponseClass SyncPQAData(PQADetail objComp)
        {
            PQAResponseClass objPQAResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                ((IObjectContextAdapter)ctx).ObjectContext.CommandTimeout = 0;
                using (TransactionScope ts = CreateTransactionScope(TimeSpan.FromMinutes(60)))
                {
                    try
                    {
                        if (objComp.CompartmentID.GetValueOrDefault() != Guid.Empty)
                        {
                            var compartment = (from item in ctx.TP_Compartment_Data
                                               where item.CompartmentID == objComp.CompartmentID
                                               select item).FirstOrDefault();

                            if (compartment != null)
                            {
                                ts.Complete();
                                objPQARespMessage.CompSlno = compartment.Comp_Slno.ToString();
                                objPQARespMessage.Status = "Exist";
                                objPQARespMessage.WONUMBER = objComp.WoNumber;
                                objPQARespMessage.ErrorMessage = string.Empty;
                                objPQAResponse.ResponseMessage = objPQARespMessage;
                                return objPQAResponse;
                            }
                        }

                        TP_Compartment_Data objCompData = new TP_Compartment_Data();
                        objCompData.FeatID = objComp.FeatID;
                        objCompData.PlantationSuperindent = objComp.PlantationSuperindent;
                        objCompData.Fertilizer = objComp.Fertilizer;
                        objCompData.OperationType = objComp.OperationType;
                        objCompData.WO_NUMBER = objComp.WoNumber;
                        objCompData.ASSESSORCODE = objComp.AssessorCode;
                        objCompData.TargetSpacing = objComp.TargetSpacing;
                        objCompData.QAPercentage = objComp.QAPercentage;
                        objCompData.SAPID = string.Empty;
                        objCompData.CRT_DATE = DateTime.Now;
                        objCompData.TotalPlotNo = objComp.TotalPlotNo;
                        objCompData.CRT_USERID = objComp.CreatedBy;
                        objCompData.CompartmentID = objComp.CompartmentID;

                        ctx.TP_Compartment_Data.Add(objCompData);
                        ctx.SaveChanges();

                        objComp.CompSlno = (from item in ctx.TP_Compartment_Data
                                            where item.CompartmentID == objComp.CompartmentID
                                            select item.Comp_Slno).FirstOrDefault();

                        try
                        {
                            var details = ctx.SP_FetchQARegisterDetails(objComp.WoNumber, objComp.CompSlno);

                            var detail = details.FirstOrDefault();
                            var qaReg = (from item in ctx.TP_QA_REGISTER
                                         where item.WO_NUMBER == objComp.WoNumber && item.QA_DATE == objComp.QADate &&
                                         item.PAYMENT_NO == detail.PAYMENTNO && item.ASS_TYPE == detail.ASSTYPE
                                         select item).FirstOrDefault();

                            if (qaReg == null)
                            {
                                TP_QA_REGISTER objQARegister = new TP_QA_REGISTER();
                                objQARegister.WO_NUMBER = objComp.WoNumber;
                                objQARegister.TEAM_CODE = objComp.AssessorCode;
                                objQARegister.CRT_DATE = DateTime.Now;
                                objQARegister.CRT_USERID = objComp.CreatedBy;
                                objQARegister.QAPercentage = (objComp.QAPercentage == decimal.Zero) ? null : objComp.QAPercentage;

                                objQARegister.PASSED = objComp.WOStatus;
                                objQARegister.COMP_SLNO = objComp.CompSlno;

                                objQARegister.ENTRY_NO = Convert.ToDecimal(detail.ENTRYNO);
                                objQARegister.ASS_TYPE = detail.ASSTYPE;
                                objQARegister.PAYMENT_NO = detail.PAYMENTNO;
                                objQARegister.MAN_ID = detail.MANID;
                                objQARegister.LOCKED = detail.LOCKED;

                                objQARegister.QA_VALUE = objComp.TotalScore;
                                objQARegister.QA_DATE = objComp.QADate;
                                objQARegister.ETLStatus = null;

                                ctx.TP_QA_REGISTER.Add(objQARegister);
                                ctx.SaveChanges();
                            }
                            else
                            {
                                if (qaReg.COMP_SLNO != objComp.CompSlno)
                                    throw new Exception(qaReg.COMP_SLNO + " is not equal to " + objComp.CompSlno + " for WO Number : " + objComp.WoNumber);
                            }
                            //else
                            //{
                            //    qaReg.WO_NUMBER = objComp.WoNumber;
                            //    qaReg.TEAM_CODE = objComp.AssessorCode;
                            //    qaReg.CRT_DATE = DateTime.Now;
                            //    qaReg.CRT_USERID = objComp.CreatedBy;
                            //    qaReg.QAPercentage = (objComp.QAPercentage == decimal.Zero) ? null : objComp.QAPercentage;

                            //    qaReg.PASSED = objComp.WOStatus;
                            //    qaReg.COMP_SLNO = objComp.CompSlno;

                            //    foreach (var qa in details)
                            //    {
                            //        qaReg.ENTRY_NO = Convert.ToDecimal(qa.ENTRYNO);
                            //        qaReg.ASS_TYPE = qa.ASSTYPE;
                            //        qaReg.PAYMENT_NO = qa.PAYMENTNO;
                            //        qaReg.MAN_ID = qa.MANID;
                            //        qaReg.LOCKED = qa.LOCKED;
                            //    }
                            //    qaReg.QA_VALUE = objComp.TotalScore;
                            //    qaReg.QA_DATE = objComp.QADate;
                            //    qaReg.ETLStatus = "P";

                            //    ctx.SaveChanges();
                            //}
                        }
                        catch (DbEntityValidationException ex)
                        {
                            foreach (var error in ex.EntityValidationErrors)
                            {
                                foreach (var message in error.ValidationErrors)
                                {
                                    Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                        message.PropertyName + " in table " +
                                        "TP_QA_REGISTER", "PQA");
                                }
                            }

                            objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                            objPQARespMessage.Status = "Error";
                            objPQARespMessage.WONUMBER = objComp.WoNumber;
                            objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                            objPQAResponse.ResponseMessage = objPQARespMessage;
                            return objPQAResponse;
                        }
                        catch (Exception ex)
                        {
                            Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                           "TP_QA_REGISTER", "PQA");
                            throw ex;
                        }

                        if (objComp.Scores != null)
                        {
                            foreach (var score in objComp.Scores)
                            {
                                try
                                {
                                    TP_SCORES objScore = new TP_SCORES();

                                    objScore.Comp_Slno = objComp.CompSlno;
                                    objScore.Parameter = score.Parameter;
                                    objScore.Score = score.Score;

                                    ctx.TP_SCORES.Add(objScore);
                                    ctx.SaveChanges();
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "TP_SCORES", "PQA");
                                        }
                                    }

                                    objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = objComp.WoNumber;
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                    return objPQAResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "TP_SCORES", "PQA");
                                    throw ex;
                                }
                            }
                        }

                        if (objComp.PlotDetails != null)
                        {
                            foreach (var plot in objComp.PlotDetails)
                            {
                                try
                                {
                                    TP_Plot_Data objPlotData = new TP_Plot_Data();

                                    objPlotData.Comp_Slno = objComp.CompSlno;
                                    objPlotData.REMARKS = plot.Remarks;
                                    objPlotData.CRT_DATE = DateTime.Now;
                                    objPlotData.PLOTNO = plot.PlotNo;
                                    objPlotData.CRT_USERID = objComp.CreatedBy;
                                    objPlotData.MOD_USERID = objComp.CreatedBy;

                                    ctx.TP_Plot_Data.Add(objPlotData);
                                    ctx.SaveChanges();

                                    plot.PlotSlno = (from item in ctx.TP_Plot_Data
                                                     where item.Comp_Slno == objComp.CompSlno &&
                                                     item.PLOTNO == plot.PlotNo
                                                     select item.Plot_Slno).FirstOrDefault();

                                    if (plot.PlotGpsDetails != null)
                                    {
                                        foreach (var gps in plot.PlotGpsDetails)
                                        {
                                            try
                                            {
                                                TP_Plot_GPS objPlotGPS = new TP_Plot_GPS();

                                                objPlotGPS.Plot_Slno = plot.PlotSlno;
                                                objPlotGPS.tree_row_no = gps.TreeRowNo;
                                                objPlotGPS.GPS_Lat = gps.GpsLatitude;
                                                objPlotGPS.GPS_LONG = gps.GpsLongitude;

                                                ctx.TP_Plot_GPS.Add(objPlotGPS);
                                                ctx.SaveChanges();
                                            }
                                            catch (DbEntityValidationException ex)
                                            {
                                                foreach (var error in ex.EntityValidationErrors)
                                                {
                                                    foreach (var message in error.ValidationErrors)
                                                    {
                                                        Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                            message.PropertyName + " in table " +
                                                            "TP_Plot_GPS", "PQA");
                                                    }
                                                }

                                                objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                                objPQARespMessage.Status = "Error";
                                                objPQARespMessage.WONUMBER = objComp.WoNumber;
                                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                                objPQAResponse.ResponseMessage = objPQARespMessage;
                                                return objPQAResponse;
                                            }
                                            catch (Exception ex)
                                            {
                                                Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "TP_Plot_GPS", "PQA");
                                                throw ex;
                                            }
                                        }
                                    }

                                    if (plot.HoleSizeDetails != null)
                                    {
                                        foreach (var holeSize in plot.HoleSizeDetails)
                                        {
                                            try
                                            {
                                                TP_Plot_HoleSize objHoleSize = new TP_Plot_HoleSize();

                                                objHoleSize.Plot_Slno = plot.PlotSlno;
                                                objHoleSize.Tree_Row_No = holeSize.TreeRowNo;
                                                string status = !string.IsNullOrEmpty(holeSize.TreeNo1) && (holeSize.TreeNo1 == "OK" || holeSize.TreeNo1 == "T") ? "T" : "F";
                                                objHoleSize.Tree_No_1 = status;
                                                status = !string.IsNullOrEmpty(holeSize.TreeNo2) && (holeSize.TreeNo2 == "OK" || holeSize.TreeNo2 == "T") ? "T" : "F";
                                                objHoleSize.Tree_No_2 = status;
                                                status = !string.IsNullOrEmpty(holeSize.TreeNo3) && (holeSize.TreeNo3 == "OK" || holeSize.TreeNo3 == "T") ? "T" : "F";
                                                objHoleSize.Tree_No_3 = status;
                                                status = !string.IsNullOrEmpty(holeSize.TreeNo4) && (holeSize.TreeNo4 == "OK" || holeSize.TreeNo4 == "T") ? "T" : "F";
                                                objHoleSize.Tree_No_4 = status;
                                                status = !string.IsNullOrEmpty(holeSize.TreeNo5) && (holeSize.TreeNo5 == "OK" || holeSize.TreeNo5 == "T") ? "T" : "F";
                                                objHoleSize.Tree_No_5 = status;

                                                ctx.TP_Plot_HoleSize.Add(objHoleSize);
                                                ctx.SaveChanges();
                                            }
                                            catch (DbEntityValidationException ex)
                                            {
                                                foreach (var error in ex.EntityValidationErrors)
                                                {
                                                    foreach (var message in error.ValidationErrors)
                                                    {
                                                        Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                            message.PropertyName + " in table " +
                                                            "TP_Plot_HoleSize", "PQA");
                                                    }
                                                }

                                                objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                                objPQARespMessage.Status = "Error";
                                                objPQARespMessage.WONUMBER = objComp.WoNumber;
                                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                                objPQAResponse.ResponseMessage = objPQARespMessage;
                                                return objPQAResponse;
                                            }
                                            catch (Exception ex)
                                            {
                                                Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "TP_Plot_HoleSize", "PQA");
                                                throw ex;
                                            }
                                        }
                                    }

                                    if (plot.PlotSpaceDetails != null)
                                    {
                                        foreach (var space in plot.PlotSpaceDetails)
                                        {
                                            try
                                            {
                                                TP_Plot_Spacing objPlotSpace = new TP_Plot_Spacing();

                                                objPlotSpace.Plot_Slno = plot.PlotSlno;
                                                objPlotSpace.Tree_Row_No = space.TreeRowNo;
                                                objPlotSpace.BRI = space.BRI;
                                                objPlotSpace.IRI = space.IRI;

                                                ctx.TP_Plot_Spacing.Add(objPlotSpace);
                                                ctx.SaveChanges();
                                            }
                                            catch (DbEntityValidationException ex)
                                            {
                                                foreach (var error in ex.EntityValidationErrors)
                                                {
                                                    foreach (var message in error.ValidationErrors)
                                                    {
                                                        Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                            message.PropertyName + " in table " +
                                                            "TP_Plot_Spacing", "PQA");
                                                    }
                                                }

                                                objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                                objPQARespMessage.Status = "Error";
                                                objPQARespMessage.WONUMBER = objComp.WoNumber;
                                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                                objPQAResponse.ResponseMessage = objPQARespMessage;
                                                return objPQAResponse;
                                            }
                                            catch (Exception ex)
                                            {
                                                Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "TP_Plot_Spacing", "PQA");
                                                throw ex;
                                            }
                                        }
                                    }

                                    if (plot.PlotTreeDetails != null)
                                    {
                                        foreach (var tree in plot.PlotTreeDetails)
                                        {
                                            try
                                            {
                                                TP_Tree_QA_Details objQATree = new TP_Tree_QA_Details();

                                                objQATree.Plot_Slno = plot.PlotSlno;
                                                objQATree.Tree_No = tree.TreeRowNo.ToString();
                                                objQATree.Tree_Row_no = tree.TreeRowNo;
                                                objQATree.PropertyList = tree.PropertyList;
                                                objQATree.SeedLotCodeList = tree.SeedLotCodeList;

                                                try
                                                {
                                                    objQATree.ImageNameList = tree.ImageNameList;

                                                    //Avoid Duplication
                                                    try
                                                    {
                                                        var imageNameList = objQATree.ImageNameList;
                                                        if (imageNameList.Trim().Length > 0)
                                                        {
                                                            string[] strImages = imageNameList.Split(',');
                                                            List<string> strNewImages = new List<string>();
                                                            foreach (var imageName in strImages)
                                                            {
                                                                if (!strNewImages.Contains(imageName))
                                                                {
                                                                    var exists = (from item in ctx.TP_Tree_QA_Details
                                                                                  where item.ImageNameList.Contains(imageName)
                                                                                  select item).Any();

                                                                    if (!exists)
                                                                    {
                                                                        strNewImages.Add(imageName);
                                                                    }
                                                                }
                                                            }

                                                            objQATree.ImageNameList = string.Join(",", strNewImages);
                                                        }
                                                    }
                                                    catch { }
                                                    objQATree.ImageDescription = tree.ImageDescription;
                                                }
                                                catch { }

                                                ctx.TP_Tree_QA_Details.Add(objQATree);
                                                ctx.SaveChanges();
                                            }
                                            catch (DbEntityValidationException ex)
                                            {
                                                foreach (var error in ex.EntityValidationErrors)
                                                {
                                                    foreach (var message in error.ValidationErrors)
                                                    {
                                                        Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                            message.PropertyName + " in table " +
                                                            "TP_Tree_QA_Details", "PQA");
                                                    }
                                                }

                                                objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                                objPQARespMessage.Status = "Error";
                                                objPQARespMessage.WONUMBER = objComp.WoNumber;
                                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                                objPQAResponse.ResponseMessage = objPQARespMessage;
                                                return objPQAResponse;
                                            }
                                            catch (Exception ex)
                                            {
                                                Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "TP_Tree_QA_Details", "PQA");
                                                throw ex;
                                            }
                                        }
                                    }

                                    if (plot.PlotStockingDetails != null)
                                    {
                                        foreach (var stocking in plot.PlotStockingDetails)
                                        {
                                            try
                                            {
                                                TP_Plot_Stocking_Data objStockingData = new TP_Plot_Stocking_Data();

                                                objStockingData.Plot_Slno = plot.PlotSlno;
                                                objStockingData.PlotStockingNo = stocking.PlotStockingNo;
                                                objStockingData.TreeRowNo = stocking.TreeRowNo;
                                                objStockingData.PlotQDR = stocking.Qdr;
                                                objStockingData.PlotLine = stocking.Line;
                                                objStockingData.PlotL = stocking.L;
                                                objStockingData.PlotDA = stocking.DA;
                                                objStockingData.PlotDU = stocking.DU;
                                                objStockingData.PlotVA = stocking.VA;
                                                objStockingData.PlotVU = stocking.VU;
                                                objStockingData.Remarks = stocking.Remarks;

                                                ctx.TP_Plot_Stocking_Data.Add(objStockingData);
                                                ctx.SaveChanges();
                                            }
                                            catch (DbEntityValidationException ex)
                                            {
                                                foreach (var error in ex.EntityValidationErrors)
                                                {
                                                    foreach (var message in error.ValidationErrors)
                                                    {
                                                        Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                            message.PropertyName + " in table " +
                                                            "TP_Plot_Stocking_Data", "PQA");
                                                    }
                                                }

                                                objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                                objPQARespMessage.Status = "Error";
                                                objPQARespMessage.WONUMBER = objComp.WoNumber;
                                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                                objPQAResponse.ResponseMessage = objPQARespMessage;
                                                return objPQAResponse;
                                            }
                                            catch (Exception ex)
                                            {
                                                Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                   "TP_Plot_Stocking_Data", "PQA");
                                                throw ex;
                                            }
                                        }
                                    }
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "TP_Plot_Data", "PQA");
                                        }
                                    }

                                    objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = objComp.WoNumber;
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                    return objPQAResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                "TP_Plot_Data", "PQA");
                                    throw ex;
                                }
                            }
                        }

                        if (objComp.PlotStockingSummaries != null)
                        {
                            foreach (var summary in objComp.PlotStockingSummaries)
                            {
                                try
                                {
                                    TP_Plot_Stocking_Data_Summary objStockingDataSummary = new TP_Plot_Stocking_Data_Summary();

                                    objStockingDataSummary.Comp_Slno = objComp.CompSlno;
                                    objStockingDataSummary.TotalPQAPlot = summary.TotalPQAPlot;
                                    objStockingDataSummary.TotalPQAStocking = summary.TotalPQAStocking;
                                    objStockingDataSummary.PlotSize = summary.PlotSize;
                                    objStockingDataSummary.Spacing = summary.Spacing;
                                    objStockingDataSummary.AverageLive = summary.AverageLive;
                                    objStockingDataSummary.AverageDA = summary.AverageDA;
                                    objStockingDataSummary.AverageDU = summary.AverageDU;
                                    objStockingDataSummary.AverageVA = summary.AverageVA;
                                    objStockingDataSummary.AverageVU = summary.AverageVU;
                                    objStockingDataSummary.DaHa = summary.DAHa;
                                    objStockingDataSummary.DuHa = summary.DUHa;
                                    objStockingDataSummary.DeadPerHa = summary.DeadPerHa;
                                    objStockingDataSummary.VaHa = summary.VAHa;
                                    objStockingDataSummary.VuHa = summary.VUHa;
                                    objStockingDataSummary.VacantPerHa = summary.VacantPerHa;
                                    objStockingDataSummary.InitialPlanting = summary.InitialPlanting;
                                    objStockingDataSummary.IpHa = summary.IPHa;
                                    objStockingDataSummary.LHa = summary.LHa;
                                    objStockingDataSummary.InitialStocking = summary.InitialStocking;
                                    objStockingDataSummary.LiveStocking = summary.LiveStocking;
                                    objStockingDataSummary.KerapatanTitikTanam = summary.PlantingDensity;

                                    ctx.TP_Plot_Stocking_Data_Summary.Add(objStockingDataSummary);
                                    ctx.SaveChanges();
                                }
                                catch (DbEntityValidationException ex)
                                {
                                    foreach (var error in ex.EntityValidationErrors)
                                    {
                                        foreach (var message in error.ValidationErrors)
                                        {
                                            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                                message.PropertyName + " in table " +
                                                "TP_Plot_Stocking_Data_Summary", "PQA");
                                        }
                                    }

                                    objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = objComp.WoNumber;
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                    return objPQAResponse;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog("Error : " + ex.Message + " happened for in table " +
                                                "TP_Plot_Stocking_Data_Summary", "PQA");
                                    throw ex;
                                }
                            }
                        }

                        ts.Complete();

                        //try
                        //{
                        //    var updateETLStatus = ctx.SP_UpdateETLStatus(objComp.CompSlno);
                        //    foreach (var etl in updateETLStatus)
                        //    {
                        //        Log.Writelog("SyncPQAData --  IsUpdated: " + etl.IsUpdated + ", TPCompartmentTotalPlotNo: " + etl.TPCompartmentTotalPlotNo + ", TPPlotDataTotalPlotNo: " + etl.TPPlotDataTotalPlotNo, "PQA");
                        //    }
                        //}
                        //catch (DbEntityValidationException ex)
                        //{
                        //    foreach (var error in ex.EntityValidationErrors)
                        //    {
                        //        foreach (var message in error.ValidationErrors)
                        //        {
                        //            Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                        //                message.PropertyName + " in procedure " +
                        //                "SP_UpdateETLStatus", "PQA");
                        //        }
                        //    }

                        //    objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                        //    objPQARespMessage.Status = "Error";
                        //    objPQARespMessage.WONUMBER = objComp.WoNumber;
                        //    objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                        //    objPQAResponse.ResponseMessage = objPQARespMessage;
                        //    return objPQAResponse;
                        //}
                        //catch (Exception ex)
                        //{
                        //    Log.Writelog("Error : " + ex.Message + " happened for in procedure " +
                        //                "SP_UpdateETLStatus", "PQA");
                        //    throw ex;
                        //}

                        objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                        objPQARespMessage.Status = "Success";
                        objPQARespMessage.WONUMBER = objComp.WoNumber;
                        objPQARespMessage.ErrorMessage = string.Empty;
                    }
                    catch (DbEntityValidationException ex)
                    {
                        foreach (var error in ex.EntityValidationErrors)
                        {
                            foreach (var message in error.ValidationErrors)
                            {
                                Log.Writelog("Error : " + message.ErrorMessage + " happened for " +
                                    message.PropertyName + " in table " +
                                    "TP_Compartment_Data", "PQA");
                            }
                        }

                        objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                        objPQARespMessage.Status = "Error";
                        objPQARespMessage.WONUMBER = objComp.WoNumber;
                        objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                    }
                    catch (Exception ex)
                    {
                        Log.Writelog("Compartment data not saved " + ex.Message, "PQA");
                        Exception temp = ex;
                        while (temp.InnerException != null)
                        {
                            Log.Writelog("Compartment data not saved " + temp.InnerException.Message, "PQA");
                            temp = temp.InnerException;
                        }
                        Log.Writelog("Compartment data not saved " + ex.StackTrace, "PQA");
                        objPQARespMessage.CompSlno = objComp.CompSlno.ToString();
                        objPQARespMessage.Status = "Error";
                        objPQARespMessage.WONUMBER = objComp.WoNumber;
                        objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                    }
                }
            }

            objPQAResponse.ResponseMessage = objPQARespMessage;
            return objPQAResponse;
        }

        #region InsertPQADetails
        /// <summary>
        /// InsertPQADetails
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstScores"></param>
        /// <param name="lstPlotData"></param>
        /// <param name="lstPlotGPS"></param>
        /// <param name="lstHoleSize"></param>
        /// <param name="lstPlotSpace"></param>
        /// <param name="lstTreeQA"></param>
        /// <returns></returns>
        /// 

        public PQAResponseClass InsertPQADetails(clsPQACompartmentData objComp, List<clsScores> lstScores, clsQARegister objQARegdata, string deviceID)
        {
            //Log.Writelog("In InsertPQADetails of Data Layer", "PQA");
            string strSave = string.Empty;
            string QARegWONumber = string.Empty;
            string TotalScore = string.Empty;
            string WOSTATUS = string.Empty;
            string strAssessorcode = string.Empty;
            string struser = string.Empty;
            string sCompSlNo = string.Empty;
            int compslno = 0;

            string strPlotforTree = string.Empty;
            PQAResponseClass objPQAResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();
            string resWO = string.Empty;
            string strQADate = string.Empty;
            bool pkError = false;


            var context = new IFOC_FFE_FAEntities();

            if (objComp.CompSlno != null && objComp.CompSlno != "")
            {
                int csl = Convert.ToInt32(objComp.CompSlno);
                var qData = context.TP_Compartment_Data.Where(x => x.Comp_Slno == csl);
                var data = qData.FirstOrDefault<TP_Compartment_Data>();

                if (data != null)
                {
                    Log.Writelog(deviceID, "WO " + objComp.WONUMBER + " QA Date " + objComp.QADATE + " CompSlNo " + data.Comp_Slno + " is already available in staging database", "PQA");
                    objPQARespMessage.CompSlno = data.Comp_Slno.ToString();
                    objPQARespMessage.Status = "Exist";
                    objPQARespMessage.WONUMBER = objComp.WONUMBER;
                    objPQARespMessage.ErrorMessage = "WO " + objComp.WONUMBER + " QA Date " + objComp.QADATE + " is already available in staging database";
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                    return objPQAResponse;
                }
            }
            else
            {
                System.DateTime qaDate = Convert.ToDateTime(objComp.QADATE);
                var s = context.SP_FetchQARegisterDetails(objComp.WONUMBER, null).FirstOrDefault();
                var qData = context.TP_QA_REGISTER.Where(x => x.WO_NUMBER == objComp.WONUMBER && x.QA_DATE == qaDate && x.ASS_TYPE == s.ASSTYPE && x.PAYMENT_NO == s.PAYMENTNO);
                var data = qData.FirstOrDefault<TP_QA_REGISTER>();

                if (data != null)
                {
                    Log.Writelog(deviceID, "WO " + objComp.WONUMBER + " QA Date " + objComp.QADATE + " CompSlNo " + data.COMP_SLNO + " is already available in staging database", "PQA");
                    objPQARespMessage.CompSlno = data.COMP_SLNO.ToString();
                    objPQARespMessage.Status = "Exist";
                    objPQARespMessage.WONUMBER = objComp.WONUMBER;
                    objPQARespMessage.ErrorMessage = "WO " + objComp.WONUMBER + " QA Date " + objComp.QADATE + " is already available in staging database";
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                    return objPQAResponse;
                }
            }

            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    using (TransactionScope ts = new TransactionScope())
                    {
                        bool success = false;
                        if (objComp != null)
                        {
                            try
                            {
                                strAssessorcode = objComp.AssessorCode;
                                QARegWONumber = objComp.WONUMBER;

                                if (objComp.CRTUSERID != null)
                                {
                                    struser = objComp.CRTUSERID;
                                }

                                TP_Compartment_Data objCompData = new TP_Compartment_Data();
                                objCompData.FeatID = objComp.FeatID;
                                objCompData.PlantationSuperindent = objComp.PlantationSuperindent;
                                objCompData.Fertilizer = objComp.Fertilizer;
                                objCompData.OperationType = objComp.OperationType;
                                objCompData.WO_NUMBER = objComp.WONUMBER;
                                resWO = objComp.WONUMBER;
                                objCompData.ASSESSORCODE = objComp.AssessorCode;
                                objCompData.TargetSpacing = (objComp.TargetSpacing == 0) ? null : objComp.TargetSpacing;
                                objCompData.QAPercentage = (objComp.QAPercentage == decimal.Zero) ? null : objComp.QAPercentage;
                                strAssessorcode = objComp.AssessorCode;
                                //objCompData.SAPID = objComp.SAPID;
                                objCompData.SAPID = string.Empty;
                                objCompData.CRT_DATE = DateTime.Now;
                                objCompData.TotalPlotNo = objComp.TotalPlotNo;

                                QARegWONumber = objComp.WONUMBER;

                                if (objComp.CRTUSERID != null)
                                {
                                    objCompData.CRT_USERID = objComp.CRTUSERID;
                                    struser = objComp.CRTUSERID;
                                }
                                else
                                {
                                    Log.Writelog(deviceID, "NO Comp CRTUSERID", "PQA");
                                }

                                ctx.TP_Compartment_Data.Add(objCompData);
                                ctx.SaveChanges();
                                success = true;
                                int j = objCompData.Comp_Slno;
                                var cSlNo = ctx.TP_Compartment_Data.Max(x => x.Comp_Slno);

                                try
                                {
                                    sCompSlNo = cSlNo.ToString();
                                    compslno = Convert.ToInt32(cSlNo);
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog(ex.Message, "PQA");
                                };

                                Log.Writelog(deviceID, "Saved TP_Compartment_Data - compslno is " + sCompSlNo, "PQA");
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                success = false;
                                objPQARespMessage.CompSlno = objComp.CompSlno;
                                objPQARespMessage.Status = "Error";
                                objPQARespMessage.WONUMBER = resWO;
                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                objPQAResponse.ResponseMessage = objPQARespMessage;
                            }
                        }

                        // Inserting the tp_qa_register
                        if (objQARegdata != null)
                        {
                            try
                            {
                                TotalScore = objQARegdata.TotalScore;
                                WOSTATUS = objQARegdata.WOSTATUS;
                                TP_QA_REGISTER objQARegister = new TP_QA_REGISTER();

                                objQARegister.WO_NUMBER = QARegWONumber;
                                objQARegister.TEAM_CODE = strAssessorcode;
                                objQARegister.CRT_DATE = DateTime.Now;
                                objQARegister.CRT_USERID = struser;
                                objQARegister.QAPercentage = (objComp.QAPercentage == decimal.Zero) ? null : objComp.QAPercentage;

                                objQARegister.PASSED = WOSTATUS;
                                objQARegister.COMP_SLNO = compslno;
                                var s = ctx.SP_FetchQARegisterDetails(QARegWONumber, compslno);
                                foreach (var QA in s)
                                {
                                    objQARegister.ENTRY_NO = Convert.ToDecimal(QA.ENTRYNO);
                                    objQARegister.ASS_TYPE = QA.ASSTYPE;
                                    objQARegister.PAYMENT_NO = QA.PAYMENTNO;
                                    objQARegister.MAN_ID = QA.MANID;
                                    objQARegister.LOCKED = QA.LOCKED;
                                }
                                objQARegister.QA_VALUE = Convert.ToDecimal(TotalScore);
                                objQARegister.QA_DATE = Convert.ToDateTime(objComp.QADATE);
                                objQARegister.ETLStatus = "P";

                                strQADate = objComp.QADATE;

                                ctx.TP_QA_REGISTER.Add(objQARegister);
                                ctx.SaveChanges();
                                success = true;
                                Log.Writelog(deviceID, "Saved TP_QA_REGISTER", "PQA");

                                if (lstScores.Count > 0)
                                {
                                    try
                                    {
                                        for (int i = 0; i < lstScores.Count; i++)
                                        {
                                            TP_SCORES ojScores = new TP_SCORES();
                                            ojScores.Comp_Slno = compslno;
                                            ojScores.Parameter = lstScores[i].Parameter;
                                            ojScores.Score = Convert.ToInt32(lstScores[i].Score);

                                            ctx.TP_SCORES.Add(ojScores);
                                            ctx.SaveChanges();
                                            success = true;
                                            Log.Writelog("Saved TP_SCORES " + " row  " + i.ToString(), "PQA");
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                        Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                        success = false;
                                        strSave = "The Transaction could not be completed";
                                        objPQARespMessage.CompSlno = objComp.CompSlno;
                                        objPQARespMessage.Status = "Exist";
                                        objPQARespMessage.WONUMBER = resWO;
                                        objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                        objPQAResponse.ResponseMessage = objPQARespMessage;
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                success = false;
                                objPQARespMessage.WONUMBER = resWO;
                                objPQARespMessage.CompSlno = objComp.CompSlno;

                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objPQARespMessage.Status = "Exist";
                                    objPQARespMessage.ErrorMessage = " WO " + QARegWONumber.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {
                                        objPQARespMessage.Status = "Exist";
                                        objPQARespMessage.ErrorMessage = " WO " + QARegWONumber.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objPQAResponse.ResponseMessage = objPQARespMessage;
                            }
                        }

                        if (success)
                        {
                            ts.Complete();
                            Log.Writelog(deviceID, "The Transaction completed sucessfully for WO " + QARegWONumber.ToString(), "PQA");
                            objPQARespMessage.CompSlno = sCompSlNo;
                            objPQARespMessage.Status = "Success";
                            objPQARespMessage.WONUMBER = resWO;
                            objPQARespMessage.ErrorMessage = "";
                            objPQAResponse.ResponseMessage = objPQARespMessage;

                        }
                        else
                        {
                            if (pkError == true)
                            {
                                // the error is already set
                            }
                            else
                            {
                                Log.Writelog(deviceID, "The Transaction could not be completed for WO " + QARegWONumber.ToString(), "PQA");
                                objPQARespMessage.CompSlno = sCompSlNo;
                                objPQARespMessage.Status = "Error";
                                objPQARespMessage.WONUMBER = resWO;
                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                objPQAResponse.ResponseMessage = objPQARespMessage;
                            }
                        }
                    }

                }

            }
            catch (Exception ex)
            {
                Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA"); Log.Writelog(ex.InnerException.ToString(), "PQA");
                objPQARespMessage.CompSlno = sCompSlNo;
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = resWO;
                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                objPQAResponse.ResponseMessage = objPQARespMessage;
            }
            return objPQAResponse;
        }
        #endregion InsertPQADetails

        #region InsertPQAPlotDetails
        public PQAPlotResponseClass InsertPQAPlotDetails(List<clsPlotData> lstPlotData, List<clsPlotGPS> lstPlotGPS, List<clsPlotHoleSize> lstHoleSize, List<clsPlotSpace> lstPlotSpace, List<clsTreeQADetails> lstTreeQA, string compSlNo, string deviceID)
        {
            //Log.Writelog("In InsertPQAPlotDetails of Data Layer", "PQA");

            PQAPlotResponseClass objPQAResponse = new PQAPlotResponseClass();
            PQAPlotResponseMessage objPQARespMessage = new PQAPlotResponseMessage();
            TP_Compartment_Data CompartmentData = new TP_Compartment_Data();

            string strSave = string.Empty;
            string QARegWONumber = string.Empty;
            string TotalScore = string.Empty;
            string WOSTATUS = string.Empty;
            string strAssessorcode = string.Empty;
            string struser = string.Empty;
            string strPlotforTree = string.Empty;
            string resWO = string.Empty;
            string strQADate = string.Empty;
            bool pkError = false;
            bool success = false;
            int comp_Slno = 0;
            string qaPlotSlNo = string.Empty;

            if (compSlNo != String.Empty && compSlNo != "null")
            {
                comp_Slno = Convert.ToInt32(compSlNo);

                var context = new IFOC_FFE_FAEntities();
                var qCompartmentData = context.TP_Compartment_Data.Where(x => x.Comp_Slno == comp_Slno);
                CompartmentData = qCompartmentData.FirstOrDefault<TP_Compartment_Data>();

                if (CompartmentData == null)
                {
                    Log.Writelog(deviceID, "Invalid Compartment Serial Number --" + comp_Slno, "PQA");
                    success = false;
                    objPQARespMessage.CompSlno = compSlNo;
                    objPQARespMessage.Status = "Error";
                    objPQARespMessage.WONUMBER = "";
                    objPQARespMessage.ErrorMessage = "Invalid Compartment Serial Number";
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                    return objPQAResponse;
                }
                var plotNo = lstPlotData[0].PLOTNO;

                var qPlotData = context.TP_Plot_Data.Where(x => x.Comp_Slno == comp_Slno && x.PLOTNO == plotNo);
                var plotData = qPlotData.FirstOrDefault<TP_Plot_Data>();

                if (plotData != null)
                {
                    Log.Writelog(deviceID, "PlotNo " + plotNo + " Compartment SLNO " + comp_Slno + " is already available in staging database", "PQA");
                    success = false;
                    objPQARespMessage.CompSlno = compSlNo;
                    objPQARespMessage.Status = "Exist";
                    objPQARespMessage.WONUMBER = "";
                    objPQARespMessage.ErrorMessage = "PlotNo " + lstPlotData[0].PLOTNO + " Compartment SLNO " + comp_Slno + " is already available in staging database";
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                    return objPQAResponse;
                }
            }
            else
            {
                Log.Writelog(deviceID, "The Compartment Serial No is empty", "PQA");
                success = false;
                objPQARespMessage.CompSlno = compSlNo;
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = "";
                objPQARespMessage.ErrorMessage = "The Compartment Serial No is empty";
                objPQAResponse.ResponseMessage = objPQARespMessage;
                return objPQAResponse;
            }


            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    using (TransactionScope ts = new TransactionScope())
                    {
                        success = false;
                        QARegWONumber = CompartmentData.WO_NUMBER;
                        if (lstPlotData.Count > 0)
                        {
                            try
                            {
                                for (int j = 0; j < lstPlotData.Count; j++)
                                {
                                    TP_Plot_Data objPlotData = new TP_Plot_Data();

                                    objPlotData.Comp_Slno = comp_Slno;
                                    objPlotData.REMARKS = lstPlotData[j].REMARKS;
                                    objPlotData.CRT_DATE = DateTime.Now;

                                    if (lstPlotData[j].PLOTNO != null)
                                    {
                                        objPlotData.PLOTNO = lstPlotData[j].PLOTNO;
                                        strPlotforTree = lstPlotData[j].PLOTNO;
                                    }
                                    else
                                    {
                                        Log.Writelog(deviceID, " Comp PLOTNO null", "PQA");
                                    }

                                    if (lstPlotData[j].PDCRTUSERID != null)
                                    {
                                        if (lstPlotData[j].PDCRTUSERID.Trim().Length == 0)
                                        {
                                            objPlotData.CRT_USERID = CompartmentData.CRT_USERID;
                                        }
                                        else
                                        {
                                            objPlotData.CRT_USERID = lstPlotData[j].PDCRTUSERID;
                                        }
                                    }
                                    else
                                    {
                                        Log.Writelog(deviceID, "NO PLot User", "PQA");
                                    }

                                    if (lstPlotData[j].PDMODUSERID != null)
                                    {
                                        objPlotData.MOD_USERID = lstPlotData[j].PDMODUSERID;
                                    }
                                    else
                                    {
                                        Log.Writelog(deviceID, "NO PLot PDMODUSERID", "PQA");
                                    }

                                    Log.Writelog(deviceID, "Writing TP_plot_data", "PQA");
                                    ctx.TP_Plot_Data.Add(objPlotData);
                                    ctx.SaveChanges();
                                    success = true;

                                    //fetching Plot_Slno from TP_Plot_Data
                                    int plotSlNo = 0;
                                    var sPlotNO = ctx.TP_Plot_Data.Where(x => x.Comp_Slno == objPlotData.Comp_Slno).Max(x => x.Plot_Slno);
                                    plotSlNo = Convert.ToInt32(sPlotNO);
                                    qaPlotSlNo = sPlotNO.ToString();
                                    Log.Writelog(deviceID, "converting plotslno to int " + plotSlNo.ToString(), "PQA");

                                    if (lstPlotGPS.Count > 0)
                                    {
                                        try
                                        {
                                            Log.Writelog(deviceID, "writing lstplotgps", "PQA");
                                            var s = from PlotGPS in lstPlotGPS
                                                    where PlotGPS.PlotNo.Contains(strPlotforTree)
                                                    select PlotGPS;

                                            List<clsPlotGPS> lstPlotGPSDet = s.ToList<clsPlotGPS>();

                                            for (int k = 0; k < lstPlotGPSDet.Count; k++)
                                            {
                                                int findTreeRow = Convert.ToInt32(lstPlotGPSDet[k].Treerowno);
                                                if (findTreeRow > 0)
                                                {
                                                    if (findTreeRow == lstPlotGPS.Count && findTreeRow > 1)
                                                    {
                                                        TP_Plot_GPS objPlotGPS = new TP_Plot_GPS();

                                                        objPlotGPS.Plot_Slno = plotSlNo;
                                                        objPlotGPS.tree_row_no = findTreeRow;
                                                        objPlotGPS.GPS_Lat = Convert.ToDecimal(lstPlotGPSDet[k - 1].GPSLat);
                                                        objPlotGPS.GPS_LONG = Convert.ToDecimal(lstPlotGPSDet[k - 1].GPSLONG);

                                                        ctx.TP_Plot_GPS.Add(objPlotGPS);
                                                        ctx.SaveChanges();
                                                        Log.Writelog(deviceID, "saved TP_Plot_GPS - row " + k.ToString(), "PQA");
                                                        objPlotGPS = null;
                                                    }
                                                    else
                                                    {
                                                        TP_Plot_GPS objPlotGPS = new TP_Plot_GPS();

                                                        objPlotGPS.Plot_Slno = plotSlNo;
                                                        objPlotGPS.tree_row_no = Convert.ToInt32(lstPlotGPSDet[k].Treerowno);
                                                        objPlotGPS.GPS_Lat = Convert.ToDecimal(lstPlotGPSDet[k].GPSLat);
                                                        objPlotGPS.GPS_LONG = Convert.ToDecimal(lstPlotGPSDet[k].GPSLONG);

                                                        ctx.TP_Plot_GPS.Add(objPlotGPS);
                                                        ctx.SaveChanges();
                                                        success = true;
                                                        objPlotGPS = null;
                                                    }
                                                }
                                            }
                                            Log.Writelog(deviceID, "saved TP_Plot_GPS  ", "PQA");
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                            success = false;
                                            objPQARespMessage.CompSlno = compSlNo;
                                            objPQARespMessage.Status = "Error";
                                            objPQARespMessage.WONUMBER = resWO;
                                            objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                            objPQAResponse.ResponseMessage = objPQARespMessage;
                                        }

                                    }

                                    if (lstHoleSize.Count > 0)
                                    {
                                        try
                                        {
                                            var s = from HoleSize in lstHoleSize
                                                    where HoleSize.PlotNo.Contains(strPlotforTree)
                                                    select HoleSize;

                                            List<clsPlotHoleSize> lstHoleSizeDet = s.ToList<clsPlotHoleSize>();

                                            for (int l = 0; l < lstHoleSizeDet.Count; l++)
                                            {
                                                TP_Plot_HoleSize objHoleSize = new TP_Plot_HoleSize();
                                                objHoleSize.Plot_Slno = plotSlNo;
                                                string strTreeRowno = lstHoleSizeDet[l].TreeRowNo;
                                                if (strTreeRowno.Trim().Length > 0)
                                                {
                                                    int findRow = Convert.ToInt32(lstHoleSizeDet[l].TreeRowNo);
                                                    if (findRow > 0)
                                                    {
                                                        objHoleSize.Tree_Row_No = Convert.ToInt32(lstHoleSizeDet[l].TreeRowNo);

                                                        objHoleSize.Tree_No_1 = lstHoleSizeDet[l].TreeNo1;
                                                        objHoleSize.Tree_No_2 = lstHoleSizeDet[l].TreeNo2;
                                                        objHoleSize.Tree_No_3 = lstHoleSizeDet[l].TreeNo3;
                                                        objHoleSize.Tree_No_4 = lstHoleSizeDet[l].TreeNo4;
                                                        objHoleSize.Tree_No_5 = lstHoleSizeDet[l].TreeNo5;
                                                        ctx.TP_Plot_HoleSize.Add(objHoleSize);
                                                        ctx.SaveChanges();
                                                        success = true;
                                                    }
                                                }
                                                objHoleSize = null;
                                            }
                                            Log.Writelog(deviceID, "saved TP_Plot_holesize  ", "PQA");
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                            success = false;
                                            objPQARespMessage.CompSlno = compSlNo;
                                            objPQARespMessage.Status = "Error";
                                            objPQARespMessage.WONUMBER = resWO;
                                            objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                            objPQAResponse.ResponseMessage = objPQARespMessage;
                                        }
                                    }

                                    string strPlotSpaceTreeno = "25";
                                    if (lstPlotSpace.Count > 0)
                                    {
                                        try
                                        {
                                            var s = from PlotSpace in lstPlotSpace
                                                    where PlotSpace.PlotNo.Contains(strPlotforTree)
                                                    select PlotSpace;

                                            List<clsPlotSpace> lstPlotSpaceDet = s.ToList<clsPlotSpace>();
                                            for (int m = 0; m < lstPlotSpaceDet.Count; m++)
                                            {
                                                TP_Plot_Spacing objPlotSpace = new TP_Plot_Spacing();
                                                objPlotSpace.Plot_Slno = plotSlNo;
                                                strPlotSpaceTreeno = lstPlotSpaceDet[m].TreeRowNo;

                                                if (strPlotSpaceTreeno.Trim().Length > 0)
                                                {
                                                    int findTreeRowNo = Convert.ToInt32(strPlotSpaceTreeno.Trim());
                                                    if (findTreeRowNo > 0)
                                                    {
                                                        try
                                                        {
                                                            objPlotSpace.Tree_Row_No = Convert.ToInt32(lstPlotSpaceDet[m].TreeRowNo);
                                                            objPlotSpace.BRI = Convert.ToDecimal(lstPlotSpaceDet[m].BRI);
                                                            objPlotSpace.IRI = Convert.ToDecimal(lstPlotSpaceDet[m].IRI);
                                                            ctx.TP_Plot_Spacing.Add(objPlotSpace);
                                                            ctx.SaveChanges();
                                                            success = true;
                                                        }
                                                        catch (Exception ex) { Log.Writelog(ex.Message, "PQA"); }
                                                    }
                                                }
                                                objPlotSpace = null;
                                            }
                                            Log.Writelog(deviceID, "saved TP_Plot_Spacing  ", "PQA");
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                            success = false;
                                            objPQARespMessage.CompSlno = compSlNo;
                                            objPQARespMessage.Status = "Error";
                                            objPQARespMessage.WONUMBER = resWO;
                                            objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                            objPQAResponse.ResponseMessage = objPQARespMessage;
                                        }
                                    }

                                    if (lstTreeQA.Count > 0)
                                    {
                                        try
                                        {
                                            var s = from TreeQA in lstTreeQA
                                                    where TreeQA.PlotNo.Contains(strPlotforTree)
                                                    select TreeQA;

                                            List<clsTreeQADetails> lstTreeQADet = s.ToList<clsTreeQADetails>();
                                            for (int n = 0; n < lstTreeQADet.Count; n++)
                                            {
                                                TP_Tree_QA_Details objQATree = new TP_Tree_QA_Details();
                                                objQATree.Plot_Slno = plotSlNo;
                                                if (lstTreeQA[n].TreeNo != null)
                                                {
                                                    objQATree.Tree_No = lstTreeQADet[n].TreeNo;
                                                }
                                                else
                                                {
                                                    Log.Writelog(deviceID, "TreeNo null", "PQA");
                                                }
                                                objQATree.Tree_Row_no = Convert.ToInt32(lstTreeQADet[n].TreeRowno);
                                                objQATree.PropertyList = lstTreeQADet[n].PropertyList;
                                                //Tree SeedLotCode. Added by soumitri on 17-07-2018.
                                                objQATree.SeedLotCodeList = lstTreeQADet[n].SeedLotCodeList;
                                                try
                                                {
                                                    objQATree.ImageNameList = lstTreeQADet[n].ImageNameList;

                                                    //Avoid Duplication
                                                    try
                                                    {
                                                        var imageNameList = objQATree.ImageNameList;
                                                        if (imageNameList.Trim().Length > 0)
                                                        {
                                                            string[] strImages = imageNameList.Split(',');
                                                            List<string> strNewImages = new List<string>();
                                                            foreach (var imageName in strImages)
                                                            {
                                                                if (!strNewImages.Contains(imageName))
                                                                {
                                                                    var exists = (from item in ctx.TP_Tree_QA_Details
                                                                                  where item.ImageNameList.Contains(imageName)
                                                                                  select item).Any();

                                                                    if (!exists)
                                                                    {
                                                                        strNewImages.Add(imageName);
                                                                    }
                                                                    else
                                                                    {
                                                                        //Log Duplicate File. Added by soumitri.                                                    
                                                                        Log.Writelog(deviceID, "Record Duiplication Image Starts.", "PQA");
                                                                        Log.Writelog(deviceID, imageName, "PQA");
                                                                    }
                                                                }
                                                            }

                                                            objQATree.ImageNameList = string.Join(",", strNewImages);
                                                        }
                                                    }
                                                    catch { }


                                                    objQATree.ImageDescription = lstTreeQADet[n].ImageDescription;
                                                }
                                                catch (Exception ex)
                                                {
                                                    Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                                }
                                                ctx.TP_Tree_QA_Details.Add(objQATree);
                                                ctx.SaveChanges();
                                                success = true;
                                                objQATree = null;
                                            }
                                            Log.Writelog(deviceID, "saved TP_Tree_QA_Details  ", "PQA");
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                            success = false;
                                            objPQARespMessage.CompSlno = compSlNo;
                                            objPQARespMessage.Status = "Error";
                                            objPQARespMessage.WONUMBER = resWO;

                                            if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                            {
                                                objPQARespMessage.ErrorMessage = " WO " + QARegWONumber.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                                pkError = true;
                                            }
                                            else if (ex.Message.ToLower().Contains("inner exception"))
                                            {
                                                if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                                {
                                                    objPQARespMessage.ErrorMessage = " WO " + QARegWONumber.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                                    pkError = true;
                                                }
                                            }
                                            else
                                            {
                                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                            }
                                            objPQAResponse.ResponseMessage = objPQARespMessage;
                                        }
                                    }
                                }

                                try
                                {
                                    var updateETLStatus = ctx.SP_UpdateETLStatus(comp_Slno);
                                    foreach (var etl in updateETLStatus)
                                    {
                                        success = true;
                                        Log.Writelog(deviceID, "InsertPQAPlotDetails --  IsUpdated: " + etl.IsUpdated + ", TPCompartmentTotalPlotNo: " + etl.TPCompartmentTotalPlotNo + ", TPPlotDataTotalPlotNo: " + etl.TPPlotDataTotalPlotNo, "PQA");
                                    }
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                    Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                    success = false;
                                    objPQARespMessage.CompSlno = compSlNo;
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = resWO;
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                }
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "PQA");
                                success = false;
                                objPQARespMessage.CompSlno = compSlNo;
                                objPQARespMessage.Status = "Error";
                                objPQARespMessage.WONUMBER = resWO;

                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objPQARespMessage.ErrorMessage = " WO " + QARegWONumber.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {
                                        objPQARespMessage.ErrorMessage = " WO " + QARegWONumber.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objPQAResponse.ResponseMessage = objPQARespMessage;
                            }
                        }

                        if (success)
                        {
                            ts.Complete();
                            Log.Writelog(deviceID, "The Transaction completed sucessfully for WO " + QARegWONumber.ToString(), "PQA");
                            objPQARespMessage.CompSlno = compSlNo;
                            objPQARespMessage.PlotSlno = qaPlotSlNo.ToString();
                            objPQARespMessage.Status = "Success";
                            objPQARespMessage.WONUMBER = QARegWONumber;
                            objPQARespMessage.ErrorMessage = "";
                            objPQAResponse.ResponseMessage = objPQARespMessage;

                        }
                        else
                        {
                            if (pkError == true)
                            {
                                // the error is already set
                            }
                            else
                            {
                                Log.Writelog(deviceID, "The Transaction could not be completed for WO " + QARegWONumber.ToString(), "PQA");
                                objPQARespMessage.CompSlno = compSlNo;
                                objPQARespMessage.Status = "Error";
                                objPQARespMessage.WONUMBER = resWO;
                                objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                objPQAResponse.ResponseMessage = objPQARespMessage;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog(deviceID, "The error is for work order number  " + QARegWONumber.ToString() + "  " + ex.Message, "PQA"); Log.Writelog(ex.InnerException.ToString(), "PQA");
                objPQARespMessage.CompSlno = compSlNo;
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = resWO;
                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                objPQAResponse.ResponseMessage = objPQARespMessage;
            }

            return objPQAResponse;
        }


        #endregion InsertPQADetails

        #region InsertPQAStocking
        /// <summary>
        /// InsertPQAStocking
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstScores"></param>
        /// <param name="lstPlotData"></param>
        /// <param name="lstPlotGPS"></param>
        /// <param name="lstHoleSize"></param>
        /// <param name="lstPlotSpace"></param>
        /// <param name="lstTreeQA"></param>
        /// <returns></returns>
        /// 

        public PQAResponseClass InsertPQAStocking(List<clsPQAStockingData> lstTreeStocking, string compSlNo)
        {
            //Log.Writelog("In InsertPQAStocking of Data Layer", "PQA");
            string strSave = string.Empty;
            string QARegWONumber = string.Empty;
            string TotalScore = string.Empty;
            string WOSTATUS = string.Empty;
            string strAssessorcode = string.Empty;
            string struser = string.Empty;
            string sCompSlNo = string.Empty;

            string strPlotforTree = string.Empty;
            PQAResponseClass objPQAResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();
            string resWO = string.Empty;
            string strQADate = string.Empty;
            bool pkError = false;
            bool success = false;
            int comp_Slno = 0;
            TP_Compartment_Data CompartmentData = new TP_Compartment_Data();

            if (compSlNo != String.Empty && compSlNo != "null")
            {
                comp_Slno = Convert.ToInt32(compSlNo);
                //var context = new IFOC_FFE_FAEntities();

                //var qCompartmentData = context.TP_Compartment_Data.Where(x => x.Comp_Slno == comp_Slno);
                //CompartmentData = qCompartmentData.FirstOrDefault<TP_Compartment_Data>();

                //if (CompartmentData == null)
                //{
                //    success = false;
                //    objPQARespMessage.CompSlno = compSlNo;
                //    objPQARespMessage.Status = "Error";
                //    objPQARespMessage.WONUMBER = "";
                //    objPQARespMessage.ErrorMessage = "Invalid Compartment Serial Number";
                //    objPQAResponse.ResponseMessage = objPQARespMessage;
                //    return objPQAResponse;
                //}                
            }
            else
            {
                success = false;
                objPQARespMessage.CompSlno = compSlNo;
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = "";
                objPQARespMessage.ErrorMessage = "The Compartment Serial No is empty";
                objPQAResponse.ResponseMessage = objPQARespMessage;
                return objPQAResponse;
            }

            if (lstTreeStocking.Count > 0)
            {
                try
                {
                    using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                    {
                        using (TransactionScope ts = new TransactionScope())
                        {
                            for (int i = 0; i < lstTreeStocking.Count; i++)
                            {
                                string _plotNO = lstTreeStocking[i].PlotNo.ToString();
                                TP_Plot_Data PlotData = new TP_Plot_Data();
                                var qPlotData = ctx.TP_Plot_Data.Where(x => x.Comp_Slno == comp_Slno && x.PLOTNO == _plotNO);
                                PlotData = qPlotData.FirstOrDefault<TP_Plot_Data>();

                                if (PlotData != null)
                                {
                                    TP_Plot_Stocking_Data objStockingData = new TP_Plot_Stocking_Data();
                                    objStockingData.Plot_Slno = PlotData.Plot_Slno;
                                    objStockingData.PlotStockingNo = lstTreeStocking[i].PlotStockingNo;
                                    objStockingData.TreeRowNo = lstTreeStocking[i].TreePlotNo;
                                    objStockingData.PlotQDR = lstTreeStocking[i].PlotQdr;
                                    objStockingData.PlotLine = lstTreeStocking[i].PlotLine;
                                    objStockingData.PlotL = lstTreeStocking[i].PlotL;
                                    objStockingData.PlotDA = lstTreeStocking[i].PlotDA;
                                    objStockingData.PlotDU = lstTreeStocking[i].PlotDU;
                                    objStockingData.PlotVA = lstTreeStocking[i].PlotVA;
                                    objStockingData.PlotVU = lstTreeStocking[i].PlotVU;
                                    objStockingData.Remarks = lstTreeStocking[i].Remarks;

                                    ctx.TP_Plot_Stocking_Data.Add(objStockingData);
                                    ctx.SaveChanges();
                                    success = true;
                                }
                                else
                                {
                                    success = false;
                                    objPQARespMessage.CompSlno = compSlNo;
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = "";
                                    objPQARespMessage.ErrorMessage = "Invalid Plot Serial Number";
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                    return objPQAResponse;
                                }
                            }

                            if (success)
                            {
                                ts.Complete();
                                objPQARespMessage.CompSlno = sCompSlNo;
                                objPQARespMessage.Status = "Success";
                                objPQARespMessage.WONUMBER = resWO;
                                objPQARespMessage.ErrorMessage = "";
                                objPQAResponse.ResponseMessage = objPQARespMessage;

                            }
                            else
                            {
                                if (pkError == true)
                                {
                                    // the error is already set
                                }
                                else
                                {
                                    objPQARespMessage.CompSlno = sCompSlNo;
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = resWO;
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    strSave = "The Transaction could not be completed";
                    objPQARespMessage.CompSlno = "";
                    objPQARespMessage.Status = "Exist";
                    objPQARespMessage.WONUMBER = resWO;
                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                }
            }
            return objPQAResponse;
        }
        #endregion InsertPQAStocking

        #region InsertPQAStockingSummary
        /// <summary>
        /// InsertPQAStockingSummary
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstScores"></param>
        /// <param name="lstPlotData"></param>
        /// <param name="lstPlotGPS"></param>
        /// <param name="lstHoleSize"></param>
        /// <param name="lstPlotSpace"></param>
        /// <param name="lstTreeQA"></param>
        /// <returns></returns>
        /// 

        public PQAResponseClass InsertPQAStockingSummary(List<clsPQAStockingSummaryData> lstTreeStockingSummary, string compSlNo)
        {
            //Log.Writelog("In InsertPQAStockingSummary of Data Layer", "PQA");
            string strSave = string.Empty;
            string QARegWONumber = string.Empty;
            string TotalScore = string.Empty;
            string WOSTATUS = string.Empty;
            string strAssessorcode = string.Empty;
            string struser = string.Empty;
            string sCompSlNo = string.Empty;

            string strPlotforTree = string.Empty;
            PQAResponseClass objPQAResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();
            string resWO = string.Empty;
            string strQADate = string.Empty;
            bool pkError = false;
            bool success = false;
            int comp_Slno = 0;
            TP_Compartment_Data CompartmentData = new TP_Compartment_Data();

            if (compSlNo != String.Empty && compSlNo != "null")
            {
                comp_Slno = Convert.ToInt32(compSlNo);
                var context = new IFOC_FFE_FAEntities();

                var qCompartmentData = context.TP_Compartment_Data.Where(x => x.Comp_Slno == comp_Slno);
                CompartmentData = qCompartmentData.FirstOrDefault<TP_Compartment_Data>();

                if (CompartmentData == null)
                {
                    success = false;
                    objPQARespMessage.CompSlno = compSlNo;
                    objPQARespMessage.Status = "Error";
                    objPQARespMessage.WONUMBER = "";
                    objPQARespMessage.ErrorMessage = "Invalid Compartment Serial Number";
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                    return objPQAResponse;
                }
            }
            else
            {
                success = false;
                objPQARespMessage.CompSlno = compSlNo;
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = "";
                objPQARespMessage.ErrorMessage = "The Compartment Serial No is empty";
                objPQAResponse.ResponseMessage = objPQARespMessage;
                return objPQAResponse;
            }

            if (lstTreeStockingSummary.Count > 0)
            {
                try
                {
                    using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                    {
                        using (TransactionScope ts = new TransactionScope())
                        {
                            for (int i = 0; i < lstTreeStockingSummary.Count; i++)
                            {
                                TP_Plot_Stocking_Data_Summary objStockingDataSummary = new TP_Plot_Stocking_Data_Summary();
                                objStockingDataSummary.Comp_Slno = comp_Slno;
                                objStockingDataSummary.TotalPQAPlot = lstTreeStockingSummary[i].totalPlotPQA;
                                objStockingDataSummary.TotalPQAStocking = lstTreeStockingSummary[i].totalPlotPQAStocking;
                                objStockingDataSummary.PlotSize = lstTreeStockingSummary[i].plotSize;
                                objStockingDataSummary.Spacing = lstTreeStockingSummary[i].spacing;
                                objStockingDataSummary.AverageLive = lstTreeStockingSummary[i].averageLive;
                                objStockingDataSummary.AverageDA = lstTreeStockingSummary[i].averageDA;
                                objStockingDataSummary.AverageDU = lstTreeStockingSummary[i].averageDU;
                                objStockingDataSummary.AverageVA = lstTreeStockingSummary[i].averageVA;
                                objStockingDataSummary.AverageVU = lstTreeStockingSummary[i].averageVU;
                                objStockingDataSummary.DaHa = lstTreeStockingSummary[i].daHa;
                                objStockingDataSummary.DuHa = lstTreeStockingSummary[i].duHa;
                                objStockingDataSummary.DeadPerHa = lstTreeStockingSummary[i].deadPerHa;
                                objStockingDataSummary.VaHa = lstTreeStockingSummary[i].vaHa;
                                objStockingDataSummary.VuHa = lstTreeStockingSummary[i].vuHa;
                                objStockingDataSummary.VacantPerHa = lstTreeStockingSummary[i].vacantPerHa;
                                objStockingDataSummary.InitialPlanting = lstTreeStockingSummary[i].initialPlanting;
                                objStockingDataSummary.IpHa = lstTreeStockingSummary[i].ipHa;
                                objStockingDataSummary.LHa = lstTreeStockingSummary[i].lHa;
                                objStockingDataSummary.InitialStocking = lstTreeStockingSummary[i].initialStocking;
                                objStockingDataSummary.LiveStocking = lstTreeStockingSummary[i].liveStocking;
                                objStockingDataSummary.KerapatanTitikTanam = lstTreeStockingSummary[i].kerapatanTitikTanam;

                                ctx.TP_Plot_Stocking_Data_Summary.Add(objStockingDataSummary);
                                ctx.SaveChanges();
                                success = true;
                            }

                            if (success)
                            {
                                ts.Complete();
                                objPQARespMessage.CompSlno = sCompSlNo;
                                objPQARespMessage.Status = "Success";
                                objPQARespMessage.WONUMBER = resWO;
                                objPQARespMessage.ErrorMessage = "";
                                objPQAResponse.ResponseMessage = objPQARespMessage;

                            }
                            else
                            {
                                if (pkError == true)
                                {
                                    // the error is already set
                                }
                                else
                                {
                                    objPQARespMessage.CompSlno = sCompSlNo;
                                    objPQARespMessage.Status = "Error";
                                    objPQARespMessage.WONUMBER = resWO;
                                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed";
                                    objPQAResponse.ResponseMessage = objPQARespMessage;
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    strSave = "The Transaction could not be completed";
                    objPQARespMessage.CompSlno = "";
                    objPQARespMessage.Status = "Exist";
                    objPQARespMessage.WONUMBER = resWO;
                    objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                    objPQAResponse.ResponseMessage = objPQARespMessage;
                }
            }
            return objPQAResponse;
        }
        #endregion InsertPQAStockingSummary

        //add sigit
        #region GetTimelinePQA
        public List<clsGetTimeline> GetTimelineData(string wo)
        {
            List<clsGetTimeline> lstTimelineDet = new List<clsGetTimeline>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {

                var TimeData = ctx.SP_GetTimelineforPQA(wo);
                foreach (var s in TimeData)
                {
                    clsGetTimeline objTimeDet = new clsGetTimeline();
                    objTimeDet.WO = s.WO_NUMBER.ToString();
                    objTimeDet.StartDate = s.START_DATE.ToString();
                    objTimeDet.CPRDate = s.CPR_DATE.ToString();
                    objTimeDet.FirstDPRDate = s.FIRST_DPR_DATE.ToString();
                    objTimeDet.LastDPRDate = s.LAST_DPR_DATE.ToString();
                    objTimeDet.EstDate = s.EST_DATE.ToString();
                    lstTimelineDet.Add(objTimeDet);
                }

            }
            return lstTimelineDet;
        }
        #endregion GetTimelinePQA

        #region GetConfigurations
        public List<KeyValuePair<string, string>> GetConfigurations()
        {
            List<KeyValuePair<string, string>> configs = new List<KeyValuePair<string, string>>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                var items = (from item in ctx.T_Config
                             select item).ToList();
                foreach (var item in items)
                {
                    configs.Add(new KeyValuePair<string, string>(item.ConfigName, item.Value_string));
                }
            }
            return configs;
        }
        #endregion GetConfigurations

        #endregion PQA

        #region HQA
        #region GetHQAWorkOrders
        /// <summary>
        /// GetHQAWorkOrders
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="dtReqStartDate"></param>
        /// <param name="dtReqEndDate"></param>
        /// <returns></returns>
        public List<clsHQAGetWorkOrders> GetHQAWorkOrders(string sector, DateTime dtReqStartDate, DateTime dtReqEndDate, string deviceID)
        {
            List<clsHQAGetWorkOrders> lsHQAWO = new List<clsHQAGetWorkOrders>();
            try
            {
                //#Guaz - capture the parameters used to query the PQA WO.
                Log.Writelog(deviceID, "GetHQAWorkOrders - SP[SP_HQA_GetWorkOrders]", "HQA");

                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    //Smrithy Added SP_HQA_GetWorkOrders
                    var compData = ctx.SP_HQA_GetWorkOrders(sector, dtReqStartDate, dtReqEndDate);

                    int count = 0;
                    foreach (var s in compData)
                    {
                        count++;
                        var noEntry = ctx.TP_QA_REGISTER.Where(x => x.WO_NUMBER == s.WO_NUMBER && x.ASS_TYPE.Equals("RWA"))
                            .OrderByDescending(x => x.ENTRY_NO).ThenByDescending(x => x.CRT_DATE).FirstOrDefault();

                        var noHWAEntry = ctx.TP_QA_REGISTER.Where(x => x.WO_NUMBER == s.WO_NUMBER && x.ASS_TYPE.Equals("HQA"))
                           .OrderByDescending(x => x.ENTRY_NO).ThenByDescending(x => x.CRT_DATE).FirstOrDefault();

                        var EAPassed = noEntry != null ? ctx.SP_GetEAScore(noEntry.COMP_SLNO).FirstOrDefault() : null;

                        var nameOfRwaImages = noEntry != null ? (noEntry.ENTRY_NO + 1).ToString() : "1";
                        var isRWAMandatory = noEntry != null ? noEntry.PASSED == "F" ? "true" : "false" : "true";
                        var isHQAMandatory = noHWAEntry != null ? noHWAEntry.PASSED == "F" ? "true" : "false" : "true";
                        var isEAMandatory = EAPassed != null ? EAPassed.Passed == "F" ? "true" : "false" : "true";

                        clsHQAGetWorkOrders objHQAWO = new clsHQAGetWorkOrders();
                        objHQAWO.TypeOfAssessment = s.TypeOfAssessment;
                        objHQAWO.WONUMBER = s.WO_NUMBER;
                        objHQAWO.ESTATE = s.ESTATE;
                        objHQAWO.COMPNO = s.COMPNO;
                        objHQAWO.COMPIMAGE = sector + "-RWA" + nameOfRwaImages + "-" + s.ESTATE + s.COMPNO + ".png";
                        //Added By Smrithy-05-11-2015
                        string strYear = s.DateOfIssue.Year.ToString();
                        string strMonth = s.DateOfIssue.Month.ToString();
                        string strDay = s.DateOfIssue.Day.ToString();
                        objHQAWO.DateOfIssue = strDay + "/" + strMonth + "/" + strYear;

                        objHQAWO.TOTHA = s.Area;
                        objHQAWO.NAME = s.ContractorName;
                        objHQAWO.SPVCODE = s.PlantationAssistant;
                        objHQAWO.FOREMANID = s.PlantationForeman;
                        objHQAWO.FOREMANNAME = s.FOREMAN_NAME;
                        objHQAWO.SPVNAME = s.SPV_NAME;
                        objHQAWO.IsRWAMandatory = isRWAMandatory;
                        objHQAWO.IsHQAMandatory = isHQAMandatory;
                        objHQAWO.IsEAMandatory = isEAMandatory;

                        //Added By Smrithy 04-11-2015-JC/OC
                        objHQAWO.JC = s.JC;
                        // Log.Writelog("HQA - JC is " + s.JC, "HQA");
                        objHQAWO.OC = s.OC;
                        // Log.Writelog("HQA - OC is " + s.OC, "HQA");
                        lsHQAWO.Add(objHQAWO);
                    }
                    Log.Writelog(deviceID, "GetHQAWorkOrders - Result count: " + count, "HQA");

                }
            }
            catch (Exception ex)
            {
                Log.Writelog(deviceID, "GetHQAWorkOrders error: " + ex.Message, "HQA");
                Log.Writelog(deviceID, "GetHQAWorkOrders error: " + ex.InnerException.ToString(), "HQA");
            }
            return lsHQAWO;
        }
        #endregion GetHQAWorkOrders

        //Smrithy Added
        #region GetPQATeamDetails
        /// <summary>
        /// GetHQATeamDetails
        /// </summary>
        /// <returns></returns>
        public List<clsQATeam> GetPQATeamDetails(string sector)
        {
            List<clsQATeam> lstQATeam = new List<clsQATeam>();
            try
            {

                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_GetQATeamDetails_v2(sector);
                    foreach (var s in compData)
                    {
                        clsQATeam objQATeam = new clsQATeam();
                        objQATeam.TEAMCODE = s.TEAM_CODE;
                        objQATeam.TEAMNAME = s.TEAM_NAME;
                        objQATeam.COMPANYID = s.COMPANYID;
                        objQATeam.TYPE = s.ass_type;
                        //objQATeam.COMPANYID = "RAP"; // #Guaz: Removed the hardcoded company id. SP will return the company id
                        objQATeam.Active = s.Active;
                        lstQATeam.Add(objQATeam);
                        //Log.Writelog("GetHQATeamDetails" + s.TEAM_CODE + ";" + s.COMPANYID, "HQA"); // #Guaz: only use when need to troubleshoot in details.
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog("GetPQATeamDetails error: " + ex.Message, "HQA");
                Log.Writelog("GetPQATeamDetails error: " + ex.InnerException.ToString(), "HQA");
            }
            return lstQATeam;
        }
        #endregion GetPQATeamDetails

        //Added null checking by Smrithy on 30th Oct 2015
        #region InsertHQADetails
        /// <summary>
        /// InsertHQADetails
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstEAScores"></param>
        /// <param name="lstHQAScores"></param>
        /// <param name="lstHQATree"></param>
        /// <param name="lstRWAPlotData"></param>
        /// <param name="lstRWATree"></param>
        /// <returns></returns>
        public HQAResponseClass InsertHQADetails(clsHQACompartment objHQACompartment, List<clsEAScores> lstEAScores, List<clsHQAScores> lstHQAScores,
                                        List<clsHQATreeDetails> lstHQATree, List<clsRWAPlotSData> lstRWAPlotData, List<clsRWATreeDetails> lstRWATree, List<clsScoreImages> lstScoreImage, string deviceID)
        {
            //public string InsertHQADetails(clsHQACompartment objHQACompartment, List<clsEAScores> lstEAScores, List<clsHQAScores> lstHQAScores,
            //                           List<clsHQATreeDetails> lstHQATree, List<clsRWAPlotSData> lstRWAPlotData, List<clsRWATreeDetails> lstRWATree)
            string strPlotforTree = string.Empty;
            Log.Writelog("In InsertHQADetails of Data Layer", "HQA");
            string strSave = string.Empty;

            //string strSaveQARegister = "";
            string strCompartmentslno = string.Empty;
            string strCompslno = string.Empty;
            string woNumber = "";

            /* Commented by soumitri, due to changes in the HQA And RWA Score. But Later Need to change it to configuration File. */
            //decimal avgScore = Convert.ToDecimal(2.4);
            //decimal avgWood = Convert.ToDecimal(3);

            decimal avgScore = Convert.ToDecimal(2.5);
            decimal avgWood = Convert.ToDecimal(1.5);

            string Assessor = string.Empty;
            int plotSlNo = 0;
            HQAResponseClass objHQAResponse = new HQAResponseClass();
            HQAResponseMessage objHQAResponseMsg = new HQAResponseMessage();
            string resWO = string.Empty;
            DateTime strQADate = DateTime.Now;
            bool pkError = false;
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    //Transaction

                    using (TransactionScope ts = new TransactionScope())
                    {
                        bool success = false;

                        if (objHQACompartment != null)
                        {
                            try
                            {
                                TH_Compartment_Data objCompData = new TH_Compartment_Data();
                                if (objHQACompartment.Assessor != null)
                                {
                                    Assessor = objHQACompartment.Assessor;
                                }

                                if (objHQACompartment.FeatID.Trim() != "")
                                {
                                    objCompData.FeatID = objHQACompartment.FeatID;
                                }

                                if (objHQACompartment.WONUMBER.Trim() != "")
                                {
                                    objCompData.WO_NUMBER = objHQACompartment.WONUMBER;
                                    resWO = objHQACompartment.WONUMBER;
                                }
                                if (objHQACompartment.HarvestingAskep.Trim() != "")
                                {
                                    objCompData.HarvestingAskep = objHQACompartment.HarvestingAskep;
                                }
                                if (objHQACompartment.PlanningAsst.Trim() != "")
                                {
                                    objCompData.PlanningAsst = objHQACompartment.PlanningAsst;
                                }
                                if (objHQACompartment.VegetationType.Trim() != "")
                                {
                                    objCompData.VegetationType = objHQACompartment.VegetationType;
                                }
                                if (objHQACompartment.HarvestingSystem.Trim() != "")
                                {
                                    objCompData.HarvestingSystem = objHQACompartment.HarvestingSystem;
                                }
                                if (objHQACompartment.Status.Trim() != "")
                                {
                                    objCompData.Status = objHQACompartment.Status;
                                }
                                if (objHQACompartment.TotalRWAPlots.Trim().Length > 0)
                                {
                                    objCompData.TotalRWAPlots = Convert.ToInt32(objHQACompartment.TotalRWAPlots);
                                }
                                if (objHQACompartment.TotalMerchantableWood.Trim().Length > 0)
                                {
                                    objCompData.TotalMerchantableWood = Convert.ToDecimal(objHQACompartment.TotalMerchantableWood);
                                }
                                if (objHQACompartment.TotalWasteWood.Trim().Length > 0)
                                {
                                    objCompData.TotalWasteWood = Convert.ToDecimal(objHQACompartment.TotalWasteWood);
                                }
                                if (objHQACompartment.Assessor != null)
                                {
                                    if (objHQACompartment.Assessor.Trim() != "")
                                    {
                                        objCompData.Assessor = objHQACompartment.Assessor;
                                    }
                                }
                                if (objHQACompartment.AvgWood.Trim().Length > 0)
                                {
                                    objCompData.AvgWood = Convert.ToDecimal(objHQACompartment.AvgWood);
                                }
                                if (objHQACompartment.TotalHQAPlots.Trim().Length > 0)
                                {
                                    objCompData.TotalHQAPlots = Convert.ToInt32(objHQACompartment.TotalHQAPlots);
                                }
                                if (objHQACompartment.AvgHQAScore.Trim().Length > 0)
                                {
                                    objCompData.AvgHQAScore = Convert.ToDecimal(objHQACompartment.AvgHQAScore);
                                }
                                if (objHQACompartment.CRTUSERID.Trim() != "")
                                {
                                    objCompData.CRT_USERID = objHQACompartment.CRTUSERID;
                                }
                                else
                                {
                                    Log.Writelog(deviceID, "NO Comp CRTUSERID", "HQA");
                                }
                                objCompData.CRT_DATE = DateTime.Now;

                                //Log.Writelog("Saving TH_Compartment_Data...", "HQA");
                                ctx.TH_Compartment_Data.Add(objCompData);
                                ctx.SaveChanges();
                                success = true;
                                Log.Writelog(deviceID, "Saved TH_Compartment_Data Data !!", "HQA");

                            }
                            catch (Exception ex)
                            {
                                // dbContextTransaction.Rollback();

                                Log.Writelog(deviceID, ex.Message, "HQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                success = false;
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }
                        }

                        int CompSlno = 0;

                        var sCompSlno = ctx.TH_Compartment_Data.Max(x => x.Comp_Slno);

                        CompSlno = Convert.ToInt32(sCompSlno);

                        strCompartmentslno = sCompSlno.ToString();
                        strCompslno = strCompartmentslno;
                        if (objHQACompartment != null)
                        {
                            try
                            {
                                woNumber = objHQACompartment.WONUMBER;

                                var s = ctx.SP_HQARWA_FetchQARegisterDetails(woNumber, Assessor).ToList();
                                foreach (var QA in s)
                                {
                                    //HQA
                                    if (lstHQATree.Count() > 0)
                                    {
                                        TP_QA_REGISTER objQARegister = new TP_QA_REGISTER();
                                        Log.Writelog(deviceID, "Inserting TP_QA_Register", "HQA");

                                        if (objHQACompartment.WONUMBER != null)
                                        {
                                            objQARegister.WO_NUMBER = objHQACompartment.WONUMBER;
                                        }

                                        //UMA Nov-5-2015  Fetching respective team code
                                        objQARegister.TEAM_CODE = QA.HQATEAMCODE;
                                        Log.Writelog(deviceID, "HQA TEAM CODE IS " + QA.HQATEAMCODE, "HQA");
                                        objQARegister.CRT_USERID = objHQACompartment.CRTUSERID;
                                        objQARegister.CRT_DATE = DateTime.Now;
                                        objQARegister.ENTRY_NO = Convert.ToDecimal(QA.ENTRYNO);
                                        objQARegister.PAYMENT_NO = QA.PAYMENTNO;
                                        objQARegister.MAN_ID = QA.MANID;
                                        objQARegister.LOCKED = QA.LOCKED;

                                        objQARegister.ASS_TYPE = "HQA";
                                        objQARegister.QA_VALUE = Convert.ToDecimal(objHQACompartment.AvgHQAScore);
                                        if (Convert.ToDecimal(objHQACompartment.AvgHQAScore) > avgScore)
                                        {
                                            objQARegister.PASSED = "T";
                                        }
                                        else
                                        {
                                            objQARegister.PASSED = "F";
                                        }
                                        //Added By Smrithy-QADATE--05-11-2015
                                        objQARegister.QA_DATE = Convert.ToDateTime(objHQACompartment.QADATE);
                                        try
                                        {
                                            objQARegister.COMP_SLNO = Convert.ToInt32(sCompSlno);
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog(deviceID, ex.Message, "HQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                        }
                                        ctx.TP_QA_REGISTER.Add(objQARegister);
                                        Log.Writelog(deviceID, "Saving tp_qa_register for hqa" + objHQACompartment.WONUMBER.ToString(), "HQA");
                                        ctx.SaveChanges();
                                        //strSaveQARegister = "Saved HQA details";
                                    }


                                    //RWA
                                    if (lstRWAPlotData.Count() > 0)
                                    {
                                        TP_QA_REGISTER objQARegisterRWA = new TP_QA_REGISTER();
                                        Log.Writelog(deviceID, "Inserting rwa in tp_qa_register", "HQA");
                                        if (objHQACompartment.WONUMBER != null)
                                        {
                                            objQARegisterRWA.WO_NUMBER = objHQACompartment.WONUMBER;
                                        }

                                        Log.Writelog(deviceID, "RWA TEAM CODE IS " + QA.RWATEAMCODE, "HQA");
                                        objQARegisterRWA.TEAM_CODE = QA.RWATEAMCODE;
                                        objQARegisterRWA.CRT_USERID = objHQACompartment.CRTUSERID;
                                        objQARegisterRWA.CRT_DATE = DateTime.Now;
                                        objQARegisterRWA.ENTRY_NO = Convert.ToDecimal(QA.ENTRYNO);
                                        objQARegisterRWA.PAYMENT_NO = QA.PAYMENTNO;
                                        objQARegisterRWA.MAN_ID = QA.MANID;
                                        objQARegisterRWA.LOCKED = QA.LOCKED;

                                        objQARegisterRWA.ASS_TYPE = "RWA";
                                        objQARegisterRWA.QA_VALUE = Convert.ToDecimal(objHQACompartment.AvgWood);
                                        //Commented by Soumitri, As condition check should apply for AVGWood but not AVGScore
                                        //if (Convert.ToDecimal(objHQACompartment.AvgWood) < avgScore)
                                        if (Convert.ToDecimal(objHQACompartment.AvgWood) < avgWood)
                                        {
                                            objQARegisterRWA.PASSED = "T";
                                        }
                                        else
                                        {
                                            objQARegisterRWA.PASSED = "F";
                                        }
                                        //Added By Smrithy-QADATE--05-11-2015
                                        objQARegisterRWA.QA_DATE = Convert.ToDateTime(objHQACompartment.QADATE);
                                        strQADate = objQARegisterRWA.QA_DATE;
                                        try
                                        {
                                            objQARegisterRWA.COMP_SLNO = Convert.ToInt32(sCompSlno);
                                        }
                                        catch (Exception ex)
                                        {
                                            Log.Writelog(deviceID, ex.Message, "HQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                        }
                                        ctx.TP_QA_REGISTER.Add(objQARegisterRWA);
                                        //  Log.Writelog("Saving tp_qa_register for rwa" + objHQACompartment.WONUMBER.ToString(), "HQA");
                                        ctx.SaveChanges();
                                        success = true;
                                        //strSaveQARegister = "Saved RWA details";
                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                                Log.Writelog(deviceID, ex.Message, "HQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                success = false;
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                //objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                    //‘WO ____ QA Date ___ is already available in staging database’
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {

                                        objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }



                        }


                        if (lstEAScores != null)
                        {
                            if (lstEAScores.Count > 0)
                            {
                                try
                                {
                                    for (int i = 0; i < lstEAScores.Count; i++)
                                    {
                                        Log.Writelog(deviceID, "In lstEAScores   " + i.ToString(), "HQA");
                                        TP_EA_SCORES ojEAScores = new TP_EA_SCORES();
                                        if (strCompslno != "")
                                        {
                                            ojEAScores.Comp_Slno = Convert.ToInt32(strCompslno);
                                        }
                                        if (lstEAScores[i].Parameter.Trim() != "")
                                        {
                                            ojEAScores.Parameter = lstEAScores[i].Parameter;
                                        }
                                        if (lstEAScores[i].Score.Trim().Length > 0)
                                        {
                                            ojEAScores.Score = Convert.ToInt32(lstEAScores[i].Score);
                                        }
                                        if (lstEAScores[i].OilContaminationGPSLat.Trim().Length > 0)
                                        {
                                            ojEAScores.OilContaminationGPSLat = Convert.ToDecimal(lstEAScores[i].OilContaminationGPSLat);
                                        }
                                        if (lstEAScores[i].OilContaminationGPSLong.Trim().Length > 0)
                                        {
                                            ojEAScores.OilContaminationGPSLong = Convert.ToDecimal(lstEAScores[i].OilContaminationGPSLong);
                                        }
                                        if (lstEAScores[i].Notes != null)
                                        {
                                            if (lstEAScores[i].Notes.Trim() != "")
                                            {
                                                ojEAScores.Notes = lstEAScores[i].Notes;
                                            }
                                        }
                                        if (lstEAScores[i].Status != null)
                                        {
                                            if (lstEAScores[i].Status.Trim() != "")
                                            {
                                                ojEAScores.Status = lstEAScores[i].Status;
                                            }
                                        }
                                        ctx.TP_EA_SCORES.Add(ojEAScores);
                                        ctx.SaveChanges();
                                        success = true;
                                        //    Log.Writelog("Saving Scoring Data " + lstEAScores[i].Score.ToString(), "HQA");
                                        ojEAScores = null;
                                    }
                                    Log.Writelog(deviceID, "Saved tp_ea_Score Data ", "HQA");
                                }
                                catch (Exception ex)
                                {


                                    Log.Writelog(deviceID, ex.Message, "HQA");
                                    Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                    success = false;
                                    objHQAResponseMsg.Status = "Error";
                                    objHQAResponseMsg.WONUMBER = resWO;
                                    objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                    if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {
                                        objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                        //‘WO ____ QA Date ___ is already available in staging database’
                                    }
                                    else if (ex.Message.ToLower().Contains("inner exception"))
                                    {
                                        if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                        {

                                            objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                            pkError = true;
                                        }
                                    }
                                    else
                                    {
                                        objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                    }
                                    objHQAResponse.ResponseMessage = objHQAResponseMsg;
                                }
                            }
                        }
                        if (lstHQAScores != null)
                        {
                            try
                            {
                                if (lstHQAScores.Count > 0)
                                {

                                    for (int i = 0; i < lstHQAScores.Count; i++)
                                    {
                                        Log.Writelog(deviceID, "In lstHQAScores   " + i.ToString(), "HQA");
                                        TP_HQA_SCORES ojHQAScores = new TP_HQA_SCORES();
                                        ojHQAScores.Comp_Slno = Convert.ToInt32(strCompslno);
                                        if (lstHQAScores[i].Parameter != null)
                                        {
                                            if (lstHQAScores[i].Parameter != "")
                                            {
                                                ojHQAScores.Parameter = lstHQAScores[i].Parameter;
                                            }
                                        }
                                        if (lstHQAScores[i].Type != null)
                                        {
                                            if (lstHQAScores[i].Type != "")
                                            {
                                                ojHQAScores.Type = lstHQAScores[i].Type;
                                            }
                                        }
                                        if (lstHQAScores[i].Score != null)
                                        {
                                            if (lstHQAScores[i].Score.Trim().Length > 0)
                                            {
                                                ojHQAScores.Score = Convert.ToInt32(lstHQAScores[i].Score);
                                            }
                                        }
                                        ctx.TP_HQA_SCORES.Add(ojHQAScores);
                                        ctx.SaveChanges();
                                        success = true;
                                        //  Log.Writelog("Saving HQAScores Data " + lstHQAScores[i].Score.ToString(), "HQA");
                                        ojHQAScores = null;
                                    }

                                }
                                Log.Writelog(deviceID, "Saved HQAScores Data ", "HQA");
                            }
                            catch (Exception ex)
                            {


                                Log.Writelog(deviceID, ex.Message, "HQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                success = false;
                                // strSave = "The Transaction could not be completed";
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                // objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.Message.ToString();
                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                    //‘WO ____ QA Date ___ is already available in staging database’
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {

                                        objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }
                        }
                        //Added for Score Image
                        if (lstScoreImage != null)
                        {
                            try
                            {
                                if (lstScoreImage.Count > 0)
                                {

                                    for (int i = 0; i < lstScoreImage.Count; i++)
                                    {
                                        Log.Writelog(deviceID, "In lstScoreImage   " + i.ToString(), "HQA");
                                        TH_SCORE_IMAGES objScoreImages = new TH_SCORE_IMAGES();
                                        objScoreImages.ComplSlNo = Convert.ToInt32(strCompslno);
                                        if (lstScoreImage[i].Category != null)
                                        {
                                            if (lstScoreImage[i].Category != "")
                                            {
                                                objScoreImages.Category = lstScoreImage[i].Category;
                                            }
                                        }
                                        if (lstScoreImage[i].ImageName != null)
                                        {
                                            if (lstScoreImage[i].ImageName != "")
                                            {
                                                objScoreImages.ImageName = lstScoreImage[i].ImageName;

                                                //Avoid Duplication
                                                try
                                                {
                                                    var imageNameList = objScoreImages.ImageName;
                                                    if (imageNameList.Trim().Length > 0)
                                                    {
                                                        string[] strImages = imageNameList.Split(',');
                                                        List<string> strNewImages = new List<string>();
                                                        foreach (var imageName in strImages)
                                                        {
                                                            if (!strNewImages.Contains(imageName))
                                                            {
                                                                var exists = (from item in ctx.TH_SCORE_IMAGES
                                                                              where item.ImageName.Contains(imageName)
                                                                              select item).Any();

                                                                if (!exists)
                                                                {
                                                                    strNewImages.Add(imageName);
                                                                }
                                                                else
                                                                {
                                                                    //Log Duplicate File. Added by soumitri.
                                                                    Log.Writelog(deviceID, "Record Duiplication Image Starts.", "HQA");
                                                                    Log.Writelog(deviceID, imageName, "HQA");
                                                                }
                                                            }
                                                        }

                                                        objScoreImages.ImageName = string.Join(",", strNewImages);
                                                    }
                                                }
                                                catch { }
                                            }
                                        }
                                        if (lstScoreImage[i].ImageDescription != null)
                                        {
                                            if (lstScoreImage[i].ImageDescription != "")
                                            {
                                                objScoreImages.Description = lstScoreImage[i].ImageDescription;
                                            }
                                        }
                                        if (lstScoreImage[i].CRTUSERID != null)
                                        {
                                            objScoreImages.CRT_USERID = lstScoreImage[i].CRTUSERID;
                                        }
                                        else
                                        {
                                            objScoreImages.CRT_USERID = "RGEUser";
                                        }
                                        objScoreImages.CRT_DATE = DateTime.Now;
                                        ctx.TH_SCORE_IMAGES.Add(objScoreImages);
                                        ctx.SaveChanges();
                                        success = true;
                                        // Log.Writelog("Saving ScoreImages Data " + lstScoreImage[i].Category.ToString(), "HQA");
                                        objScoreImages = null;
                                    }
                                }
                                Log.Writelog(deviceID, "Saved scoreimages ", "HQA");
                            }
                            catch (Exception ex)
                            {


                                Log.Writelog(deviceID, ex.Message, "HQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                success = false;
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                //objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.Message.ToString();
                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                    //‘WO ____ QA Date ___ is already available in staging database’
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {

                                        objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }
                        }
                        //End Added for Score Image
                        if (lstHQATree != null)
                        {
                            try
                            {
                                if (lstHQATree.Count > 0)
                                {

                                    for (int i = 0; i < lstHQATree.Count; i++)
                                    {
                                        Log.Writelog(deviceID, "In lstHQATree   " + i.ToString(), "HQA");
                                        TH_Tree_HQA_Details ojHQATrees = new TH_Tree_HQA_Details();
                                        ojHQATrees.Comp_Slno = Convert.ToInt32(strCompslno);

                                        if (lstHQATree[i].HQASerialNo != "")
                                        {
                                            ojHQATrees.HQASerialNo = lstHQATree[i].HQASerialNo;
                                        }
                                        if (lstHQATree[i].PlotNo != "")
                                        {
                                            ojHQATrees.PlotNo = lstHQATree[i].PlotNo;
                                        }
                                        if (lstHQATree[i].CavityCount.Trim().Length > 0)
                                        {
                                            ojHQATrees.CavityCount = Convert.ToInt32(lstHQATree[i].CavityCount);
                                        }
                                        if (lstHQATree[i].DebrisCount.Trim().Length > 0)
                                        {
                                            ojHQATrees.DebrisCount = Convert.ToInt32(lstHQATree[i].DebrisCount);
                                        }
                                        //Added for Image Name & Desc
                                        ojHQATrees.ImageName = lstHQATree[i].ImageNameList;

                                        //Avoid Duplication
                                        try
                                        {
                                            var imageNameList = ojHQATrees.ImageName;
                                            if (imageNameList.Trim().Length > 0)
                                            {
                                                string[] strImages = imageNameList.Split(',');
                                                List<string> strNewImages = new List<string>();
                                                foreach (var imageName in strImages)
                                                {
                                                    if (!strNewImages.Contains(imageName))
                                                    {
                                                        var exists = (from item in ctx.TH_Tree_HQA_Details
                                                                      where item.ImageName.Contains(imageName)
                                                                      select item).Any();

                                                        if (!exists)
                                                        {
                                                            strNewImages.Add(imageName);
                                                        }
                                                        else
                                                        {
                                                            //Log Duplicate File. Added by soumitri.                                                    
                                                            Log.Writelog(deviceID, "Record Duiplication Image Starts.", "HQA");
                                                            Log.Writelog(deviceID, imageName, "HQA");
                                                        }
                                                    }
                                                }

                                                ojHQATrees.ImageName = string.Join(",", strNewImages);
                                            }
                                        }
                                        catch { }

                                        ojHQATrees.Description = lstHQATree[i].ImageDescription;

                                        ctx.TH_Tree_HQA_Details.Add(ojHQATrees);
                                        ctx.SaveChanges();
                                        success = true;
                                        //Log.Writelog("Saving HQATree Data " + lstHQATree[i].PlotNo.ToString(), "HQA");
                                        ojHQATrees = null;
                                    }
                                }
                                Log.Writelog(deviceID, "Saved HQATree Data ", "HQA");
                            }
                            catch (Exception ex)
                            {


                                Log.Writelog(deviceID, ex.Message, "HQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                success = false;
                                //strSave = "The Transaction could not be completed";
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                // objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.Message.ToString();
                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                    //‘WO ____ QA Date ___ is already available in staging database’
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {

                                        objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }

                        }
                        if (lstRWAPlotData.Count > 0)
                        {
                            try
                            {
                                Log.Writelog(deviceID, "Reading HQAScores...", "HQA");
                                for (int j = 0; j < lstRWAPlotData.Count; j++)
                                {
                                    // Log.Writelog("In lstRWAPlotData   " + j.ToString(), "HQA");
                                    TH_RWA_Plot_Data objPlotData = new TH_RWA_Plot_Data();
                                    if (lstRWAPlotData[j].PLOTNO != null)
                                    {
                                        objPlotData.PLOTNO = lstRWAPlotData[j].PLOTNO;
                                        //uma 26-Nov-2015
                                        //Plot number is assigned to track tree details
                                        strPlotforTree = lstRWAPlotData[j].PLOTNO;
                                    }
                                    else
                                    {
                                        Log.Writelog(deviceID, "PLOTNO null", "HQA");

                                    }
                                    objPlotData.Comp_Slno = Convert.ToInt32(strCompslno);
                                    if (lstRWAPlotData[j].REMARKS != "")
                                    {
                                        objPlotData.REMARKS = lstRWAPlotData[j].REMARKS;
                                    }
                                    if (lstRWAPlotData[j].PlotGpsLat.Trim().Length > 0)
                                    {
                                        objPlotData.PlotGpsLat = Convert.ToDecimal(lstRWAPlotData[j].PlotGpsLat);
                                    }
                                    if (lstRWAPlotData[j].PlotGpsLong.Trim().Length > 0)
                                    {
                                        objPlotData.PlotGpsLong = Convert.ToDecimal(lstRWAPlotData[j].PlotGpsLong);
                                    }
                                    if (lstRWAPlotData[j].RecordedDate.Trim() != "")
                                    {
                                        objPlotData.RecordedDate = Convert.ToDateTime(lstRWAPlotData[j].RecordedDate);
                                    }

                                    if (lstRWAPlotData[j].CRTUSERID != null)
                                    {
                                        objPlotData.CRT_USERID = lstRWAPlotData[j].CRTUSERID;
                                    }
                                    else
                                    {
                                        Log.Writelog(deviceID, "NO PLot User", "HQA");
                                    }
                                    objPlotData.CRT_DATE = DateTime.Now;



                                    //Log.Writelog("Writing TP_plot_data", "HQA");
                                    ctx.TH_RWA_Plot_Data.Add(objPlotData);

                                    ctx.SaveChanges();
                                    success = true;
                                    //Log.Writelog("Saved tp_plot_data", "HQA");

                                    //fetching Plot_Slno from TH_RWA_Plot_Data

                                    //Log.Writelog("ctx.TH_RWA_Plot_Data.Max", "HQA");
                                    var sPlotNO = ctx.TH_RWA_Plot_Data.Max(x => x.Plot_Slno);
                                    //Log.Writelog("plot no is " + sPlotNO.ToString(), "HQA");
                                    plotSlNo = Convert.ToInt32(sPlotNO);
                                    //Log.Writelog("converting plotslno to int " + plotSlNo.ToString(), "HQA");

                                    decimal Diameter = 0;
                                    decimal HeightLength = 0;

                                    //Need to add PLOTNO in clsRWATreeDetails 
                                    if (lstRWATree.Count > 0)
                                    {
                                        try
                                        {
                                            Log.Writelog(deviceID, "writing lstplotgps", "HQA");
                                            var s = from RWATreeData in lstRWATree
                                                    where RWATreeData.PlotNo.Contains(strPlotforTree)
                                                    select RWATreeData;

                                            List<clsRWATreeDetails> lstRWATreeDetails = s.ToList<clsRWATreeDetails>();
                                            //iterate through using lst;
                                            //if lst does not work , then iterate through every row and assign to a list object of clsRWATreeDetails



                                            for (int k = 0; k < lstRWATreeDetails.Count; k++)
                                            {
                                                //Log.Writelog(" the value of k is " + k.ToString(), "HQA");
                                                TH_Tree_RWA_Details objRWATree = new TH_Tree_RWA_Details();

                                                objRWATree.Plot_Slno = plotSlNo;
                                                if (lstRWATreeDetails[k].TreeNo != null)
                                                {
                                                    objRWATree.Tree_No = lstRWATreeDetails[k].TreeNo;
                                                }
                                                if (lstRWATreeDetails[k].PropList != null)
                                                {
                                                    objRWATree.PropList = lstRWATreeDetails[k].PropList;
                                                }
                                                if (lstRWATreeDetails[k].Diameter != null)
                                                {
                                                    if (lstRWATreeDetails[k].Diameter.Trim().Length > 0)
                                                    {
                                                        objRWATree.Diameter = Convert.ToDecimal(lstRWATreeDetails[k].Diameter);
                                                        Diameter = Convert.ToDecimal(objRWATree.Diameter);
                                                    }
                                                }
                                                if (lstRWATreeDetails[k].HeightLength != null)
                                                {
                                                    if (lstRWATreeDetails[k].HeightLength.Trim().Length > 0)
                                                    {
                                                        objRWATree.HeightLength = Convert.ToDecimal(lstRWATreeDetails[k].HeightLength);
                                                        HeightLength = Convert.ToDecimal(objRWATree.HeightLength);
                                                    }
                                                }
                                                //int count = 2;
                                                Log.Writelog(deviceID, "Calculating the total volume", "HQA");
                                                Log.Writelog(deviceID, "Diameter is " + Diameter.ToString(), "HQA");
                                                //Log.Writelog("HeightLength is " + HeightLength.ToString(), "HQA");
                                                //decimal H = Diameter;

                                                //decimal D = HeightLength * HeightLength;
                                                //decimal calc = Convert.ToDecimal(0.25 * 3.14);
                                                ////Nov-3-2015 Uma converting total volume to meter cube
                                                //// decimal totlVolume = calc * H * D;//(0.25 * 3.14 * D^2 * H)
                                                //decimal totlVolume = (calc * H * D) / 1000000;
                                                decimal calc = Convert.ToDecimal(0.25 * 3.14);
                                                //Nov-3-2015 Uma converting total volume to meter cube
                                                // decimal totlVolume = calc * H * D;//(0.25 * 3.14 * D^2 * H)
                                                decimal totlVolume = Math.Round(((calc * (Diameter * Diameter) * HeightLength) / 1000000), 6, MidpointRounding.AwayFromZero);

                                                Log.Writelog(deviceID, "Total volume is " + totlVolume.ToString(), "HQA");
                                                objRWATree.TotalVolume = Convert.ToDecimal(totlVolume);
                                                objRWATree.ImageName = lstRWATreeDetails[k].ImageNameList;

                                                //Avoid Duplication
                                                try
                                                {
                                                    var imageNameList = objRWATree.ImageName;
                                                    if (imageNameList.Trim().Length > 0)
                                                    {
                                                        string[] strImages = imageNameList.Split(',');
                                                        List<string> strNewImages = new List<string>();
                                                        foreach (var imageName in strImages)
                                                        {
                                                            if (!strNewImages.Contains(imageName))
                                                            {
                                                                var exists = (from item in ctx.TH_Tree_RWA_Details
                                                                              where item.ImageName.Contains(imageName)
                                                                              select item).Any();

                                                                if (!exists)
                                                                {
                                                                    strNewImages.Add(imageName);
                                                                }
                                                                else
                                                                {
                                                                    //Log Duplicate File. Added by soumitri.                                                    
                                                                    Log.Writelog(deviceID, "Record Duiplication Image Starts.", "HQA");
                                                                    Log.Writelog(deviceID, imageName, "HQA");
                                                                }
                                                            }
                                                        }

                                                        objRWATree.ImageName = string.Join(",", strNewImages);
                                                    }
                                                }
                                                catch { }

                                                //Added for ImageDescription
                                                objRWATree.Description = lstRWATreeDetails[k].ImageDescription;
                                                ctx.TH_Tree_RWA_Details.Add(objRWATree);
                                                //Log.Writelog("Saving TH_Tree_RWA_Details", "HQA");
                                                ctx.SaveChanges();
                                                success = true;
                                                //Log.Writelog("saved TH_Tree_RWA_Details", "HQA");
                                                objRWATree = null;
                                            }
                                            Log.Writelog(deviceID, "saved TH_Tree_RWA_Details", "HQA");
                                        }
                                        catch (Exception ex)
                                        {


                                            Log.Writelog(deviceID, ex.Message, "HQA");
                                            Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                            success = false;
                                            //  strSave = "The Transaction could not be completed";
                                            objHQAResponseMsg.Status = "Error";
                                            objHQAResponseMsg.WONUMBER = resWO;
                                            // objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.Message.ToString();
                                            if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                            {
                                                objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                                pkError = true;
                                                //‘WO ____ QA Date ___ is already available in staging database’
                                            }
                                            else if (ex.Message.ToLower().Contains("inner exception"))
                                            {
                                                if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                                {

                                                    objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                                    pkError = true;
                                                }
                                            }
                                            else
                                            {
                                                objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                            }
                                            objHQAResponse.ResponseMessage = objHQAResponseMsg;
                                        }

                                    }

                                }
                            }
                            catch (Exception ex)
                            {


                                Log.Writelog(deviceID, ex.Message, "HQA");
                                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                                success = false;
                                // strSave = "The Transaction could not be completed";
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                // objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.Message.ToString();
                                if (ex.Message.ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                {
                                    objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                    pkError = true;
                                    //‘WO ____ QA Date ___ is already available in staging database’
                                }
                                else if (ex.Message.ToLower().Contains("inner exception"))
                                {
                                    if (ex.InnerException.ToString().ToUpper().Contains("PRIMARY KEY CONSTRAINT"))
                                    {

                                        objHQAResponseMsg.ErrorMessage = " WO " + resWO.ToString() + " QA Date " + strQADate.ToString() + " is already available in staging database";
                                        pkError = true;
                                    }
                                }
                                else
                                {
                                    objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                                }
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }
                        }
                        if (success)
                        {
                            ts.Complete();
                            //strSave = "Successfully Saved HQA,RWA and EA Details";
                            objHQAResponseMsg.Status = "Success";
                            objHQAResponseMsg.WONUMBER = resWO;
                            objHQAResponseMsg.ErrorMessage = "";
                            objHQAResponse.ResponseMessage = objHQAResponseMsg;
                        }
                        else
                        {
                            if (pkError == true)
                            {
                                // the error is already set
                            }
                            else
                            {
                                Log.Writelog(deviceID, "The Transaction could not be completed", "HQA");
                                strSave = "The Transaction could not be completed";
                                objHQAResponseMsg.Status = "Error";
                                objHQAResponseMsg.WONUMBER = resWO;
                                objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed";
                                objHQAResponse.ResponseMessage = objHQAResponseMsg;
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Log.Writelog(deviceID, ex.Message, "HQA");
                Log.Writelog(deviceID, ex.InnerException.ToString(), "HQA");
                // strSave = "The Transaction could not be completed";
                objHQAResponseMsg.Status = "Error";
                objHQAResponseMsg.WONUMBER = resWO;
                objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed";
                objHQAResponse.ResponseMessage = objHQAResponseMsg;
            }
            Log.Writelog(deviceID, "Final error message is " + objHQAResponseMsg.ErrorMessage.ToString(), "HQA");
            Log.Writelog(deviceID, "Final status  is " + objHQAResponseMsg.Status.ToString(), "HQA");
            return objHQAResponse;
        }


        #endregion InsertHQADetails

        //Smrithy Added-03-11-2015
        #region InsertHQARWAQARegisterDetails
        /// <summary>
        /// InsertHQARWAQARegisterDetails
        /// </summary>
        /// <param name="objHQACompartment"></param>
        /// <returns></returns>
        public string InsertHQARWAQARegisterDetails(clsHQACompartment objHQACompartment)
        {
            //string strSaveQARegister = "";
            string strCompartmentslno = string.Empty;
            if (objHQACompartment != null)
            {
                string woNumber = "";

                /* Commented by soumitri, due to changes in the HQA And RWA Score. But Later Need to change it to configuration File. */
                //decimal avgScore = Convert.ToDecimal(2.4);
                //decimal avgWood = Convert.ToDecimal(3);

                decimal avgScore = Convert.ToDecimal(2.5);
                decimal avgWood = Convert.ToDecimal(1.5);

                string Assessor = string.Empty;
                if (objHQACompartment.Assessor != null)
                {
                    Assessor = objHQACompartment.Assessor;
                }
                try
                {
                    using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                    {
                        //Transaction

                        using (TransactionScope ts = new TransactionScope())
                        {
                            bool success = false;
                            if (objHQACompartment != null)
                            {
                                try
                                {
                                    TH_Compartment_Data objCompData = new TH_Compartment_Data();

                                    if (objHQACompartment.FeatID.Trim() != "")
                                    {
                                        objCompData.FeatID = objHQACompartment.FeatID;
                                    }

                                    if (objHQACompartment.WONUMBER.Trim() != "")
                                    {
                                        objCompData.WO_NUMBER = objHQACompartment.WONUMBER;
                                    }
                                    if (objHQACompartment.HarvestingAskep.Trim() != "")
                                    {
                                        objCompData.HarvestingAskep = objHQACompartment.HarvestingAskep;
                                    }
                                    if (objHQACompartment.PlanningAsst.Trim() != "")
                                    {
                                        objCompData.PlanningAsst = objHQACompartment.PlanningAsst;
                                    }
                                    if (objHQACompartment.VegetationType.Trim() != "")
                                    {
                                        objCompData.VegetationType = objHQACompartment.VegetationType;
                                    }
                                    if (objHQACompartment.HarvestingSystem.Trim() != "")
                                    {
                                        objCompData.HarvestingSystem = objHQACompartment.HarvestingSystem;
                                    }
                                    if (objHQACompartment.Status.Trim() != "")
                                    {
                                        objCompData.Status = objHQACompartment.Status;
                                    }
                                    if (objHQACompartment.TotalRWAPlots.Trim().Length > 0)
                                    {
                                        objCompData.TotalRWAPlots = Convert.ToInt32(objHQACompartment.TotalRWAPlots);
                                    }
                                    if (objHQACompartment.TotalMerchantableWood.Trim().Length > 0)
                                    {
                                        objCompData.TotalMerchantableWood = Convert.ToDecimal(objHQACompartment.TotalMerchantableWood);
                                    }
                                    if (objHQACompartment.TotalWasteWood.Trim().Length > 0)
                                    {
                                        objCompData.TotalWasteWood = Convert.ToDecimal(objHQACompartment.TotalWasteWood);
                                    }
                                    if (objHQACompartment.Assessor != null)
                                    {
                                        if (objHQACompartment.Assessor.Trim() != "")
                                        {
                                            objCompData.Assessor = objHQACompartment.Assessor;
                                        }
                                    }
                                    if (objHQACompartment.AvgWood.Trim().Length > 0)
                                    {
                                        objCompData.AvgWood = Convert.ToDecimal(objHQACompartment.AvgWood);
                                    }
                                    if (objHQACompartment.TotalHQAPlots.Trim().Length > 0)
                                    {
                                        objCompData.TotalHQAPlots = Convert.ToInt32(objHQACompartment.TotalHQAPlots);
                                    }
                                    if (objHQACompartment.AvgHQAScore.Trim().Length > 0)
                                    {
                                        objCompData.AvgHQAScore = Convert.ToDecimal(objHQACompartment.AvgHQAScore);
                                    }
                                    if (objHQACompartment.CRTUSERID.Trim() != "")
                                    {
                                        objCompData.CRT_USERID = objHQACompartment.CRTUSERID;
                                    }
                                    else
                                    {
                                        Log.Writelog("NO Comp CRTUSERID", "HQA");
                                    }
                                    objCompData.CRT_DATE = DateTime.Now;

                                    Log.Writelog("Saving TH_Compartment_Data...", "HQA");
                                    ctx.TH_Compartment_Data.Add(objCompData);
                                    ctx.SaveChanges();
                                    success = true;
                                    Log.Writelog("Saved TH_Compartment_Data Data !!", "HQA");

                                }
                                catch (Exception ex)
                                {
                                    // dbContextTransaction.Rollback();

                                    Log.Writelog(ex.Message, "HQA");
                                    Log.Writelog(ex.InnerException.ToString(), "HQA");
                                    success = false;
                                }
                            }

                            int CompSlno = 0;

                            var sCompSlno = ctx.TH_Compartment_Data.Max(x => x.Comp_Slno);

                            CompSlno = Convert.ToInt32(sCompSlno);
                            strCompartmentslno = sCompSlno.ToString();
                            if (objHQACompartment != null)
                            {
                                try
                                {
                                    woNumber = objHQACompartment.WONUMBER;


                                    var s = ctx.SP_HQARWA_FetchQARegisterDetails(woNumber, Assessor).ToList();
                                    foreach (var QA in s)
                                    {
                                        //HQA
                                        TP_QA_REGISTER objQARegister = new TP_QA_REGISTER();
                                        Log.Writelog("Inserting TP_QA_Register", "HQA");

                                        if (objHQACompartment.WONUMBER != null)
                                        {
                                            objQARegister.WO_NUMBER = objHQACompartment.WONUMBER;
                                        }

                                        //UMA Nov-5-2015  Fetching respective team code
                                        objQARegister.TEAM_CODE = QA.HQATEAMCODE;
                                        Log.Writelog("HQA TEAM CODE IS " + QA.HQATEAMCODE, "HQA");
                                        objQARegister.CRT_USERID = objHQACompartment.CRTUSERID;
                                        objQARegister.CRT_DATE = DateTime.Now;
                                        objQARegister.ENTRY_NO = Convert.ToDecimal(QA.ENTRYNO);
                                        objQARegister.PAYMENT_NO = QA.PAYMENTNO;
                                        objQARegister.MAN_ID = QA.MANID;
                                        objQARegister.LOCKED = QA.LOCKED;

                                        objQARegister.ASS_TYPE = "HQA";
                                        objQARegister.QA_VALUE = Convert.ToDecimal(objHQACompartment.AvgHQAScore);
                                        if (Convert.ToDecimal(objHQACompartment.AvgHQAScore) > avgScore)
                                        {
                                            objQARegister.PASSED = "T";
                                        }
                                        else
                                        {
                                            objQARegister.PASSED = "F";
                                        }
                                        //Added By Smrithy-QADATE--05-11-2015
                                        objQARegister.QA_DATE = Convert.ToDateTime(objHQACompartment.QADATE);
                                        try
                                        {
                                            objQARegister.COMP_SLNO = Convert.ToInt32(sCompSlno);
                                        }
                                        catch { }
                                        ctx.TP_QA_REGISTER.Add(objQARegister);
                                        Log.Writelog("Saving tp_qa_register for hqa" + objHQACompartment.WONUMBER.ToString(), "HQA");
                                        ctx.SaveChanges();
                                        //strSaveQARegister = "Saved HQA details";

                                        //RWA
                                        TP_QA_REGISTER objQARegisterRWA = new TP_QA_REGISTER();
                                        Log.Writelog("Inserting rwa in tp_qa_register", "HQA");
                                        if (objHQACompartment.WONUMBER != null)
                                        {
                                            objQARegisterRWA.WO_NUMBER = objHQACompartment.WONUMBER;
                                        }

                                        Log.Writelog("RWA TEAM CODE IS " + QA.RWATEAMCODE, "HQA");
                                        objQARegisterRWA.TEAM_CODE = QA.RWATEAMCODE;
                                        objQARegisterRWA.CRT_USERID = objHQACompartment.CRTUSERID;
                                        objQARegisterRWA.CRT_DATE = DateTime.Now;
                                        objQARegisterRWA.ENTRY_NO = Convert.ToDecimal(QA.ENTRYNO);
                                        objQARegisterRWA.PAYMENT_NO = QA.PAYMENTNO;
                                        objQARegisterRWA.MAN_ID = QA.MANID;
                                        objQARegisterRWA.LOCKED = QA.LOCKED;

                                        objQARegisterRWA.ASS_TYPE = "RWA";
                                        objQARegisterRWA.QA_VALUE = Convert.ToDecimal(objHQACompartment.AvgWood);
                                        //Commented by Soumitri, As condition check should apply for AVGWood but not AVGScore
                                        //if (Convert.ToDecimal(objHQACompartment.AvgWood) < avgScore)
                                        if (Convert.ToDecimal(objHQACompartment.AvgWood) < avgWood)
                                        {
                                            objQARegisterRWA.PASSED = "T";
                                        }
                                        else
                                        {
                                            objQARegisterRWA.PASSED = "F";
                                        }
                                        //Added By Smrithy-QADATE--05-11-2015
                                        objQARegisterRWA.QA_DATE = Convert.ToDateTime(objHQACompartment.QADATE);
                                        try
                                        {
                                            objQARegisterRWA.COMP_SLNO = Convert.ToInt32(sCompSlno);
                                        }
                                        catch { }
                                        ctx.TP_QA_REGISTER.Add(objQARegisterRWA);
                                        Log.Writelog("Saving tp_qa_register for rwa" + objHQACompartment.WONUMBER.ToString(), "HQA");
                                        ctx.SaveChanges();
                                        success = true;
                                        //strSaveQARegister = "Saved RWA details";
                                    }

                                }
                                catch (Exception ex)
                                {
                                    // dbContextTransaction.Rollback();

                                    Log.Writelog(ex.Message, "HQA");
                                    Log.Writelog(ex.InnerException.ToString(), "HQA");
                                    success = false;
                                }



                            }

                            if (success)
                            {
                                ts.Complete();

                            }
                            else
                            {
                                Log.Writelog("The Transaction could not be completed", "HQA");
                                //strSaveQARegister = "The Transaction could not be completed";
                            }

                        }

                        //strSaveQARegister = "Saved QARegister with HQARWA Details";
                    }
                }
                catch (Exception ex) { Log.Writelog(ex.Message, "HQA"); Log.Writelog(ex.InnerException.ToString(), "HQA"); }
            }
            return strCompartmentslno;
        }
        #endregion InsertHQARWAQARegisterDetails

        //Smrithy Added-03-11-2015
        #region GetHQARWATeamDetails
        /// <summary>
        /// GetHQARWATeamDetails
        /// </summary>
        /// <returns></returns>
        public List<clsHQARWATeam> GetHQARWATeamDetails(string sector)
        {
            List<clsHQARWATeam> lstHQARWATeam = new List<clsHQARWATeam>();
            try
            {

                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {

                    var compData = ctx.SP_GetHQARWATeamDetails_v2(sector);
                    foreach (var s in compData)
                    {
                        clsHQARWATeam objHQARWATeam = new clsHQARWATeam();
                        objHQARWATeam.TEAMCODE = s.TEAM_CODE;
                        objHQARWATeam.TEAMNAME = s.TEAM_NAME;
                        objHQARWATeam.Active = s.Active;
                        objHQARWATeam.COMPANYID = s.COMPANYID;
                        objHQARWATeam.TYPE = s.ass_type;
                        lstHQARWATeam.Add(objHQARWATeam);
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog("GetHQARWATeamDetails error: " + ex.Message, "HQA");
                Log.Writelog("GetHQARWATeamDetails error: " + ex.InnerException.ToString(), "HQA");
            }
            return lstHQARWATeam;
        }
        #endregion GetHQARWATeamDetails
        #endregion HQA

        #region GetAuthTokenID
        /// <summary>
        /// GetAuthTokenID
        /// </summary>
        /// <param name="deviceID"></param>
        /// <returns></returns>


        public clsResponseAuthToken GetAuthTokenID(string deviceID)
        {
            Log.Writelog("In data layer of GetAuthTokenID " + deviceID, "");
            clsAuthTokenDet objToken = new clsAuthTokenDet();
            clsResponseAuthToken objResponse = new clsResponseAuthToken();
            clsResponseAuthTokenMessage objResponseMsg = new clsResponseAuthTokenMessage();
            string DEVICEFOUND = string.Empty;
            string strtokenID = string.Empty;
            try
            {
                using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
                {
                    var tokenID = ctx.SP_GetAuthTokenID(deviceID);
                    Log.Writelog(tokenID.ToString(), "");
                    foreach (var s in tokenID)
                    {
                        objToken.TokenID = Convert.ToString(s.AuthToken);
                        strtokenID = Convert.ToString(s.AuthToken);
                        objToken.DEVICEFOUND = Convert.ToString(s.DEVICEFOUND);
                        DEVICEFOUND = Convert.ToString(s.DEVICEFOUND);
                        Log.Writelog("DEVICEFOUND is  " + objToken.DEVICEFOUND.ToString(), "");
                        Log.Writelog("device id is  " + deviceID.ToString(), "");
                        Log.Writelog("In data layer - The token is " + objToken.TokenID.ToString(), "");
                    }
                    if (DEVICEFOUND == "0")
                    {
                        objResponseMsg.DeviceID = deviceID;
                        objResponseMsg.TokenID = string.Empty;
                        objResponseMsg.ErrorMessage = "Device Not Registered " + deviceID;
                        objResponseMsg.Status = "Error";
                        objResponse.ResponseMessage = objResponseMsg;
                    }
                    else
                    {
                        objResponseMsg.DeviceID = deviceID;
                        objResponseMsg.TokenID = strtokenID;
                        objResponseMsg.ErrorMessage = "";
                        objResponseMsg.Status = "Success " + deviceID;
                        objResponse.ResponseMessage = objResponseMsg;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.Writelog("Error 1: " + ex.InnerException.ToString(), "");
                Log.Writelog("Error 2: " + ex.Message, "");
                Log.Writelog("Error 3: " + ex.Source, "");
                Log.Writelog("Error 4: " + ex.TargetSite, "");

                objResponseMsg.DeviceID = "";
                objResponseMsg.TokenID = "";
                objResponseMsg.ErrorMessage = "DB connection error = Source|" + ex.Source.ToString() + "|TargetSite|" + ex.TargetSite + "|Message|" + ex.Message;
                objResponseMsg.Status = "";
                objResponse.ResponseMessage = objResponseMsg;
                return objResponse;
            }
            return objResponse;
        }

        //public bool ValidateAuthToken(string deviceID, string tokenID)
        //{
        //    bool isValidToken = false;

        //    using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
        //    {
        //        var s = ctx.SP_ValidateToken(deviceID, tokenID);
        //        foreach (var m in s)
        //        {
        //            int i = Convert.ToInt32((m.ISTOKENEXISTS));
        //            if (i == 1)
        //            { isValidToken = true; }
        //            else
        //            { isValidToken = false; }
        //        }

        //    }
        //    return isValidToken;
        //}

        public clsAuthTokenValidation ValidateAuthToken(string deviceID, string tokenID, int isExpiry)
        {

            // if ValidateTokenExpiry is 1 then u validate for expiration date 
            //if ValidateTokenExpiry is 0 , then dont check for expiration date
            clsAuthTokenValidation obj = new clsAuthTokenValidation();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                var s = ctx.SP_ValidateTokenWithExpiry(deviceID, tokenID, isExpiry);
                foreach (var m in s)
                {
                    int i = Convert.ToInt32((m.ISTOKENEXISTS));
                    obj.IsTokenExists = m.ISTOKENEXISTS;
                    if (i == 1)
                    { obj.IsValidToken = true; }
                    else
                    { obj.IsValidToken = false; }
                    obj.DeviceFound = m.DEVICEFOUND;
                    obj.Message = m.TOKENMESSAGE;

                }

            }
            return obj;
        }
        #endregion GetAuthTokenID

        //Added on 07/02/2018 By Soumitri for SEED LOT DATA
        #region GetSeedLotData
        /// <summary>
        /// GetSeedLotData
        /// </summary>
        /// <returns></returns>
        public List<clsSeedLot> GetSeedLotData()
        {
            List<clsSeedLot> listOfSeedLot = new List<clsSeedLot>();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                var seedlotData = ctx.SP_GetSEEDLOT();
                foreach (var s in seedlotData)
                {
                    clsSeedLot objOfSeedLot = new clsSeedLot();
                    objOfSeedLot.SEEDLOT_CODE = s.SEEDLOT_CODE;
                    objOfSeedLot.SPECIESID = s.SPECIESID;
                    objOfSeedLot.SECTOR = s.SECTOR;
                    listOfSeedLot.Add(objOfSeedLot);
                }

            }
            return listOfSeedLot;
        }
        #endregion GetSeedLotData

        #region Login
        public clsValidateUserID ValidateUserID(string userId)
        {
            clsValidateUserID obj = new clsValidateUserID();

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                try
                {
                    var userFound = ctx.SP_ValidateUserID(userId).FirstOrDefault();
                    obj.IsValidUser = Convert.ToInt32(userFound.USERFOUND);
                    obj.Message = (obj.IsValidUser == 1) ? "Success" : "Invalid User ID";
                }
                catch (Exception ex)
                {
                    Log.Writelog(ex.Message, "");
                    Log.Writelog(ex.InnerException.ToString(), "");
                }

            }
            return obj;
        }

        private string HashPassword(string password)
        {
            string x = "";
            string hash = "";
            int fact = 51;

            foreach (char c in password)
            {
                x = (System.Convert.ToInt32(c) + fact).ToString();
                hash = hash + x.Length.ToString() + x;
                fact = fact + 1;
            }

            return hash;
        }

        public clsUserDetail Login(string UserID, string Password, string AppName)
        {
            clsUserDetail obj = new clsUserDetail();

            if (String.IsNullOrEmpty(UserID))
            {
                obj.Message = "User ID is Empty";
                return obj;
            }
            if (String.IsNullOrEmpty(UserID))
            {
                obj.Message = "Password is Empty";
                return obj;
            }

            using (IFOC_FFE_FAEntities ctx = new IFOC_FFE_FAEntities())
            {
                try
                {
                    var userData = (from u in ctx.USER_APP_ACCESS
                                    join r in ctx.USER_ROLE_MAP
                                    on u.ROLE equals r.ROLE
                                    where u.USERID == UserID && r.APP_ACCESS == AppName
                                    select new clsUserDetail
                                    {
                                        UserID = u.USERID,
                                        SyncAccess = r.SYNC_ACCESS,
                                        Role = u.ROLE,
                                        Name = u.FULLNAME,
                                        Password = u.PASSWORD
                                    }).FirstOrDefault();
                    if (userData == null)
                    {
                        obj.Message = "Invalid User ID";
                        return obj;
                    }

                    if (userData.Password != HashPassword(Password))
                    {
                        obj.Message = "Invalid Password";
                        return obj;
                    }

                    obj.UserID = userData.UserID;
                    obj.Name = userData.Name;
                    obj.Role = userData.Role;
                    obj.SyncAccess = userData.SyncAccess;
                    obj.Message = string.Empty;
                }
                catch (Exception ex)
                {
                    obj.Message = "Login Failed";
                    Log.Writelog(ex.Message, "");
                    Log.Writelog(ex.InnerException.ToString(), "");
                }
            }
            return obj;
        }
        #endregion

        #endregion Methods

        #region TransactionScope
        private TransactionScope CreateTransactionScope(TimeSpan timeout)
        {
            SetTransactionManagerField("_cachedMaxTimeout", true);
            SetTransactionManagerField("_maximumTimeout", timeout);

            var transactionScopeOptions = new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted,
                Timeout = timeout
            };

            return new TransactionScope(TransactionScopeOption.RequiresNew, transactionScopeOptions);
        }


        private void SetTransactionManagerField(string fieldName, object value)
        {
            typeof(TransactionManager).GetField(fieldName, BindingFlags.NonPublic | BindingFlags.Static).SetValue(null, value);
        }
        #endregion

    }
}
