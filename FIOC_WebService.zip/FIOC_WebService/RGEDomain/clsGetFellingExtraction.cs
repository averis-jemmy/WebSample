﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsGetFellingExtraction
    {
        public List<clsFellingData> FellingWO = new List<clsFellingData>();
        public List<clsExtractingData> ExtractionWO = new List<clsExtractingData>();
    }
    public class clsFellingData
    {
        #region private_variables
        private string _WONUMBER;
        private string _JCOC;
        private string _OC;
        private string _SECTOR;
        private string _COMPNO;
        private string _NAME;
        private string _CONTCODE;

        #endregion private_variables

        #region Properties
        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
        public string JCOC
        {
            get { return _JCOC; }
            set { _JCOC = value; }
        }
        public string OC
        {
            get { return _OC; }
            set { _OC = value; }
        }
        public string SECTOR
        {
            get { return _SECTOR; }
            set { _SECTOR = value; }
        }
        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }
        public string NAME
        {
            get { return _NAME; }
            set { _NAME = value; }
        }

        public string CONTCODE
        {
            get { return _CONTCODE; }
            set { _CONTCODE = value; }
        }
        #endregion
    }
    public class clsExtractingData
    {
        #region private_variables
        private string _WONUMBER;
        private string _JCOC;
        private string _OC;
        private string _SECTOR;
        private string _COMPNO;
        private string _NAME;
        private string _CONTCODE;

        #endregion private_variables

        #region Properties
        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
        public string JCOC
        {
            get { return _JCOC; }
            set { _JCOC = value; }
        }
        public string OC
        {
            get { return _OC; }
            set { _OC = value; }
        }
        public string SECTOR
        {
            get { return _SECTOR; }
            set { _SECTOR = value; }
        }
        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }
        public string NAME
        {
            get { return _NAME; }
            set { _NAME = value; }
        }

        public string CONTCODE
        {
            get { return _CONTCODE; }
            set { _CONTCODE = value; }
        }
        #endregion
    }
}
