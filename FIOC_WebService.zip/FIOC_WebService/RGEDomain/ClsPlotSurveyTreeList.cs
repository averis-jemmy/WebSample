﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using RGEBal;
//using RGEDal;

namespace RGEDomain
{
    public class ClsPlotSurveyTreeList
    {

        #region Plot
        #region private_variables
        //private int _PlotSlno;
        private string _PlotNo;
        private int _CompSlno;
        private decimal _PlotRadius;
        private decimal _GPSLat;
        private decimal _GPSLong;
        private decimal _SamplePercentage;
        private string _PRemarks;
        private string _PCreatedBy;
        private DateTime _PCreatedDate;
        private string _PModifiedBy;
        private DateTime _PModifiedDate;

        

        #endregion private_variables

        #region Properties
        //public int PlotSlno
        //{
        //    get { return _PlotSlno; }
        //    set { _PlotSlno = value; }
        //}
        public string PlotNo
        {
            get { return _PlotNo; }
            set { _PlotNo = value; }
        }
        public int CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        public decimal PlotRadius
        {
            get { return _PlotRadius; }
            set { _PlotRadius = value; }
        }
        public decimal GPSLat
        {
            get { return _GPSLat; }
            set { _GPSLat = value; }
        }
        public decimal GPSLong
        {
            get { return _GPSLong; }
            set { _GPSLong = value; }
        }
        public decimal SamplePercentage
        {
            get { return _SamplePercentage; }
            set { _SamplePercentage = value; }
        }
        public string PRemarks
        {
            get { return _PRemarks; }
            set { _PRemarks = value; }
        }

        public string PCreatedBy
        {
            get { return _PCreatedBy; }
            set { _PCreatedBy = value; }
        }
        public DateTime PCreatedDate
        {
            get { return _PCreatedDate; }
            set { _PCreatedDate = value; }
        }
        public string PModifiedBy
        {
            get { return _PModifiedBy; }
            set { _PModifiedBy = value; }
        }
        public DateTime PModifiedDate
        {
            get { return _PModifiedDate; }
            set { _PModifiedDate = value; }
        }
        #endregion
        #endregion Plot

        #region Plot_Spacing

        #region private_variables
        private int _SpacePlotSlno;
        private decimal _BRI;
        private decimal _IRI;
        #endregion private_variables

        #region Properties
        public int SpacePlotSlno
        {
            get { return _SpacePlotSlno; }
            set { _SpacePlotSlno = value; }
        }
        public decimal BRI
        {
            get { return _BRI; }
            set { _BRI = value; }
        }
        public decimal IRI
        {
            get { return _IRI; }
            set { _IRI = value; }
        }
        #endregion Properties
        #endregion Plot_Spacing

        #region Survey
        #region private_variables

        //private int _SurveySlno;
        private string _SurveyNo;
        private DateTime _SurveyDate;
     
        private string _SInventoryType;
        private string _SurveyStatus;
        private int _EmpID;
        private string _TeamCode;
        private string _SurveyLineNo;
        private string _AzimuthPlotLine;
        
        private string _SRemarks;
        private string _MaintainenceStatus;
        private string _Flooding;
        private string _SoilSampleCollected;
        private string _UUID;
        private string _Name;
        private string _SAPID;
        private string _ErrorStatus;
  
        private string _SCreatedBy;
        private DateTime _SCreatedDate;
        private string _SModifiedBy;
        private DateTime _SModifiedDate;
      
        private string _Keyedinby;
        private string _TotalLiveYellow;
        private string _TotalDead;
        private string _TotalHealthy;
       
        #endregion private_variables

        #region Properties
        //public int SurveySlno
        //{
        //    get { return _SurveySlno; }
        //    set { _SurveySlno = value; }
        //}
        
        public string SurveyNo
        {
            get { return _SurveyNo; }
            set { _SurveyNo = value; }
        }
        public DateTime SurveyDate
        {
            get { return _SurveyDate; }
            set { _SurveyDate = value; }
        }
    
        public string SInventoryType
        {
            get { return _SInventoryType; }
            set { _SInventoryType = value; }
        }
        public string SurveyStatus
        {
            get { return _SurveyStatus; }
            set { _SurveyStatus = value; }
        }
        public int EmpID
        {
            get { return _EmpID; }
            set { _EmpID = value; }
        }
        public string TeamCode
        {
            get { return _TeamCode; }
            set { _TeamCode = value; }
        }
        public string SurveyLineNo
        {
            get { return _SurveyLineNo; }
            set { _SurveyLineNo = value; }
        }
        public string AzimuthPlotLine
        {
            get { return _AzimuthPlotLine; }
            set { _AzimuthPlotLine = value; }
        }
       
        public string SRemarks
        {
            get { return _SRemarks; }
            set { _SRemarks = value; }
        }
        public string MaintainenceStatus
        {
            get { return _MaintainenceStatus; }
            set { _MaintainenceStatus = value; }
        }
        public string Flooding
        {
            get { return _Flooding; }
            set { _Flooding = value; }
        }
        public string SoilSampleCollected
        {
            get { return _SoilSampleCollected; }
            set { _SoilSampleCollected = value; }
        }
        public string UUID
        {
            get { return _UUID; }
            set { _UUID = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string SAPID
        {
            get { return _SAPID; }
            set { _SAPID = value; }
        }
        public string ErrorStatus
        {
            get { return _ErrorStatus; }
            set { _ErrorStatus = value; }
        }

       
        public string SCreatedBy
        {
            get { return _SCreatedBy; }
            set { _SCreatedBy = value; }
        }
        public DateTime SCreatedDate
        {
            get { return _SCreatedDate; }
            set { _SCreatedDate = value; }
        }
        public string SModifiedBy
        {
            get { return _SModifiedBy; }
            set { _SModifiedBy = value; }
        }
        public DateTime SModifiedDate
        {
            get { return _SModifiedDate; }
            set { _SModifiedDate = value; }
        }
       
        public string Keyedinby
        {
            get { return _Keyedinby; }
            set { _Keyedinby = value; }
        }
        public string TotalLiveYellow
        {
            get { return _TotalLiveYellow; }
            set { _TotalLiveYellow = value; }
        }

        public string TotalDead
        {
            get { return _TotalDead; }
            set { _TotalDead = value; }
        }

        public string TotalHealthy
        {
            get { return _TotalHealthy; }
            set { _TotalHealthy = value; }
        }

       
        #endregion
        #endregion Survey

        #region Tree

        #region Tree_Properties


        #region private_variables
        //private int _TPropSlno;
        private string _PropertyID;
        private string _PropertyType;
        private string _Description;
        private string _TCreatedBy;
        private DateTime _TCreatedDate;
        private string _TModifiedBy;
        private DateTime _TModifiedDate;

        #endregion private_variables

        #region Properties
        //public int TPropSlno
        //{
        //    get { return _TPropSlno; }
        //    set { _TPropSlno = value; }
        //}
        public string PropertyID
        {
            get { return _PropertyID; }
            set { _PropertyID = value; }
        }
        public string PropertyType
        {
            get { return _PropertyType; }
            set { _PropertyType = value; }
        }
        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }

        public string TCreatedBy
        {
            get { return _TCreatedBy; }
            set { _TCreatedBy = value; }
        }
        public DateTime TCreatedDate
        {
            get { return _TCreatedDate; }
            set { _TCreatedDate = value; }
        }
        public string TModifiedBy
        {
            get { return _TModifiedBy; }
            set { _TModifiedBy = value; }
        }
        public DateTime TModifiedDate
        {
            get { return _TModifiedDate; }
            set { _TModifiedDate = value; }
        }
        #endregion Properties


        #endregion Tree_Properties

        #region Tree_Survey

        #region private_variables
       // private int _TreeSlno;
        private int _TSurveySlno;
        private int _TreeNo;
        private string _TInventoryType;
        private decimal _TSHeight;
        private decimal _X;
        private decimal _Y;
        private decimal _DBH;
        private string _TOPHEIGHT;
        private string _TSPropSlno;
        private string _StemCode;
        #endregion private_variables

        #region Properties
        //public int TreeSlno
        //{
        //    get { return _TreeSlno; }
        //    set { _TreeSlno = value; }
        //}
      
        public int TSurveySlno
        {
            get { return _TSurveySlno; }
            set { _TSurveySlno = value; }
        }
        public int TreeNo
        {
            get { return _TreeNo; }
            set { _TreeNo = value; }
        }
        public string TInventoryType
        {
            get { return _TInventoryType; }
            set { _TInventoryType = value; }
        }
        public decimal TSHeight
        {
            get { return _TSHeight; }
            set { _TSHeight = value; }
        }
        public decimal X
        {
            get { return _X; }
            set { _X = value; }
        }
        public decimal Y
        {
            get { return _Y; }
            set { _Y = value; }
        }
        public decimal DBH
        {
            get { return _DBH; }
            set { _DBH = value; }
        }
        public string TOPHEIGHT
        {
            get { return _TOPHEIGHT; }
            set { _TOPHEIGHT = value; }
        }
        public string TSPropSlno
        {
            get { return _TSPropSlno; }
            set { _TSPropSlno = value; }
        }
        public string StemCode
        {
            get { return _StemCode; }
            set { _StemCode = value; }
        }
        #endregion Properties
        #endregion Tree_Survey

        #region Tree_Images
        #region private_variables
       // private int _TreeImgSlno;
        private int _SurvyTreeSlno;
        private string _TreeImage;
        private string _TImageDescription;
        private string _TImageCreatedBy;
        private DateTime _TImageCreatedDate;
        private string _TImageModifiedBy;
        private DateTime _TImageModifiedDate;

        #endregion private_variables

        #region Properties
        //public int TreeImgSlno
        //{
        //    get { return _TreeImgSlno; }
        //    set { _TreeImgSlno = value; }
        //}
        public int SurvyTreeSlno
        {
            get { return _SurvyTreeSlno; }
            set { _SurvyTreeSlno = value; }
        }
        public string TreeImage
        {
            get { return _TreeImage; }
            set { _TreeImage = value; }
        }
        public string TImageDescription
        {
            get { return _TImageDescription; }
            set { _TImageDescription = value; }
        }

        public string TImageCreatedBy
        {
            get { return _TImageCreatedBy; }
            set { _TImageCreatedBy = value; }
        }
        public DateTime TImageCreatedDate
        {
            get { return _TImageCreatedDate; }
            set { _TImageCreatedDate = value; }
        }
        public string TImageModifiedBy
        {
            get { return _TImageModifiedBy; }
            set { _TImageModifiedBy = value; }
        }
        public DateTime TImageModifiedDate
        {
            get { return _TImageModifiedDate; }
            set { _TImageModifiedDate = value; }
        }
        #endregion
        #endregion Tree_Images

        #region Survey_Tree_PropDetails

        #region private_variables
       // private int _SurveyTreeSlno;
        private int _STreePropSlno;
        private int _SurveyPropSlNo;
        private int _PropCount;
        #endregion private_variables

        #region Properties
        //public int SurveyTreeSlno
        //{
        //    get { return _SurveyTreeSlno; }
        //    set { _SurveyTreeSlno = value; }
        //}

        public int STreePropSlno
        {
            get { return _STreePropSlno; }
            set { _STreePropSlno = value; }
        }
        public int SurveyPropSlNo
        {
            get { return _SurveyPropSlNo; }
            set { _SurveyPropSlNo = value; }
        }
        public int PropCount
        {
            get { return _PropCount; }
            set { _PropCount = value; }
        }

        #endregion Properties
        #endregion Survey_Tree_PropDetails

        #endregion Tree


    }
}

