﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    [Serializable]
    public class clsPQASync
    {
        public clsPQASync()
        {
        }
    }
    [Serializable]
    #region CompartmentData
    public class clsPQACompartmentData
    {
        #region Private Variables & Properties
        private string _CompSlno;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        private string _FeatID;

        public string FeatID
        {
            get { return _FeatID; }
            set { _FeatID = value; }
        }
        private string _PlantationSuperindent;

        public string PlantationSuperindent
        {
            get { return _PlantationSuperindent; }
            set { _PlantationSuperindent = value; }
        }
        private string _Fertilizer;

        public string Fertilizer
        {
            get { return _Fertilizer; }
            set { _Fertilizer = value; }
        }
        private string _OperationType;

        public string OperationType
        {
            get { return _OperationType; }
            set { _OperationType = value; }
        }
        private int? _TargetSpacing;

        public Nullable<int> TargetSpacing
        {
            get { return _TargetSpacing; }
            set { _TargetSpacing = value; }
        }

        private decimal? _QAPercentage;

        public Nullable<decimal> QAPercentage
        {
            get { return _QAPercentage; }
            set { _QAPercentage = value; }
        }

        private string _WONUMBER;

        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
        private string _CRTUSERID;

        public string CRTUSERID
        {
            get { return _CRTUSERID; }
            set { _CRTUSERID = value; }
        }
        private string _CRTDATE;

        public string CRTDATE
        {
            get { return _CRTDATE; }
            set { _CRTDATE = value; }
        }
        private string _MODUSERID;

        public string MODUSERID
        {
            get { return _MODUSERID; }
            set { _MODUSERID = value; }
        }
        private string _MODDATE;

        public string MODDATE
        {
            get { return _MODDATE; }
            set { _MODDATE = value; }
        }

        private string _AssessorCode;

        public string AssessorCode
        {
            get { return _AssessorCode; }
            set { _AssessorCode = value; }
        }
        private string _SAPID;

        public string SAPID
        {
            get { return _SAPID; }
            set { _SAPID = value; }
        }
        //Added Smrithy QADATE 05-11-2015
        private string _QADATE;

        public string QADATE
        {
            get { return _QADATE; }
            set { _QADATE = value; }
        }

        private string totalPlotNo;
        public string TotalPlotNo
        {
            get { return totalPlotNo; }
            set { totalPlotNo = value; }
        }
        #endregion Private Variables & Properties
    }

    #endregion CompartmentData

    [Serializable]
    #region PlotData
    public class clsPlotData
    {
        #region Private Variables & Properties
        private string _PLOTNO;

        public string PLOTNO
        {
            get { return _PLOTNO; }
            set { _PLOTNO = value; }
        }
        private string _REMARKS;

        public string REMARKS
        {
            get { return _REMARKS; }
            set { _REMARKS = value; }
        }
        private string _PDCRTUSERID;

        public string PDCRTUSERID
        {
            get { return _PDCRTUSERID; }
            set { _PDCRTUSERID = value; }
        }
        private string _PDCRTDATE;

        public string PDCRTDATE
        {
            get { return _PDCRTDATE; }
            set { _PDCRTDATE = value; }
        }
        private string _PDMODUSERID;

        public string PDMODUSERID
        {
            get { return _PDMODUSERID; }
            set { _PDMODUSERID = value; }
        }
        private string _PDMODDATE;

        public string PDMODDATE
        {
            get { return _PDMODDATE; }
            set { _PDMODDATE = value; }
        }

        //private int compSlno;
        public int CompSlno { get; set; }

        #endregion Private Variables & Properties

        
    }
    #endregion PlotData

    [Serializable]
    #region PlotGPS
    public class clsPlotGPS
    {
        #region Private Variables & Properties
        private string _Plotno;

        public string PlotNo
        {
            get { return _Plotno; }
            set { _Plotno = value; }
        }

        private string _GPSLat;

        public string GPSLat
        {
            get { return _GPSLat; }
            set { _GPSLat = value; }
        }
        private string _GPSLONG;

        public string GPSLONG
        {
            get { return _GPSLONG; }
            set { _GPSLONG = value; }
        }
        private string _treerowno;

        public string Treerowno
        {
            get { return _treerowno; }
            set { _treerowno = value; }
        }
        #endregion Private Variables & Properties
    }
    #endregion PlotGPS

    [Serializable]
    #region PlotHoleSize
    public class clsPlotHoleSize
    {
        #region Private Variables & Properties

        private string _Plotno;

        public string PlotNo
        {
            get { return _Plotno; }
            set { _Plotno = value; }
        }
        private string _TreeRowNo;

        public string TreeRowNo
        {
            get { return _TreeRowNo; }
            set { _TreeRowNo = value; }
        }
        private string _TreeNo1;

        public string TreeNo1
        {
            get { return _TreeNo1; }
            set { _TreeNo1 = value; }
        }
        private string _TreeNo2;

        public string TreeNo2
        {
            get { return _TreeNo2; }
            set { _TreeNo2 = value; }
        }
        private string _TreeNo3;

        public string TreeNo3
        {
            get { return _TreeNo3; }
            set { _TreeNo3 = value; }
        }
        private string _TreeNo4;

        public string TreeNo4
        {
            get { return _TreeNo4; }
            set { _TreeNo4 = value; }
        }
        private string _TreeNo5;

        public string TreeNo5
        {
            get { return _TreeNo5; }
            set { _TreeNo5 = value; }
        }
        #endregion Private Variables & Properties
    }
    #endregion PlotHoleSize

    [Serializable]
    #region PlotSpace
    public class clsPlotSpace
    {
        #region Private Variables & Properties
        private string _Plotno;

        public string PlotNo
        {
            get { return _Plotno; }
            set { _Plotno = value; }
        }
        private string _TreeRowNo;

        public string TreeRowNo
        {
            get { return _TreeRowNo; }
            set { _TreeRowNo = value; }
        }
        private string _BRI;

        public string BRI
        {
            get { return _BRI; }
            set { _BRI = value; }
        }
        private string _IRI;

        public string IRI
        {
            get { return _IRI; }
            set { _IRI = value; }
        }
        #endregion Private Variables & Properties
    }
    #endregion PlotSpace

    [Serializable]
    #region TreeQADetails
    public class clsTreeQADetails
    {
        #region Private Variables & Properties
        private string _Plotno;

        public string PlotNo
        {
            get { return _Plotno; }
            set { _Plotno = value; }
        }
        private string _TreeNo;

        public string TreeNo
        {
            get { return _TreeNo; }
            set { _TreeNo = value; }
        }
        private string _PropertyList;

        public string PropertyList
        {
            get { return _PropertyList; }
            set { _PropertyList = value; }
        }

        private string _SeedLotCodeList;

        public string SeedLotCodeList
        {
            get { return _SeedLotCodeList; }
            set { _SeedLotCodeList = value; }
        }

        private string _TreeRowno;

        public string TreeRowno
        {
            get { return _TreeRowno; }
            set { _TreeRowno = value; }
        }

        private string _ImageNameList;

        public string ImageNameList
        {
            get { return _ImageNameList; }
            set { _ImageNameList = value; }
        }

        private string _ImageDescription;

        public string ImageDescription
        {
            get { return _ImageDescription; }
            set { _ImageDescription = value; }
        }
        #endregion Private Variables & Properties

    }
    #endregion TreeQADetails

    [Serializable]
    #region TreeRowImages
    public class clsTreeRowImages
    {
        #region Private Variables & Properties
        private string _TreeRowImage;

        public string TreeRowImage
        {
            get { return _TreeRowImage; }
            set { _TreeRowImage = value; }
        }
        private string _Description;

        public string Description
        {
            get { return _Description; }
            set { _Description = value; }
        }
        private string _CRTUSERID;

        public string CRTUSERID
        {
            get { return _CRTUSERID; }
            set { _CRTUSERID = value; }
        }
        private string _CRTDATE;

        public string CRTDATE
        {
            get { return _CRTDATE; }
            set { _CRTDATE = value; }
        }
        private string _MODUSERID;

        public string MODUSERID
        {
            get { return _MODUSERID; }
            set { _MODUSERID = value; }
        }
        private string _MODDATE;

        public string MODDATE
        {
            get { return _MODDATE; }
            set { _MODDATE = value; }
        }
        private string _TreeRowno;

        public string TreeRowno
        {
            get { return _TreeRowno; }
            set { _TreeRowno = value; }
        }

        #endregion Private Variables & Properties
    }
    #endregion TreeRowImages

    [Serializable]
    #region Scores
    public class clsScores
    {
        #region Private Variables & Properties
        private string _Parameter;

        public string Parameter
        {
            get { return _Parameter; }
            set { _Parameter = value; }
        }
        private string _Score;

        public string Score
        {
            get { return _Score; }
            set { _Score = value; }
        }

        #endregion Private Variables & Properties
    }
    #endregion Scores



    #region QARegister
    public class clsQARegister
    {
        private string _TotalScore;

        public string TotalScore
        {
            get { return _TotalScore; }
            set { _TotalScore = value; }
        }
        private string _WOSTATUS;

        public string WOSTATUS
        {
            get { return _WOSTATUS; }
            set { _WOSTATUS = value; }
        }
    }
    #endregion
}
