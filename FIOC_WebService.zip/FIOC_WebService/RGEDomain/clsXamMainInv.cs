﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsXamMainInv
    {
        clsXamCompartment Compartment = new clsXamCompartment();
      

    }
        public class clsXamCompartment
        {
            #region private_variables
            private string _CompSlno;

            private string _COMPNO;
            private string _Sector;
            private string _Estate;
            private string _Tot_HA;
            private string _SpeciesID;
            private string _CompImage;
            #endregion

            #region Properties
            public string CompSlno
            {
                get { return _CompSlno; }
                set { _CompSlno = value; }
            }
            public string COMPNO
            {
                get { return _COMPNO; }
                set { _COMPNO = value; }
            }
            public string Sector
            {
                get { return _Sector; }
                set { _Sector = value; }
            }
            public string Estate
            {
                get { return _Estate; }
                set { _Estate = value; }
            }
            public string Tot_HA
            {
                get { return _Tot_HA; }
                set { _Tot_HA = value; }
            }
            public string SpeciesID
            {
                get { return _SpeciesID; }
                set { _SpeciesID = value; }
            }

            public string CompImage
            {
                get { return _CompImage; }
                set { _CompImage = value; }
            }
            #endregion 

            public List<clsXamPlot> Plots = new List<clsXamPlot>();
        }
        public class clsXamPlot
        {
            #region Plot
            #region private_variables
         
            private string _PlotNo;
            private int _CompSlno;
            private string _PlotRadius;
            private string _GPSLat;
            private string _GPSLong;
            private string _SamplePercentage;
            private string _PRemarks;
            private string _PCreatedBy;
            private string _PCreatedDate;
            private string _PModifiedBy;
            private string _PModifiedDate;



            #endregion private_variables

            #region Properties
           
            public string PlotNo
            {
                get { return _PlotNo; }
                set { _PlotNo = value; }
            }
            public int CompSlno
            {
                get { return _CompSlno; }
                set { _CompSlno = value; }
            }
            public string PlotRadius
            {
                get { return _PlotRadius; }
                set { _PlotRadius = value; }
            }
            public string GPSLat
            {
                get { return _GPSLat; }
                set { _GPSLat = value; }
            }
            public string GPSLong
            {
                get { return _GPSLong; }
                set { _GPSLong = value; }
            }
            public string SamplePercentage
            {
                get { return _SamplePercentage; }
                set { _SamplePercentage = value; }
            }
            public string PRemarks
            {
                get { return _PRemarks; }
                set { _PRemarks = value; }
            }

            public string PCreatedBy
            {
                get { return _PCreatedBy; }
                set { _PCreatedBy = value; }
            }
            public string PCreatedDate
            {
                get { return _PCreatedDate; }
                set { _PCreatedDate = value; }
            }
            public string PModifiedBy
            {
                get { return _PModifiedBy; }
                set { _PModifiedBy = value; }
            }
            public string PModifiedDate
            {
                get { return _PModifiedDate; }
                set { _PModifiedDate = value; }
            }
            #endregion
            #endregion Plot

            public List<clsXamSurvey> Survey = new List<clsXamSurvey>();
        }

        public class clsXamSurvey
        {
            #region Survey
            #region private_variables

      
            private string _SurveyNo;
            private string _SurveyDate;

            private string _SInventoryType;
            private string _SurveyStatus;
            private int _EmpID;
            private string _TeamCode;
            private string _SurveyLineNo;
            private string _AzimuthPlotLine;

            private string _SRemarks;
            private string _MaintainenceStatus;
            private string _Flooding;
            private string _SoilSampleCollected;
            private string _UUID;
            private string _Name;
            private string _SAPID;
            private string _ErrorStatus;

            private string _SCreatedBy;
            private string _SCreatedDate;
            private string _SModifiedBy;
            private string _SModifiedDate;

            private string _Keyedinby;
            private string _TotalLiveYellow;
            private string _TotalDead;
            private string _TotalHealthy;
            private string _GPSLat;
            private string _GPSLong;
            private string _ErrorSurveySlno;

          
            #endregion private_variables

            #region Properties
         

            public string SurveyNo
            {
                get { return _SurveyNo; }
                set { _SurveyNo = value; }
            }
            public string SurveyDate
            {
                get { return _SurveyDate; }
                set { _SurveyDate = value; }
            }

            public string SInventoryType
            {
                get { return _SInventoryType; }
                set { _SInventoryType = value; }
            }
            public string SurveyStatus
            {
                get { return _SurveyStatus; }
                set { _SurveyStatus = value; }
            }
            public int EmpID
            {
                get { return _EmpID; }
                set { _EmpID = value; }
            }
            public string TeamCode
            {
                get { return _TeamCode; }
                set { _TeamCode = value; }
            }
            public string SurveyLineNo
            {
                get { return _SurveyLineNo; }
                set { _SurveyLineNo = value; }
            }
            public string AzimuthPlotLine
            {
                get { return _AzimuthPlotLine; }
                set { _AzimuthPlotLine = value; }
            }

            public string SRemarks
            {
                get { return _SRemarks; }
                set { _SRemarks = value; }
            }
            public string MaintainenceStatus
            {
                get { return _MaintainenceStatus; }
                set { _MaintainenceStatus = value; }
            }
            public string Flooding
            {
                get { return _Flooding; }
                set { _Flooding = value; }
            }
            public string SoilSampleCollected
            {
                get { return _SoilSampleCollected; }
                set { _SoilSampleCollected = value; }
            }
            public string UUID
            {
                get { return _UUID; }
                set { _UUID = value; }
            }
            public string Name
            {
                get { return _Name; }
                set { _Name = value; }
            }
            public string SAPID
            {
                get { return _SAPID; }
                set { _SAPID = value; }
            }
            public string ErrorStatus
            {
                get { return _ErrorStatus; }
                set { _ErrorStatus = value; }
            }


            public string SCreatedBy
            {
                get { return _SCreatedBy; }
                set { _SCreatedBy = value; }
            }
            public string SCreatedDate
            {
                get { return _SCreatedDate; }
                set { _SCreatedDate = value; }
            }
            public string SModifiedBy
            {
                get { return _SModifiedBy; }
                set { _SModifiedBy = value; }
            }
            public string SModifiedDate
            {
                get { return _SModifiedDate; }
                set { _SModifiedDate = value; }
            }

            public string Keyedinby
            {
                get { return _Keyedinby; }
                set { _Keyedinby = value; }
            }
            public string TotalLiveYellow
            {
                get { return _TotalLiveYellow; }
                set { _TotalLiveYellow = value; }
            }

            public string TotalDead
            {
                get { return _TotalDead; }
                set { _TotalDead = value; }
            }

            public string TotalHealthy
            {
                get { return _TotalHealthy; }
                set { _TotalHealthy = value; }
            }

            public string GPSLat
            {
                get { return _GPSLat; }
                set { _GPSLat = value; }
            }

            public string GPSLong
            {
                get { return _GPSLong; }
                set { _GPSLong = value; }
            }
            public string ErrorSurveySlno
            {
                get { return _ErrorSurveySlno; }
                set { _ErrorSurveySlno = value; }
            }
            #endregion
            #endregion Survey
        }
    }

