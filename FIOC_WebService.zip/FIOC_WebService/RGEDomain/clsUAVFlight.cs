﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsUAVFlight
    {
        #region Private Variables & Properties
        private string _FlightID;

        public string FlightID
        {
            get { return _FlightID; }
            set { _FlightID = value; }
        }
        private string _Flightdate;

        public string Flightdate
        {
            get { return _Flightdate; }
            set { _Flightdate = value; }
        }
        private string _FEATID;

        public string FEATID
        {
            get { return _FEATID; }
            set { _FEATID = value; }
        }
        private string _Age;

        public string Age
        {
            get { return _Age; }
            set { _Age = value; }
        }
        private string _Species;

        public string Species
        {
            get { return _Species; }
            set { _Species = value; }
        }
        private decimal _TreeCount;

        public decimal TreeCount
        {
            get { return _TreeCount; }
            set { _TreeCount = value; }
        }
        private Double _AreaSize;

        public Double AreaSize
        {
            get { return _AreaSize; }
            set { _AreaSize = value; }
        }
        private Double _Stocking;

        public Double Stocking
        {
            get { return _Stocking; }
            set { _Stocking = value; }
        }
        private string _ProcessedImagePath;

        public string ProcessedImagePath
        {
            get { return _ProcessedImagePath; }
            set { _ProcessedImagePath = value; }
        }
        private string _KMLFilePath;

        public string KMLFilePath
        {
            get { return _KMLFilePath; }
            set { _KMLFilePath = value; }
        }
        private string _ExecID;

        public string ExecID
        {
            get { return _ExecID; }
            set { _ExecID = value; }
        }
        private DateTime _Starttime;

        public DateTime Starttime
        {
            get { return _Starttime; }
            set { _Starttime = value; }
        }
        private DateTime _Endtime;

        public DateTime Endtime
        {
            get { return _Endtime; }
            set { _Endtime = value; }
        }
        private string _Assisten;

        public string Assisten
        {
            get { return _Assisten; }
            set { _Assisten = value; }
        }
        private string _Contractor;

        public string Contractor
        {
            get { return _Contractor; }
            set { _Contractor = value; }
        }

        private string _ESTDATE;

        public string ESTDATE
        {
            get { return _ESTDATE; }
            set { _ESTDATE = value; }
        }


        private string _SEEDLOTID;

        public string SEEDLOTID
        {
            get { return _SEEDLOTID; }
            set { _SEEDLOTID = value; }
        }
        private Decimal _SPACING;

        public Decimal SPACING
        {
            get { return _SPACING; }
            set { _SPACING = value; }
        }

        private double _EastCord;

        public double EastCord
        {
            get { return _EastCord; }
            set { _EastCord = value; }
        }

        private double _WestCord;

        public double WestCord
        {
            get { return _WestCord; }
            set { _WestCord = value; }
        }
        private double _NorthCord;

        public double NorthCord
        {
            get { return _NorthCord; }
            set { _NorthCord = value; }
        }
        private double _SouthCord;

        public double SouthCord
        {
            get { return _SouthCord; }
            set { _SouthCord = value; }
        }

        public string ImageType { get; set; }
        public decimal? LowTreshold { get; set; }
        public decimal? HighTreshold { get; set; }

        #endregion Private Variables & Properties
    }

    public class clsResponseUAVFlight
    {
        #region Private Variables & Properties
        private string _FlightID;

        public string FlightID
        {
            get { return _FlightID; }
            set { _FlightID = value; }
        }
        private string _Flightdate;

        public string Flightdate
        {
            get { return _Flightdate; }
            set { _Flightdate = value; }
        }
        private string _FEATID;

        public string FEATID
        {
            get { return _FEATID; }
            set { _FEATID = value; }
        }
        private string _Age;

        public string Age
        {
            get { return _Age; }
            set { _Age = value; }
        }
        private string _Species;

        public string Species
        {
            get { return _Species; }
            set { _Species = value; }
        }
        private decimal _TreeCount;

        public decimal TreeCount
        {
            get { return _TreeCount; }
            set { _TreeCount = value; }
        }
        private Double _AreaSize;

        public Double AreaSize
        {
            get { return _AreaSize; }
            set { _AreaSize = value; }
        }
        private Double _Stocking;

        public Double Stocking
        {
            get { return _Stocking; }
            set { _Stocking = value; }
        }
        private string _ProcessedImagePath;

        public string ProcessedImagePath
        {
            get { return _ProcessedImagePath; }
            set { _ProcessedImagePath = value; }
        }
        private string _KMLFilePath;

        public string KMLFilePath
        {
            get { return _KMLFilePath; }
            set { _KMLFilePath = value; }
        }
        private string _ExecID;

        public string ExecID
        {
            get { return _ExecID; }
            set { _ExecID = value; }
        }
        private string _Starttime;

        public string Starttime
        {
            get { return _Starttime; }
            set { _Starttime = value; }
        }
        private string _Endtime;

        public string Endtime
        {
            get { return _Endtime; }
            set { _Endtime = value; }
        }
        private string _Assisten;

        public string Assisten
        {
            get { return _Assisten; }
            set { _Assisten = value; }
        }
        private string _Contractor;

        public string Contractor
        {
            get { return _Contractor; }
            set { _Contractor = value; }
        }

        private string _ESTDATE;

        public string ESTDATE
        {
            get { return _ESTDATE; }
            set { _ESTDATE = value; }
        }


        private string _SEEDLOTID;

        public string SEEDLOTID
        {
            get { return _SEEDLOTID; }
            set { _SEEDLOTID = value; }
        }
        private Decimal _SPACING;

        public Decimal SPACING
        {
            get { return _SPACING; }
            set { _SPACING = value; }
        }

        private double _EastCord;

        public double EastCord
        {
            get { return _EastCord; }
            set { _EastCord = value; }
        }

        private double _WestCord;

        public double WestCord
        {
            get { return _WestCord; }
            set { _WestCord = value; }
        }
        private double _NorthCord;

        public double NorthCord
        {
            get { return _NorthCord; }
            set { _NorthCord = value; }
        }
        private double _SouthCord;

        public double SouthCord
        {
            get { return _SouthCord; }
            set { _SouthCord = value; }
        }

        public string ImageType { get; set; }
        public decimal? LowTreshold { get; set; }
        public decimal? HighTreshold { get; set; }

        #endregion Private Variables & Properties
    }
}
