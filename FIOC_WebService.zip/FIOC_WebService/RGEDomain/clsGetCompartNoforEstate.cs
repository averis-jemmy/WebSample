﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsGetCompartNoforEstate
    {
        private string _FEATID;

        public string FEATID
        {
            get { return _FEATID; }
            set { _FEATID = value; }
        }
        private string _Compartment;

        public string Compartment
        {
            get { return _Compartment; }
            set { _Compartment = value; }
        }
    }
}
