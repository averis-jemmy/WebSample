﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsMainWeather
    {
        public List<clsWeather> Weathers = new List<clsWeather>();
    }
}
