﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    
    public class clsInventory
    {
        
    public ddComp Compartment;
    
    public List<ddPlot> Plot = new List<ddPlot>();
    public clsInventory()
    { }
    public clsInventory(ddComp obj, List<ddPlot> obj2)
    {
        this.Compartment = obj;
        this.Plot = obj2;

    }
    }
    
    public class ddComp
    {
        private string _compartmentNo;
        private string _contractorCode;
        private string _contractorName;
        private string _surveyStatus;
        private string _compslno;
        public string compartmentNo
        {
            get { return _compartmentNo; }
            set { _compartmentNo = value; }
        }
        public string contractorCode
        {
            get { return _contractorCode; }
            set { _contractorCode = value; }
        }
        public string contractorName
        {
            get { return _contractorName; }
            set { _contractorName = value; }
        }
        public string surveyStatus
        {
            get { return _surveyStatus; }
            set { _surveyStatus = value; }
        }
        public string compslno
        {
            get { return _compslno; }
            set { _compslno = value; }
        }
    }
    public class ddPlot
    {
        #region Plot
        #region private_variables

        private string _PlotNo;
        private string _CompSlno;
        private string _PlotRadius;
        private string _GPSLat;
        private string _GPSLong;
        private string _SamplePercentage;
        private string _PRemarks;
        private string _PCreatedBy;
        private string _PCreatedDate;
        private string _PModifiedBy;
        private string _PModifiedDate;



        #endregion private_variables

        #region Properties

        public string PlotNo
        {
            get { return _PlotNo; }
            set { _PlotNo = value; }
        }
        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        public string PlotRadius
        {
            get { return _PlotRadius; }
            set { _PlotRadius = value; }
        }
        public string GPSLat
        {
            get { return _GPSLat; }
            set { _GPSLat = value; }
        }
        public string GPSLong
        {
            get { return _GPSLong; }
            set { _GPSLong = value; }
        }
        public string SamplePercentage
        {
            get { return _SamplePercentage; }
            set { _SamplePercentage = value; }
        }
        public string PRemarks
        {
            get { return _PRemarks; }
            set { _PRemarks = value; }
        }

        public string PCreatedBy
        {
            get { return _PCreatedBy; }
            set { _PCreatedBy = value; }
        }
        public string PCreatedDate
        {
            get { return _PCreatedDate; }
            set { _PCreatedDate = value; }
        }
        public string PModifiedBy
        {
            get { return _PModifiedBy; }
            set { _PModifiedBy = value; }
        }
        public string PModifiedDate
        {
            get { return _PModifiedDate; }
            set { _PModifiedDate = value; }
        }
        #endregion
        #endregion Plot

        public ddSurvey Survey = new ddSurvey();
        public List<ddTree> TreeData = new List<ddTree>();
        public List<ddTreeImages> TreeImage = new List<ddTreeImages>();
       
     

    }
    #region Survey
    public class ddSurvey
    {

        #region private_variables


        private string _SurveyNo;
        private string _SurveyDate;
        private string _SInventoryType;
        private string _SurveyStatus;
        private string _EmpID;
        private string _TeamCode;
        private string _SurveyLineNo;
        private string _AzimuthPlotLine;
      
        private string _SRemarks;
        private string _MaintainenceStatus;
        private string _Flooding;
        private string _SoilSampleCollected;
        private string _UUID;
        private string _Name;
        private string _SAPID;
        private string _ErrorStatus;
       
        private string _SCreatedBy;
        private string _SCreatedDate;
        private string _SModifiedBy;
        private string _SModifiedDate;
            
        private string _Keyedinby;

        private string _TotalLiveYellow;
        private string _TotalDead;
        private string _TotalHealthy;
        private string _GPSLat;
        private string _GPSLong;

       
        #endregion private_variables

        #region Properties

        public string SurveyNo
        {
            get { return _SurveyNo; }
            set { _SurveyNo = value; }
        }
        public string SurveyDate
        {
            get { return _SurveyDate; }
            set { _SurveyDate = value; }
        }
       
        public string SInventoryType
        {
            get { return _SInventoryType; }
            set { _SInventoryType = value; }
        }
        public string SurveyStatus       

        {
            get { return _SurveyStatus; }
            set { _SurveyStatus = value; }
        }
        public string SurveyLineNo
        {
            get { return _SurveyLineNo; }
            set { _SurveyLineNo = value; }
        }
        public string EmpID
        {
            get { return _EmpID; }
            set { _EmpID = value; }
        }
        public string TeamCode
        {
            get { return _TeamCode; }
            set { _TeamCode = value; }
        }
        public string AzimuthPlotLine
        {
            get { return _AzimuthPlotLine; }
            set { _AzimuthPlotLine = value; }
        }
        
        public string SRemarks
        {
            get { return _SRemarks; }
            set { _SRemarks = value; }
        }
        public string MaintainenceStatus
        {
            get { return _MaintainenceStatus; }
            set { _MaintainenceStatus = value; }
        }
        public string Flooding
        {
            get { return _Flooding; }
            set { _Flooding = value; }
        }
        public string SoilSampleCollected
        {
            get { return _SoilSampleCollected; }
            set { _SoilSampleCollected = value; }
        }
        public string UUID
        {
            get { return _UUID; }
            set { _UUID = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string SAPID
        {
            get { return _SAPID; }
            set { _SAPID = value; }
        }
        public string ErrorStatus
        {
            get { return _ErrorStatus; }
            set { _ErrorStatus = value; }
        }

      
        public string SCreatedBy
        {
            get { return _SCreatedBy; }
            set { _SCreatedBy = value; }
        }
        public string SCreatedDate
        {
            get { return _SCreatedDate; }
            set { _SCreatedDate = value; }
        }
        public string SModifiedBy
        {
            get { return _SModifiedBy; }
            set { _SModifiedBy = value; }
        }
        public string SModifiedDate
        {
            get { return _SModifiedDate; }
            set { _SModifiedDate = value; }
        }
       
        public string Keyedinby
        {
            get { return _Keyedinby; }
            set { _Keyedinby = value; }
        }
        public string TotalLiveYellow
        {
            get { return _TotalLiveYellow; }
            set { _TotalLiveYellow = value; }
        }

        public string TotalDead
        {
            get { return _TotalDead; }
            set { _TotalDead = value; }
        }

        public string TotalHealthy
        {
            get { return _TotalHealthy; }
            set { _TotalHealthy = value; }
        }

        public string GPSLat
        {
            get { return _GPSLat; }
            set { _GPSLat = value; }
        }


        public string GPSLong
        {
            get { return _GPSLong; }
            set { _GPSLong = value; }
        }
        #endregion
    #endregion Survey

        
    }
    #region Tree_Survey_Images

    #region Tree_Survey
    public class ddTree
    {
        
        #region private_variables

        private string _TSurveySlno;
        private string _TreeNo;
        private string _TInventoryType;
        private string _Height;
        private string _X;
        private string _Y;
        private string _DBH;
        private string _TOPHEIGHT;
        private string _TSPropSlno;
        private string _StemCode;

        #endregion private_variables


        #region Properties

        public string TSurveySlno
        {
            get { return _TSurveySlno; }
            set { _TSurveySlno = value; }
        }
        public string TreeNo
        {
            get { return _TreeNo; }
            set { _TreeNo = value; }
        }
        public string TInventoryType
        {
            get { return _TInventoryType; }
            set { _TInventoryType = value; }
        }
        public string Height
        {
            get { return _Height; }
            set { _Height = value; }
        }
        public string X
        {
            get { return _X; }
            set { _X = value; }
        }
        public string Y
        {
            get { return _Y; }
            set { _Y = value; }
        }
        public string DBH
        {
            get { return _DBH; }
            set { _DBH = value; }
        }
        public string TOPHEIGHT
        {
            get { return _TOPHEIGHT; }
            set { _TOPHEIGHT = value; }
        }
        public string TSPropSlno
        {
            get { return _TSPropSlno; }
            set { _TSPropSlno = value; }
        }
        public string StemCode
        {
            get { return _StemCode; }
            set { _StemCode = value; }
        }

       
        #endregion Properties 
        

    }
    #endregion  Tree_Survey

    #region Tree_Image
    public class ddTreeImages
    {
        #region Tree_Images
        #region private_variables
        private int _TreeImgSlno;
        private int _SurvyTreeSlno;
        private string _TreeImage;
        private string _TImageDescription;
        private string _TImageCreatedBy;
        private DateTime _TImageCreatedDate;
        private string _TImageModifiedBy;
        private DateTime _TImageModifiedDate;

        #endregion private_variables

        #region Properties
        public int TreeImgSlno
        {
            get { return _TreeImgSlno; }
            set { _TreeImgSlno = value; }
        }
        public int SurvyTreeSlno
        {
            get { return _SurvyTreeSlno; }
            set { _SurvyTreeSlno = value; }
        }
        public string TreeImage
        {
            get { return _TreeImage; }
            set { _TreeImage = value; }
        }
        public string TImageDescription
        {
            get { return _TImageDescription; }
            set { _TImageDescription = value; }
        }

        public string TImageCreatedBy
        {
            get { return _TImageCreatedBy; }
            set { _TImageCreatedBy = value; }
        }
        public DateTime TImageCreatedDate
        {
            get { return _TImageCreatedDate; }
            set { _TImageCreatedDate = value; }
        }
        public string TImageModifiedBy
        {
            get { return _TImageModifiedBy; }
            set { _TImageModifiedBy = value; }
        }
        public DateTime TImageModifiedDate
        {
            get { return _TImageModifiedDate; }
            set { _TImageModifiedDate = value; }
        }
        #endregion Properties
        #endregion Tree_Images

    }
    #endregion Tree_Image
  
    #endregion Tree_Survey_Images

    #region PlotSpacing
    public class ddPlotSpace
    {
        #region Plot_Spacing

        #region private_variables
        private string _SpacePlotSlno;
        private string _BRI;
        private string _IRI;
        #endregion private_variables

        #region Properties
        public string SpacePlotSlno
        {
            get { return _SpacePlotSlno; }
            set { _SpacePlotSlno = value; }
        }
        public string BRI
        {
            get { return _BRI; }
            set { _BRI = value; }
        }
        public string IRI
        {
            get { return _IRI; }
            set { _IRI = value; }
        }
        #endregion Properties
        #endregion Plot_Spacing
    }
    #endregion PlotSpacing


    #region Survey_Tree_PropDetails
    public class ddSurveyTreeProp
    {
        #region Survey_Tree_PropDetails

        #region private_variables
        // private int _SurveyTreeSlno;
        private string _STreePropSlno;
        private string _SurveyPropSlNo;
        private string _PropCount;
        #endregion private_variables

        #region Properties
        //public int SurveyTreeSlno
        //{
        //    get { return _SurveyTreeSlno; }
        //    set { _SurveyTreeSlno = value; }
        //}

        public string STreePropSlno
        {
            get { return _STreePropSlno; }
            set { _STreePropSlno = value; }
        }
        public string SurveyPropSlNo
        {
            get { return _SurveyPropSlNo; }
            set { _SurveyPropSlNo = value; }
        }
        public string PropCount
        {
            get { return _PropCount; }
            set { _PropCount = value; }
        }

        #endregion Properties
        #endregion Survey_Tree_PropDetails
    } 
    #endregion Survey_Tree_PropDetails
      
}
