﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    [Serializable]
    public class clsHQASync
    {
        public clsHQASync()
        {
        }
    }
    [Serializable]
    #region HQACompartment
    public class clsHQACompartment
    {
        #region  Private Variables & Properties
        private string _WONUMBER;

        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
        private string _FeatID;

        public string FeatID
        {
            get { return _FeatID; }
            set { _FeatID = value; }
        }
        private string _HarvestingAskep;

        public string HarvestingAskep
        {
            get { return _HarvestingAskep; }
            set { _HarvestingAskep = value; }
        }
        private string _PlanningAsst;

        public string PlanningAsst
        {
            get { return _PlanningAsst; }
            set { _PlanningAsst = value; }
        }
        private string _VegetationType;

        public string VegetationType
        {
            get { return _VegetationType; }
            set { _VegetationType = value; }
        }
        private string _HarvestingSystem;

        public string HarvestingSystem
        {
            get { return _HarvestingSystem; }
            set { _HarvestingSystem = value; }
        }
        private string _Status;

        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _TotalRWAPlots;

        public string TotalRWAPlots
        {
            get { return _TotalRWAPlots; }
            set { _TotalRWAPlots = value; }
        }
        private string _TotalMerchantableWood;

        public string TotalMerchantableWood
        {
            get { return _TotalMerchantableWood; }
            set { _TotalMerchantableWood = value; }
        }
        private string _TotalWasteWood;

        public string TotalWasteWood
        {
            get { return _TotalWasteWood; }
            set { _TotalWasteWood = value; }
        }
        private string _AvgWood;

        public string AvgWood
        {
            get { return _AvgWood; }
            set { _AvgWood = value; }
        }
        private string _TotalHQAPlots;

        public string TotalHQAPlots
        {
            get { return _TotalHQAPlots; }
            set { _TotalHQAPlots = value; }
        }
        private string _AvgHQAScore;

        public string AvgHQAScore
        {
            get { return _AvgHQAScore; }
            set { _AvgHQAScore = value; }
        }

        private string _Assessor;

        public string Assessor
        {
            get { return _Assessor; }
            set { _Assessor = value; }
        }
        private string _CRTUSERID;

        public string CRTUSERID
        {
            get { return _CRTUSERID; }
            set { _CRTUSERID = value; }
        }
        private string _CRTDATE;

        public string CRTDATE
        {
            get { return _CRTDATE; }
            set { _CRTDATE = value; }
        }
        private string _MODUSERID;

        public string MODUSERID
        {
            get { return _MODUSERID; }
            set { _MODUSERID = value; }
        }
        private string _MODDATE;

        public string MODDATE
        {
            get { return _MODDATE; }
            set { _MODDATE = value; }
        }
        //Added Smrithy QADATE 05-11-2015
        private string _QADATE;

        public string QADATE
        {
            get { return _QADATE; }
            set { _QADATE = value; }
        }

        #endregion  Private Variables & Properties
    }
    #endregion HQACompartment

    [Serializable]

    #region RWAPlotSData
    public class clsRWAPlotSData
    {
        #region  Private Variables & Properties
        private string _PLOTNO;

        public string PLOTNO
        {
            get { return _PLOTNO; }
            set { _PLOTNO = value; }
        }
        private string _PlotGpsLat;

        public string PlotGpsLat
        {
            get { return _PlotGpsLat; }
            set { _PlotGpsLat = value; }
        }
        private string _PlotGpsLong;

        public string PlotGpsLong
        {
            get { return _PlotGpsLong; }
            set { _PlotGpsLong = value; }
        }
        private string _RecordedDate;

        public string RecordedDate
        {
            get { return _RecordedDate; }
            set { _RecordedDate = value; }
        }
        private string _CompSlno;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        private string _REMARKS;

        public string REMARKS
        {
            get { return _REMARKS; }
            set { _REMARKS = value; }
        }
        private string _CRTUSERID;

        public string CRTUSERID
        {
            get { return _CRTUSERID; }
            set { _CRTUSERID = value; }
        }
        private string _CRTDATE;

        public string CRTDATE
        {
            get { return _CRTDATE; }
            set { _CRTDATE = value; }
        }
        private string _MODUSERID;

        public string MODUSERID
        {
            get { return _MODUSERID; }
            set { _MODUSERID = value; }
        }
        private string _MODDATE;

        public string MODDATE
        {
            get { return _MODDATE; }
            set { _MODDATE = value; }
        }
        #endregion  Private Variables & Properties
    }
    #endregion RWAPlotSData

    [Serializable]
    #region HQATreeDetails
    public class clsHQATreeDetails
    {
        #region  Private Variables & Properties
        private string _CompSlno;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        private string _HQASerialNo;

        public string HQASerialNo
        {
            get { return _HQASerialNo; }
            set { _HQASerialNo = value; }
        }
        private string _PlotNo;

        public string PlotNo
        {
            get { return _PlotNo; }
            set { _PlotNo = value; }
        }
        private string _CavityCount;

        public string CavityCount
        {
            get { return _CavityCount; }
            set { _CavityCount = value; }
        }
        private string _DebrisCount;

        public string DebrisCount
        {
            get { return _DebrisCount; }
            set { _DebrisCount = value; }
        }

        //Added for Iamge Name & Desc
        private string _ImageNameList;

        public string ImageNameList
        {
            get { return _ImageNameList; }
            set { _ImageNameList = value; }
        }


        private string _ImageDescription;

        public string ImageDescription
        {
            get { return _ImageDescription; }
            set { _ImageDescription = value; }
        }
        #endregion  Private Variables & Properties
    }
    #endregion HQATreeDetails

    [Serializable]
    #region RWATreeDetails
    public class clsRWATreeDetails
    {
        #region  Private Variables & Properties
        private string _PlotSlno;

        public string PlotSlno
        {
            get { return _PlotSlno; }
            set { _PlotSlno = value; }
        }


        private string _Plotno;

        public string PlotNo
        {
            get { return _Plotno; }
            set { _Plotno = value; }
        }
        private string _TreeNo;

        public string TreeNo
        {
            get { return _TreeNo; }
            set { _TreeNo = value; }
        }
        private string _PropList;

        public string PropList
        {
            get { return _PropList; }
            set { _PropList = value; }
        }
        private string _Diameter;

        public string Diameter
        {
            get { return _Diameter; }
            set { _Diameter = value; }
        }
        private string _HeightLength;

        public string HeightLength
        {
            get { return _HeightLength; }
            set { _HeightLength = value; }
        }
        private string _ImageNameList;

        public string ImageNameList
        {
            get { return _ImageNameList; }
            set { _ImageNameList = value; }
        }



        private string _TotalVolume;

        public string TotalVolume
        {
            get { return _TotalVolume; }
            set { _TotalVolume = value; }
        }

        //Added for Iamge Desc
        private string _ImageDescription;

        public string ImageDescription
        {
            get { return _ImageDescription; }
            set { _ImageDescription = value; }
        }
        #endregion  Private Variables & Properties
    }
    #endregion RWATreeDetails

    [Serializable]
    #region EAScores
    public class clsEAScores
    {
        #region  Private Variables & Properties
        private string _CompSlno;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        private string _Parameter;

        public string Parameter
        {
            get { return _Parameter; }
            set { _Parameter = value; }
        }
        private string _Score;

        public string Score
        {
            get { return _Score; }
            set { _Score = value; }
        }
        private string _OilContaminationGPSLat;

        public string OilContaminationGPSLat
        {
            get { return _OilContaminationGPSLat; }
            set { _OilContaminationGPSLat = value; }
        }
        private string _OilContaminationGPSLong;

        public string OilContaminationGPSLong
        {
            get { return _OilContaminationGPSLong; }
            set { _OilContaminationGPSLong = value; }
        }
        private string _Notes;

        public string Notes
        {
            get { return _Notes; }
            set { _Notes = value; }
        }

        private string _Status;

        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        #endregion  Private Variables & Properties
    }
    #endregion EAScores

    [Serializable]
    #region HQAScores
    public class clsHQAScores
    {
        #region  Private Variables & Properties
        private string _CompSlno;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }

        private string _Parameter;

        public string Parameter
        {
            get { return _Parameter; }
            set { _Parameter = value; }
        }
        private string _Score;

        public string Score
        {
            get { return _Score; }
            set { _Score = value; }
        }
        private string _Type;

        public string Type
        {
            get { return _Type; }
            set { _Type = value; }
        }
        #endregion Private Variables & Properties
    }
    #endregion HQAScores

    //Added for Score Images
    [Serializable]
    #region ScoreImaages
    public class clsScoreImages
    {
        private string _Category;

        public string Category
        {
            get { return _Category; }
            set { _Category = value; }
        }
        private string _ImageName;

        public string ImageName
        {
            get { return _ImageName; }
            set { _ImageName = value; }
        }
        private string _ImageDescription;

        public string ImageDescription
        {
            get { return _ImageDescription; }
            set { _ImageDescription = value; }
        }
        private string _CRTUSERID;
        public string CRTUSERID
        {
            get { return _CRTUSERID; }
            set { _CRTUSERID = value; }
        }
        private string _CRTDATE;

        public string CRTDATE
        {
            get { return _CRTDATE; }
            set { _CRTDATE = value; }
        }
        private string _MODUSERID;

        public string MODUSERID
        {
            get { return _MODUSERID; }
            set { _MODUSERID = value; }
        }
        private string _MODDATE;

        public string MODDATE
        {
            get { return _MODDATE; }
            set { _MODDATE = value; }
        }
    }
    #endregion ScoreImaages

}
