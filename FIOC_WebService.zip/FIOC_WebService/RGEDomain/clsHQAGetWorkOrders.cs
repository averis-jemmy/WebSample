﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsHQAGetWorkOrders
    {
        private string _TypeOfAssessment;

        public string TypeOfAssessment
        {
            get { return _TypeOfAssessment; }
            set { _TypeOfAssessment = value; }
        }
        private string _WONUMBER;

        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
        private string _ESTATE;

        public string ESTATE
        {
            get { return _ESTATE; }
            set { _ESTATE = value; }
        }
        private string _COMPNO;

        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }

        private string _COMPIMAGE;
        public string COMPIMAGE
        {
            get { return _COMPIMAGE; }
            set { _COMPIMAGE = value; }
        }

        private string _DateOfIssue;

        public string DateOfIssue
        {
            get { return _DateOfIssue; }
            set { _DateOfIssue = value; }
        }
        private decimal _TOTHA;

        public decimal TOTHA
        {
            get { return _TOTHA; }
            set { _TOTHA = value; }
        }
        private string _NAME;

        public string NAME
        {
            get { return _NAME; }
            set { _NAME = value; }
        }
        private string _SPVCODE;

        public string SPVCODE
        {
            get { return _SPVCODE; }
            set { _SPVCODE = value; }
        }
        private string _FOREMANID;

        public string FOREMANID
        {
            get { return _FOREMANID; }
            set { _FOREMANID = value; }
        }
        private string _FOREMANNAME;

        public string FOREMANNAME
        {
            get { return _FOREMANNAME; }
            set { _FOREMANNAME = value; }
        }
        private string _SPVNAME;

        public string SPVNAME
        {
            get { return _SPVNAME; }
            set { _SPVNAME = value; }
        }
        //Added By Smrithy 04-11-2015
        private string _JC;

        public string JC
        {
            get { return _JC; }
            set { _JC = value; }
        }
        private string _OC;

        public string OC
        {
            get { return _OC; }
            set { _OC = value; }
        }

        //private string isRWAMandatory;
        //private string isHQAMandatory;
        //private string isEAMandatory;

        public string IsRWAMandatory { get; set; }
        public string IsHQAMandatory { get; set; }
        public string IsEAMandatory { get; set; }
    }
}
