﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainDBHType
    {
        public List<clsDBHType> DBHTypeList = new List<clsDBHType>();
    }
}
