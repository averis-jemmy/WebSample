﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsTripTicket
    {
        #region private_variables
        private string _TRIPTICKETNO;
        //private string _STRIPTICKETNO;
        private string _DRIVERNAME;
        private int _TRUCKID;
        //private short _TRUCKID;
        private short _TYPEOFTRUCK;
        private string _DESTINATIONSECTOR;
        private string _DESTINATIONESTATE;
        private string _COMPARTMENTNO;
        //Changed By Smrithy 18-11-2015 due to Production issue
        private string _DISPATCHDATETIME;
        private string _HAULERCONTRACTOR;
        private string _SUPPLIERID;
        private string _TRUCKTYPEDESCRIPTION;
        private string _POLICENO;
        private string _STATUS;
        private DateTime _ARRIVALATUKDATETIME;
        private DateTime _DEPARTUREFROMTUKDATETIME;

        //for master
        private string _ESTVOL;
        private string _CONTNAME;
        private string _CONTCODE;
        //Added By Smrithy 13-11-2015
        private string _TruckDesc;

       
        
        #endregion private_variables

        #region Properties

        public string TRIPTICKETNO    //Todo: Guaz: change from int to string for Mac C implementation
        {
            get { return _TRIPTICKETNO; }
            set { _TRIPTICKETNO = value; }
        } 
        public string DRIVERNAME
        {
            get { return _DRIVERNAME; }
            set { _DRIVERNAME = value; }
        }
        public int TRUCKID
        {
            get { return _TRUCKID; }
            set { _TRUCKID = value; }
        }
        public short TYPEOFTRUCK
        {
            get { return _TYPEOFTRUCK; }
            set { _TYPEOFTRUCK = value; }
        }
        public string DESTINATIONSECTOR
        {
            get { return _DESTINATIONSECTOR; }
            set { _DESTINATIONSECTOR = value; }
        }
        public string DESTINATIONESTATE
        {
            get { return _DESTINATIONESTATE; }
            set { _DESTINATIONESTATE = value; }
        }
        public string COMPARTMENTNO
        {
            get { return _COMPARTMENTNO; }
            set { _COMPARTMENTNO = value; }
        }
        //Changed By Smrithy 18-11-2015 due to Production issue
        public string DISPATCHDATETIME
        {
            get { return _DISPATCHDATETIME; }
            set { _DISPATCHDATETIME = value; }
        }
        public string HAULERCONTRACTOR
        {
            get { return _HAULERCONTRACTOR; }
            set { _HAULERCONTRACTOR = value; }
        }

        public string SUPPLIERID
        {
            get { return _SUPPLIERID; }
            set { _SUPPLIERID = value; }
        }
        public string TRUCKTYPEDESCRIPTION
        {
            get { return _TRUCKTYPEDESCRIPTION; }
            set { _TRUCKTYPEDESCRIPTION = value; }
        }

        public string POLICENO
        {
            get { return _POLICENO; }
            set { _POLICENO = value; }
        }

        public string STATUS
        {
            get { return _STATUS; }
            set { _STATUS = value; }
        }
        public DateTime ARRIVALATUKDATETIME
        {
            get { return _ARRIVALATUKDATETIME; }
            set { _ARRIVALATUKDATETIME = value; }
        }
        public DateTime DEPARTUREFROMTUKDATETIME
        {
            get { return _DEPARTUREFROMTUKDATETIME; }
            set { _DEPARTUREFROMTUKDATETIME = value; }
        }
        //for master
        public string ESTVOL
        {
            get { return _ESTVOL; }
            set { _ESTVOL = value; }
        }
        public string CONTNAME
        {
            get { return _CONTNAME; }
            set { _CONTNAME = value; }
        }

        public string CONTCODE
        {
            get { return _CONTCODE; }
            set { _CONTCODE = value; }
        }
        //
        //Added By Smrithy 13-11-2015
        public string TruckDesc
        {
            get { return _TruckDesc; }
            set { _TruckDesc = value; }
        }
        #endregion 
    }
}
