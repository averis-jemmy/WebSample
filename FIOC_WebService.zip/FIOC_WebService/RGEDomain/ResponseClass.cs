﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class ResponseClass
    {
        public ResponseMessage ResponseMessage;
    }

    public class ResponseMessage
    {
        private string _status;


        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }

        private string _wo;


        public string WO
        {
            get { return _wo; }
            set { _wo = value; }
        }
        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private string _pcsno;


        public string PcsNo
        {
            get { return _pcsno; }
            set { _pcsno = value; }
        }
    }



    public class InventoryResponseClass
    {
        public InventoryResponseMessage ResponseMessage;
    }

    public class InventoryResponseMessage
    {
        private string _status;


        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private string _compartmentno;


        public string CompartmentNo
        {
            get { return _compartmentno; }
            set { _compartmentno = value; }
        }

        private string _invtype;


        public string InvType
        {
            get { return _invtype; }
            set { _invtype = value; }
        }

        private string _FeatID;


        public string FeatID
        {
            get { return _FeatID; }
            set { _FeatID = value; }
        }

        private string _compSlNo;
        public string CompSlNo
        {
            get { return _compSlNo; }
            set { _compSlNo = value; }
        }
    }

    public class PQAResponseClass
    {
        public PQAResponseMessage ResponseMessage;
    }

    public class PQAResponseMessage
    {
        private string status;
        private string errorMessage;
        private string wONUMBER;
        private string compSlno;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }
        public string WONUMBER
        {
            get { return wONUMBER; }
            set { wONUMBER = value; }
        }
        public string CompSlno
        {
            get { return compSlno; }
            set { compSlno = value; }
        }
    }

    public class PQAPlotResponseClass
    {
        public PQAPlotResponseMessage ResponseMessage;
    }

    public class PQAPlotResponseMessage
    {
        private string status;
        private string errorMessage;
        private string wONUMBER;
        private string compSlno;
        private string plotslno;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }
        public string WONUMBER
        {
            get { return wONUMBER; }
            set { wONUMBER = value; }
        }
        public string CompSlno
        {
            get { return compSlno; }
            set { compSlno = value; }
        }
        public string PlotSlno
        {
            get { return plotslno; }
            set { plotslno = value; }
        }
    }

    public class HQAResponseClass
    {
        public HQAResponseMessage ResponseMessage;
    }

    public class HQAResponseMessage
    {
        private string _status;


        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private string _WONUMBER;


        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
    }

    public class INVStratumResponseClass
    {
        public INVStratumResponseMessage ResponseMessage;
    }

    public class INVStratumResponseMessage
    {
        private string status;
        private string errorMessage;
        private string featid;

        public string Status
        {
            get { return status; }
            set { status = value; }
        }
        public string ErrorMessage
        {
            get { return errorMessage; }
            set { errorMessage = value; }
        }        
        public string FeatID
        {
            get { return featid; }
            set { featid = value; }
        }
    }
}
