﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsUserSector
    {  
        public string Sector { get; set; }
        public string UserID { get; set; }        
    }
}
