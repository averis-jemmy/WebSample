﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
       [Serializable]
    public class clsPCSTrans
    {
        #region Private variables and Properties

        private string _SERIALNO;

        private string _LOADED_BARGE_TYPE;


        public string LOADED_BARGE_TYPE
        {
            get { return _LOADED_BARGE_TYPE; }
            set { _LOADED_BARGE_TYPE = value; }
        }
        public string SERIALNO
        {
            get { return _SERIALNO; }
            set { _SERIALNO = value; }
        }
        private string _PCSNO;

        public string PCSNO
        {
            get { return _PCSNO; }
            set { _PCSNO = value; }
        }
        private string _HAULCONT;

        public string HAULCONT
        {
            get { return _HAULCONT; }
            set { _HAULCONT = value; }
        }
        private string _REGISTRATION;

        public string REGISTRATION
        {
            get { return _REGISTRATION; }
            set { _REGISTRATION = value; }
        }
        private string _DRIVER;

        public string DRIVER
        {
            get { return _DRIVER; }
            set { _DRIVER = value; }
        }
        private string _TRANSDATE;

        public string TRANSDATE
        {
            get { return _TRANSDATE; }
            set { _TRANSDATE = value; }
        }
        private string _ROADNO;

        public string ROADNO
        {
            get { return _ROADNO; }
            set { _ROADNO = value; }
        }
        private string _LOADER;

        public string LOADER
        {
            get { return _LOADER; }
            set { _LOADER = value; }
        }
        private string _LOADCONT;

        public string LOADCONT
        {
            get { return _LOADCONT; }
            set { _LOADCONT = value; }
        }
        private string _LOADSTART;

        public string LOADSTART
        {
            get { return _LOADSTART; }
            set { _LOADSTART = value; }
        }
        private string _LOADSTOP;

        public string LOADSTOP
        {
            get { return _LOADSTOP; }
            set { _LOADSTOP = value; }
        }
        private string _SCALER;

        public string SCALER
        {
            get { return _SCALER; }
            set { _SCALER = value; }
        }
        private string _AGE;

        public string AGE
        {
            get { return _AGE; }
            set { _AGE = value; }
        }
        private string _DEPOTCODE;

        public string DEPOTCODE
        {
            get { return _DEPOTCODE; }
            set { _DEPOTCODE = value; }
        }
        private string _FAKTUR;

        public string FAKTUR
        {
            get { return _FAKTUR; }
            set { _FAKTUR = value; }
        }
        private string _TRIPTICKET;

        public string TRIPTICKET
        {
            get { return _TRIPTICKET; }
            set { _TRIPTICKET = value; }
        }
        private string _DEPOTBLOCKNO;

        public string DEPOTBLOCKNO
        {
            get { return _DEPOTBLOCKNO; }
            set { _DEPOTBLOCKNO = value; }
        }
        private string _MACHINELNO;

        public string MACHINELNO
        {
            get { return _MACHINELNO; }
            set { _MACHINELNO = value; }
        }
        private string _SOLIDVOL;

        public string SOLIDVOL
        {
            get { return _SOLIDVOL; }
            set { _SOLIDVOL = value; }
        }
        private string _PCSTYPE;

        public string PCSTYPE
        {
            get { return _PCSTYPE; }
            set { _PCSTYPE = value; }
        }
        private string _SOLIDADJ;

        public string SOLIDADJ
        {
            get { return _SOLIDADJ; }
            set { _SOLIDADJ = value; }
        }

        private string _CLOSED;

        public string CLOSED
        {
            get { return _CLOSED; }
            set { _CLOSED = value; }
        }
        private string _APOBLOCKLOC;

        public string APOBLOCKLOC
        {
            get { return _APOBLOCKLOC; }
            set { _APOBLOCKLOC = value; }
        }
        private string _DATEISSUE;

        public string DATEISSUE
        {
            get { return _DATEISSUE; }
            set { _DATEISSUE = value; }
        }
        private string _FELLCONT;

        public string FELLCONT
        {
            get { return _FELLCONT; }
            set { _FELLCONT = value; }
        }
        private string _BARGINGCONT;

        public string BARGINGCONT
        {
            get { return _BARGINGCONT; }
            set { _BARGINGCONT = value; }
        }
        private string _UNLOADCONT;

        public string UNLOADCONT
        {
            get { return _UNLOADCONT; }
            set { _UNLOADCONT = value; }
        }
        private string _UNLOADEQMTTOT;

        public string UNLOADEQMTTOT
        {
            get { return _UNLOADEQMTTOT; }
            set { _UNLOADEQMTTOT = value; }
        }
        private string _UNLOADSTART;

        public string UNLOADSTART
        {
            get { return _UNLOADSTART; }
            set { _UNLOADSTART = value; }
        }
        private string _UNLOADSTOP;

        public string UNLOADSTOP
        {
            get { return _UNLOADSTOP; }
            set { _UNLOADSTOP = value; }
        }
        private string _EXTRACTIONCONT;

        public string EXTRACTIONCONT
        {
            get { return _EXTRACTIONCONT; }
            set { _EXTRACTIONCONT = value; }
        }
        private string _EXTRACTIONEQMTTOT;

        public string EXTRACTIONEQMTTOT
        {
            get { return _EXTRACTIONEQMTTOT; }
            set { _EXTRACTIONEQMTTOT = value; }
        }
        private string _LOADEQMTTOT;

        public string LOADEQMTTOT
        {
            get { return _LOADEQMTTOT; }
            set { _LOADEQMTTOT = value; }
        }

        private string _DEBARKED;

        public string DEBARKED
        {
            get { return _DEBARKED; }
            set { _DEBARKED = value; }
        }
        private string _SVVSTACK;

        public string SVVSTACK
        {
            get { return _SVVSTACK; }
            set { _SVVSTACK = value; }
        }
        private string _SVVVOL;

        public string SVVVOL
        {
            get { return _SVVVOL; }
            set { _SVVVOL = value; }
        }

        private string _SVVTRUCKTYPE;

        public string SVVTRUCKTYPE
        {
            get { return _SVVTRUCKTYPE; }
            set { _SVVTRUCKTYPE = value; }
        }
        private string _SVVESTSTACKVOL;

        public string SVVESTSTACKVOL
        {
            get { return _SVVESTSTACKVOL; }
            set { _SVVESTSTACKVOL = value; }
        }
        private string _SVVESTVOL;

        public string SVVESTVOL
        {
            get { return _SVVESTVOL; }
            set { _SVVESTVOL = value; }
        }
        private string _EMPTYDEPART;

        public string EMPTYDEPART
        {
            get { return _EMPTYDEPART; }
            set { _EMPTYDEPART = value; }
        }
        private string _EMPTYARRIVAL;

        public string EMPTYARRIVAL
        {
            get { return _EMPTYARRIVAL; }
            set { _EMPTYARRIVAL = value; }
        }
        private string _EMPTYBARGELOADED;

        public string EMPTYBARGELOADED
        {
            get { return _EMPTYBARGELOADED; }
            set { _EMPTYBARGELOADED = value; }
        }

        private string _EMPTYBARGETYPE;

        public string EMPTYBARGETYPE
        {
            get { return _EMPTYBARGETYPE; }
            set { _EMPTYBARGETYPE = value; }
        }
        private string _EMPTYTOTVOL;

        public string EMPTYTOTVOL
        {
            get { return _EMPTYTOTVOL; }
            set { _EMPTYTOTVOL = value; }
        }
        private string _EMPTYBARGEEMPTY;

        public string EMPTYBARGEEMPTY
        {
            get { return _EMPTYBARGEEMPTY; }
            set { _EMPTYBARGEEMPTY = value; }
        }
        private string _EMPTYBARGEVOL;

        public string EMPTYBARGEVOL
        {
            get { return _EMPTYBARGEVOL; }
            set { _EMPTYBARGEVOL = value; }
        }
        private string _LOADEDDEPART;

        public string LOADEDDEPART
        {
            get { return _LOADEDDEPART; }
            set { _LOADEDDEPART = value; }
        }
        private string _LOADEDARRIVAL;

        public string LOADEDARRIVAL
        {
            get { return _LOADEDARRIVAL; }
            set { _LOADEDARRIVAL = value; }
        }
        private string _LOADEDNOOFBARGE;

        public string LOADEDNOOFBARGE
        {
            get { return _LOADEDNOOFBARGE; }
            set { _LOADEDNOOFBARGE = value; }
        }

        private string _LOADEDBARGETYPE;

        public string LOADEDBARGETYPE
        {
            get { return _LOADEDBARGETYPE; }
            set { _LOADEDBARGETYPE = value; }
        }
        private string _LOADEDTOTVOL;

        public string LOADEDTOTVOL
        {
            get { return _LOADEDTOTVOL; }
            set { _LOADEDTOTVOL = value; }
        }
        private string _LOADEDBARGEVOL;

        public string LOADEDBARGEVOL
        {
            get { return _LOADEDBARGEVOL; }
            set { _LOADEDBARGEVOL = value; }
        }
        private string _CANALNO;

        public string CANALNO
        {
            get { return _CANALNO; }
            set { _CANALNO = value; }
        }
        private string _TUGBOATOPR;

        public string TUGBOATOPR
        {
            get { return _TUGBOATOPR; }
            set { _TUGBOATOPR = value; }
        }
        private string _TUGBOATID;

        public string TUGBOATID
        {
            get { return _TUGBOATID; }
            set { _TUGBOATID = value; }
        }
        private string _NOTES;

        public string NOTES
        {
            get { return _NOTES; }
            set { _NOTES = value; }
        }
        private string _KMIN;

        public string KMIN
        {
            get { return _KMIN; }
            set { _KMIN = value; }
        }
        private string _KMOUT;

        public string KMOUT
        {
            get { return _KMOUT; }
            set { _KMOUT = value; }
        }


        private string _MACHINEUNO;

        public string MACHINEUNO
        {
            get { return _MACHINEUNO; }
            set { _MACHINEUNO = value; }
        }
        private string _KEYIN;

        public string KEYIN
        {
            get { return _KEYIN; }
            set { _KEYIN = value; }
        }
        private string _CRTUSERID;

        public string CRTUSERID
        {
            get { return _CRTUSERID; }
            set { _CRTUSERID = value; }
        }
        private string _CRTDATE;

        public string CRTDATE
        {
            get { return _CRTDATE; }
            set { _CRTDATE = value; }
        }
        private string _MODUSERID;

        public string MODUSERID
        {
            get { return _MODUSERID; }
            set { _MODUSERID = value; }
        }
        private string _MODDATE;

        public string MODDATE
        {
            get { return _MODDATE; }
            set { _MODDATE = value; }
        }
        private string _NETWEIGHT;

        public string NETWEIGHT
        {
            get { return _NETWEIGHT; }
            set { _NETWEIGHT = value; }
        }
        private string _DESTINATION;

        public string DESTINATION
        {
            get { return _DESTINATION; }
            set { _DESTINATION = value; }
        }
        private string _PORTID;

        public string PORTID
        {
            get { return _PORTID; }
            set { _PORTID = value; }
        }

        private string _WOLOADING;

        public string WOLOADING
        {
            get { return _WOLOADING; }
            set { _WOLOADING = value; }
        }
        private string _WOUNLOAD;

        public string WOUNLOAD
        {
            get { return _WOUNLOAD; }
            set { _WOUNLOAD = value; }
        }
        private string _WOEXTRACTION;

        public string WOEXTRACTION
        {
            get { return _WOEXTRACTION; }
            set { _WOEXTRACTION = value; }
        }
        private string _WOFELLING;

        public string WOFELLING
        {
            get { return _WOFELLING; }
            set { _WOFELLING = value; }
        }
        private string _WOLANGSIR;

        public string WOLANGSIR
        {
            get { return _WOLANGSIR; }
            set { _WOLANGSIR = value; }
        }
        private string _WO;

        public string WO
        {
            get { return _WO; }
            set { _WO = value; }
        }
        private string _FELLDATE;

        public string FELLDATE
        {
            get { return _FELLDATE; }
            set { _FELLDATE = value; }
        }
        private string _LANGSIRCONT;

        public string LANGSIRCONT
        {
            get { return _LANGSIRCONT; }
            set { _LANGSIRCONT = value; }
        }
        private string _TICKETBARGING;

        public string TICKETBARGING
        {
            get { return _TICKETBARGING; }
            set { _TICKETBARGING = value; }
        }
        private string _FAKTURAIR;

        public string FAKTURAIR
        {
            get { return _FAKTURAIR; }
            set { _FAKTURAIR = value; }
        }

        private string _DIAMETERTYPE;

        public string DIAMETERTYPE
        {
            get { return _DIAMETERTYPE; }
            set { _DIAMETERTYPE = value; }
        }
        private string _MUATANKAYU;

        public string MUATANKAYU
        {
            get { return _MUATANKAYU; }
            set { _MUATANKAYU = value; }
        }
        private string _DICEKBY;

        public string DICEKBY
        {
            get { return _DICEKBY; }
            set { _DICEKBY = value; }
        }
        private string _TANGGALDATE;

        public string TANGGALDATE
        {
            get { return _TANGGALDATE; }
            set { _TANGGALDATE = value; }
        }
        private string _REMARK;

        public string REMARK
        {
            get { return _REMARK; }
            set { _REMARK = value; }
        }
        private string _ETLStatus;

        public string ETLStatus
        {
            get { return _ETLStatus; }
            set { _ETLStatus = value; }
        }
        private string _ProcessDate;

        public string ProcessDate
        {
            get { return _ProcessDate; }
            set { _ProcessDate = value; }
        }
        //Added By Smrithy-06-11-2015
        private string _loadingforeman;

        public string Loadingforeman
        {
            get { return _loadingforeman; }
            set { _loadingforeman = value; }
        }
        private string _checkedbydispatcher;

        public string Checkedbydispatcher
        {
            get { return _checkedbydispatcher; }
            set { _checkedbydispatcher = value; }
        }
        private string _loadingoperator;

        public string Loadingoperator
        {
            get { return _loadingoperator; }
            set { _loadingoperator = value; }
        }
        #endregion  Private variables and Properties


    }
}
