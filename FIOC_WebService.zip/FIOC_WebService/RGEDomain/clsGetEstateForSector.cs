﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsGetEstateForSector
    {
        private string _Estate;

        public string Estate
        {
            get { return _Estate; }
            set { _Estate = value; }
        }

    }
}
