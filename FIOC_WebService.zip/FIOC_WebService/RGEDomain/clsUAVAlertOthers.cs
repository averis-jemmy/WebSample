﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsUAVAlertOthers
    {
        private string mAlert_Type,mFeatid, mStart_Date, mAge, mValue, mRemark, mStatus;

        public string Featid { get { return mFeatid;} set { mFeatid = value; } }
        public string Startdate { get { return mStart_Date; } set { mStart_Date = value; } }
        public string Age { get { return mAge; } set { mAge = value; } }
        public string Value { get { return mValue; } set { mValue = value; } }
        public string Remark { get { return mRemark; } set { mRemark = value; } }
        public string Status { get { return mStatus; } set { mStatus = value; } }
        public string AlertType { get { return mAlert_Type; } set { mAlert_Type = value; } }
    }
}
