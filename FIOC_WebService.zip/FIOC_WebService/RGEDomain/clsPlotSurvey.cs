﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    [Serializable]
    public class clsPlotSurvey
    {
        public clsComparmentDet Compartment;

        public List<clsPlotSurveyDet> Plot = new List<clsPlotSurveyDet>();
        public clsPlotSurvey() { }
        public clsPlotSurvey(clsComparmentDet objComparment, List<clsPlotSurveyDet> lstPlotSurvey)
        {
            this.Compartment = objComparment;
            this.Plot = lstPlotSurvey;

        }
    }
    [Serializable]
    public class clsComparmentDet
    {
        #region Compartment
        private string _CompSlno;

        private string _COMPNO;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }

        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }

        private string _featid;

        public string FeatID
        {
            get { return _featid; }
            set { _featid = value; }
        }
        #endregion Compartment
    }
    [Serializable]
    public class clsPlotSurveyDet
    {
        #region Compartment
        private string _CompSlno;

        private string _COMPNO;

        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }
        #endregion Compartment
        #region Plot
        #region private_variables

        private string _PlotNo;
        private string _SurveySlno;


        private string _PlotRadius;
        private string _PlotCenterXDirection;
        private string _PlotCenterYdirection;

        private string _SamplePercentage;
        private string _PRemarks;
        private string _PCreatedBy;
        private string _PCreatedDate;
        private string _PModifiedBy;
        private string _PModifiedDate;

        private string _Plotcenterlat;

        private string _Plotcenterlong;


        #endregion private_variables

        #region Properties

        public string PlotNo
        {
            get { return _PlotNo; }
            set { _PlotNo = value; }
        }

        public string SurveySlno
        {
            get { return _SurveySlno; }
            set { _SurveySlno = value; }
        }

        public string PlotRadius
        {
            get { return _PlotRadius; }
            set { _PlotRadius = value; }
        }
        public string PlotCenterXDirection
        {
            get { return _PlotCenterXDirection; }
            set { _PlotCenterXDirection = value; }
        }

        public string PlotCenterYdirection
        {
            get { return _PlotCenterYdirection; }
            set { _PlotCenterYdirection = value; }
        }
        public string SamplePercentage
        {
            get { return _SamplePercentage; }
            set { _SamplePercentage = value; }
        }
        public string PRemarks
        {
            get { return _PRemarks; }
            set { _PRemarks = value; }
        }

        public string PCreatedBy
        {
            get { return _PCreatedBy; }
            set { _PCreatedBy = value; }
        }
        public string PCreatedDate
        {
            get { return _PCreatedDate; }
            set { _PCreatedDate = value; }
        }
        public string PModifiedBy
        {
            get { return _PModifiedBy; }
            set { _PModifiedBy = value; }
        }
        public string PModifiedDate
        {
            get { return _PModifiedDate; }
            set { _PModifiedDate = value; }
        }


        public string Plotcenterlat
        {
            get { return _Plotcenterlat; }
            set { _Plotcenterlat = value; }
        }

        public string Plotcenterlong
        {
            get { return _Plotcenterlong; }
            set { _Plotcenterlong = value; }
        }
        #endregion
        #endregion Plot

        #region Survey
        #region private_variables

        private string _PlotSerialNo;
        private string _SurveyNo;
        private string _SurveyDate;
        private string _SCompSlno;
        private string _SInventoryType;
        private string _COMPLETE;

        private int _EmpID;
        private string _TeamCode;
        private string _SurveyLineNo;
        private string _AzimuthPlotLine;

        private string _SRemarks;
        private int _StratumNo;
        private decimal _StratumHa;
        private bool _StratumIsBlankSpot;
        private string _MaintainenceStatus;
        private string _Flooding;
        private string _SoilSampleCollected;
        private string _UUID;
        private string _Name;
        private string _SAPID;
        private string _ErrorStatus;

        private string _SCreatedBy;
        private string _SCreatedDate;
        private string _SModifiedBy;
        private string _SModifiedDate;

        private string _Keyedinby;
        private string _TotalLiveYellow;
        private string _TotalDead;
        private string _TotalHealthy;
        private string _SurGPSLat;
        private string _SurGPSLong;
        private string _ErrorSurveySlno;


        #endregion private_variables

        #region Properties


        public string SurveyNo
        {
            get { return _SurveyNo; }
            set { _SurveyNo = value; }
        }
        public string SurveyDate
        {
            get { return _SurveyDate; }
            set { _SurveyDate = value; }
        }
        public string SCompSlno
        {
            get { return _SCompSlno; }
            set { _SCompSlno = value; }
        }
        public string SInventoryType
        {
            get { return _SInventoryType; }
            set { _SInventoryType = value; }
        }

        public string COMPLETE
        {
            get { return _COMPLETE; }
            set { _COMPLETE = value; }
        }
        public int EmpID
        {
            get { return _EmpID; }
            set { _EmpID = value; }
        }
        public string TeamCode
        {
            get { return _TeamCode; }
            set { _TeamCode = value; }
        }
        public string SurveyLineNo
        {
            get { return _SurveyLineNo; }
            set { _SurveyLineNo = value; }
        }
        public string AzimuthPlotLine
        {
            get { return _AzimuthPlotLine; }
            set { _AzimuthPlotLine = value; }
        }

        public string SRemarks
        {
            get { return _SRemarks; }
            set { _SRemarks = value; }
        }

        public int StratumNo
        {
            get { return _StratumNo; }
            set { _StratumNo = value; }
        }

        public decimal StratumHa
        {
            get { return _StratumHa; }
            set { _StratumHa = value; }
        }

        public bool StratumIsBlankSpot
        {
            get { return _StratumIsBlankSpot; }
            set { _StratumIsBlankSpot = value; }
        }

        public string MaintainenceStatus
        {
            get { return _MaintainenceStatus; }
            set { _MaintainenceStatus = value; }
        }
        public string Flooding
        {
            get { return _Flooding; }
            set { _Flooding = value; }
        }
        public string SoilSampleCollected
        {
            get { return _SoilSampleCollected; }
            set { _SoilSampleCollected = value; }
        }
        public string UUID
        {
            get { return _UUID; }
            set { _UUID = value; }
        }
        public string Name
        {
            get { return _Name; }
            set { _Name = value; }
        }
        public string SAPID
        {
            get { return _SAPID; }
            set { _SAPID = value; }
        }
        public string ErrorStatus
        {
            get { return _ErrorStatus; }
            set { _ErrorStatus = value; }
        }


        public string SCreatedBy
        {
            get { return _SCreatedBy; }
            set { _SCreatedBy = value; }
        }
        public string SCreatedDate
        {
            get { return _SCreatedDate; }
            set { _SCreatedDate = value; }
        }
        public string SModifiedBy
        {
            get { return _SModifiedBy; }
            set { _SModifiedBy = value; }
        }
        public string SModifiedDate
        {
            get { return _SModifiedDate; }
            set { _SModifiedDate = value; }
        }

        public string Keyedinby
        {
            get { return _Keyedinby; }
            set { _Keyedinby = value; }
        }
        public string TotalLiveYellow
        {
            get { return _TotalLiveYellow; }
            set { _TotalLiveYellow = value; }
        }

        public string TotalDead
        {
            get { return _TotalDead; }
            set { _TotalDead = value; }
        }

        public string TotalHealthy
        {
            get { return _TotalHealthy; }
            set { _TotalHealthy = value; }
        }

        public string SurGPSLat
        {
            get { return _SurGPSLat; }
            set { _SurGPSLat = value; }
        }

        public string SurGPSLong
        {
            get { return _SurGPSLong; }
            set { _SurGPSLong = value; }
        }
        public string ErrorSurveySlno
        {
            get { return _ErrorSurveySlno; }
            set { _ErrorSurveySlno = value; }
        }


        public string PlotSerialNo
        {
            get { return _PlotSerialNo; }
            set { _PlotSerialNo = value; }
        }
        #endregion
        #endregion Survey
    }
    [Serializable]
    public class clsMainSyncInventory
    {
        public clsPlotSurvey SyncData = new clsPlotSurvey();

    }

    [Serializable]
    public class clsPlotSpacing
    {
        private string _PlotNo;
        private string _BRI;
        private string _IRI;
        private string _BRITREES;
        private string _IRITREES;
        private string _TREEREMARKS;

        public string PlotNo
        {
            get { return _PlotNo; }
            set { _PlotNo = value; }
        }
        public string BRI
        {
            get { return _BRI; }
            set { _BRI = value; }
        }
        public string IRI
        {
            get { return _IRI; }
            set { _IRI = value; }
        }
        public string BRITREES
        {
            get { return _BRITREES; }
            set { _BRITREES = value; }
        }
        public string IRITREES
        {
            get { return _IRITREES; }
            set { _IRITREES = value; }
        }
        public string TREEREMARKS
        {
            get { return _TREEREMARKS; }
            set { _TREEREMARKS = value; }
        }
    }

    [Serializable]
    public class clsTreeImage
    {


        private string _ImageName;
        public string ImageName
        {
            get { return _ImageName; }
            set { _ImageName = value; }
        }

    }

    [Serializable]
    public class clsTreeSurvey
    {
        #region private_variables

        private string _TSurveySlno;
        private string _TreeNo;
        private string _TInventoryType;
        private string _TSHeight;
        private string _X;
        private string _Y;
        private string _DBH;
        private string _HCB;
        private string _TOPHEIGHT;
        private string _TSPropSlno;
        private string _StemCode;
        private string _TreeRemarks;
        private string _PlotNo;
        private string _TreeProperties;
        private string _COMPNO;
        private string _ImageName;
        private string _ImageDescription;
        #endregion private_variables

        #region Properties
        public string PlotNo
        {
            get { return _PlotNo; }
            set { _PlotNo = value; }
        }
        public string TSurveySlno
        {
            get { return _TSurveySlno; }
            set { _TSurveySlno = value; }
        }
        public string TreeNo
        {
            get { return _TreeNo; }
            set { _TreeNo = value; }
        }
        public string TInventoryType
        {
            get { return _TInventoryType; }
            set { _TInventoryType = value; }
        }
        public string TSHeight
        {
            get { return _TSHeight; }
            set { _TSHeight = value; }
        }
        public string X
        {
            get { return _X; }
            set { _X = value; }
        }
        public string Y
        {
            get { return _Y; }
            set { _Y = value; }
        }
        public string DBH
        {
            get { return _DBH; }
            set { _DBH = value; }
        }
        public string HCB
        {
            get { return _HCB; }
            set { _HCB = value; }
        }
        public string TOPHEIGHT
        {
            get { return _TOPHEIGHT; }
            set { _TOPHEIGHT = value; }
        }
        public string TSPropSlno
        {
            get { return _TSPropSlno; }
            set { _TSPropSlno = value; }
        }
        public string StemCode
        {
            get { return _StemCode; }
            set { _StemCode = value; }
        }
        //Added by Soumitri on 28/05/2018 for the Remarks column on the Tree Details
        public string TreeRemarks
        {
            get { return _TreeRemarks; }
            set { _TreeRemarks = value; }
        }

        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }
        public string TreeProperties
        {
            get { return _TreeProperties; }
            set { _TreeProperties = value; }
        }

        public string ImageName
        {
            get { return _ImageName; }
            set { _ImageName = value; }
        }

        public string ImageDescription
        {
            get { return _ImageDescription; }
            set { _ImageDescription = value; }
        }

        #endregion Properties
    }
    [Serializable]
    public class clsTreeSurveyProp
    {
        #region private_variables

        private string _STreePropSlno;
        private string _SurveyPropSlNo;
        private string _PropCount;
        #endregion private_variables

        #region Properties

        public string STreePropSlno
        {
            get { return _STreePropSlno; }
            set { _STreePropSlno = value; }
        }
        public string SurveyPropSlNo
        {
            get { return _SurveyPropSlNo; }
            set { _SurveyPropSlNo = value; }
        }
        public string PropCount
        {
            get { return _PropCount; }
            set { _PropCount = value; }
        }

        #endregion Properties
    }
    //Aded By Smrithy 05-11-2015
    [Serializable]
    public class clsPlotCenterDistance
    {
        #region Private & Public Properties

        private string _Plotno;

        public string PlotNo
        {
            get { return _Plotno; }
            set { _Plotno = value; }
        }

        private string _Plotslno;

        public string Plotslno
        {
            get { return _Plotslno; }
            set { _Plotslno = value; }
        }
        private string _TreeNo;

        public string TreeNo
        {
            get { return _TreeNo; }
            set { _TreeNo = value; }
        }
        private string _Distance;

        public string Distance
        {
            get { return _Distance; }
            set { _Distance = value; }
        }
        #endregion Private & Public Properties
    }

    [Serializable]
    public class clsWeedCoverage
    {
        private string plotNo;
        private string col;
        private string val;

        public string PlotNo
        {
            get { return plotNo; }
            set { plotNo = value; }
        }
        public string Col
        {
            get { return col; }
            set { col = value; }
        }
        public string Val
        {
            get { return val; }
            set { val = value; }
        }
    }

    [Serializable]
    public class clsLAI
    {
        private string plotNo;
        private string col;
        private string val;

        public string PlotNo
        {
            get { return plotNo; }
            set { plotNo = value; }
        }
        public string Col
        {
            get { return col; }
            set { col = value; }
        }
        public string Val
        {
            get { return val; }
            set { val = value; }
        }
    }
}

