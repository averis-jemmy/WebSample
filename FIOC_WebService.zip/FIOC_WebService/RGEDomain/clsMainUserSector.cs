﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainUserSector
    {
        public List<clsUserSector> SectorList = new List<clsUserSector>();
    }
}
