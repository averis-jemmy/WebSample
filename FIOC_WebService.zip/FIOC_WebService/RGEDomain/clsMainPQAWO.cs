﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainPQAWO
    {
        public List<clsPQAGetWorkOrders> GetPQAWorkOrders = new List<clsPQAGetWorkOrders>();
    }
}
