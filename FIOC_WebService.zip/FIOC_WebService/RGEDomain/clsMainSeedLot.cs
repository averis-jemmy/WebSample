﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainSeedLot
    {
        public List<clsSeedLot> SectorList = new List<clsSeedLot>();
    }
}
