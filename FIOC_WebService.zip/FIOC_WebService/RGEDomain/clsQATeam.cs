﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
   public class clsQATeam
    {

        private string _TEAMCODE;

        public string TEAMCODE
        {
            get { return _TEAMCODE; }
            set { _TEAMCODE = value; }
        }
        private string _TEAMNAME;

        public string TEAMNAME
        {
            get { return _TEAMNAME; }
            set { _TEAMNAME = value; }
        }
        private string _COMPANYID;

        public string COMPANYID
        {
            get { return _COMPANYID; }
            set { _COMPANYID = value; }
        }

        private string _Active;

        public string Active
        {
            get { return _Active; }
            set { _Active = value; }
        }

        private string _TYPE;

        public string TYPE
        {
            get { return _TYPE; }
            set { _TYPE = value; }
        }
    }
}
