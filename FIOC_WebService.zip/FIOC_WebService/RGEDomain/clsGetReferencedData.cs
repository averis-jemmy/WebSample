﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsGetReferencedData
    {
        public List<clsContactors> Contractors = new List<clsContactors>();
        public List<clsConversions> Conversions = new List<clsConversions>();
        public List<clsVehicleSw> VehicleSW = new List<clsVehicleSw>();
        public List<clsBarge> Barge = new List<clsBarge>();
        public List<clsDepots> Depots = new List<clsDepots>();
    }
        public class clsContactors
        {
            #region Contractors
            #region private_variables
            private string _CONTCODE;
            private string _NAME;
            //private string _CONTTYPE;
            
            //private string _ADDRESS1;
            //private string _ADDRESS2;
            //private string _POSTBOX;
            //private string _POSTCODE;
            //private string _CITY;
            //private string _STATE;
            //private string _COUNTRY;
            //private string _TEL;
            //private string _FAX;
            //private string _CONTACT;

            //private string _ACTIVE;
            //private string _PCSUSE;
            //private string _SAPCONTCODE;
            //private string _WBHAULER;
            //private string _TAXCODE;
            //private string _CONTMANID;
            //private string _CRTUSERID;
            //private DateTime ? _CRTDATE;
            //private string _MODUSERID;
            //private DateTime ? _MODDATE;

            #endregion private_variables

            #region Properties
            public string CONTCODE
            {
                get { return _CONTCODE; }
                set { _CONTCODE = value; }
            }
            public string NAME
            {
                get { return _NAME; }
                set { _NAME = value; }
            }
            //public string CONTTYPE
            //{
            //    get { return _CONTTYPE; }
            //    set { _CONTTYPE = value; }
            //}
           
            //public string ADDRESS1
            //{
            //    get { return _ADDRESS1; }
            //    set { _ADDRESS1 = value; }
            //}
            //public string ADDRESS2
            //{
            //    get { return _ADDRESS2; }
            //    set { _ADDRESS2 = value; }
            //}
            //public string POSTBOX
            //{
            //    get { return _POSTBOX; }
            //    set { _POSTBOX = value; }
            //}
            //public string POSTCODE
            //{
            //    get { return _POSTCODE; }
            //    set { _POSTCODE = value; }
            //}
            //public string CITY
            //{
            //    get { return _CITY; }
            //    set { _CITY = value; }
            //}
            //public string STATE
            //{
            //    get { return _STATE; }
            //    set { _STATE = value; }
            //}
            //public string COUNTRY
            //{
            //    get { return _COUNTRY; }
            //    set { _COUNTRY = value; }
            //}
            //public string TEL
            //{
            //    get { return _TEL; }
            //    set { _TEL = value; }
            //}
            //public string FAX
            //{
            //    get { return _FAX; }
            //    set { _FAX = value; }
            //}
            //public string CONTACT
            //{
            //    get { return _CONTACT; }
            //    set { _CONTACT = value; }
            //}
            //public string ACTIVE
            //{
            //    get { return _ACTIVE; }
            //    set { _ACTIVE = value; }
            //}
            //public string PCSUSE
            //{
            //    get { return _PCSUSE; }
            //    set { _PCSUSE = value; }
            //}
            //public string SAPCONTCODE
            //{
            //    get { return _SAPCONTCODE; }
            //    set { _SAPCONTCODE = value; }
            //}
            //public string WBHAULER
            //{
            //    get { return _WBHAULER; }
            //    set { _WBHAULER = value; }
            //}
            //public string TAXCODE
            //{
            //    get { return _TAXCODE; }
            //    set { _TAXCODE = value; }
            //}
            //public string CONTMANID
            //{
            //    get { return _CONTMANID; }
            //    set { _CONTMANID = value; }
            //}
            //public string CRTUSERID
            //{
            //    get { return _CRTUSERID; }
            //    set { _CRTUSERID = value; }
            //}
            //public DateTime ? CRTDATE
            //{
            //    get { return _CRTDATE; }
            //    set { _CRTDATE = value; }
            //}
            //public string MODUSERID
            //{
            //    get { return _MODUSERID; }
            //    set { _MODUSERID = value; }
            //}
            //public DateTime ? MODDATE
            //{
            //    get { return _MODDATE; }
            //    set { _MODDATE = value; }
            //}
            #endregion
            #endregion Contractors
        }
        public class clsConversions
        {
            #region Conversions
            #region private_variables
            private string _CF;
            private string _DESCRIPTION;
            private decimal _CONVERSION;
            private string _CONVMANID;
            private string _DEBARKED;
            private string _CONVACTIVE;
            private string _CONVCRTUSERID;
            private DateTime _CONVCRTDATE;
            private string _CONVMODUSERID;
            private DateTime _CONVMODDATE;

            #endregion private_variables
            #region Properties
            public string CF
            {
                get { return _CF; }
                set { _CF = value; }
            }
            public string DESCRIPTION
            {
                get { return _DESCRIPTION; }
                set { _DESCRIPTION = value; }
            }
            public decimal CONVERSION
            {
                get { return _CONVERSION; }
                set { _CONVERSION = value; }
            }
            public string CONVMANID
            {
                get { return _CONVMANID; }
                set { _CONVMANID = value; }
            }
            public string DEBARKED
            {
                get { return _DEBARKED; }
                set { _DEBARKED = value; }
            }
            public string CONVACTIVE
            {
                get { return _CONVACTIVE; }
                set { _CONVACTIVE = value; }
            }
            public string CONVCRTUSERID
            {
                get { return _CONVCRTUSERID; }
                set { _CONVCRTUSERID = value; }
            }
            public DateTime CONVCRTDATE
            {
                get { return _CONVCRTDATE; }
                set { _CONVCRTDATE = value; }
            }
            public string CONVMODUSERID
            {
                get { return _CONVMODUSERID; }
                set { _CONVMODUSERID = value; }
            }

            public DateTime CONVMODDATE
            {
                get { return _CONVMODDATE; }
                set { _CONVMODDATE = value; }
            }
            #endregion
            #endregion Conversions
        }

        public class clsVehicleSw
        {
            #region VehicleSW
            #region private_variables
            private string _TRUCKTYPE;
            private string _ESTSTACKVOL;
            private string _ESTVOL;
            private string _VEHCRTUSERID;
            private DateTime _VEHCRTDATE;
            private string _VEHMODUSERID;
            private DateTime _VEHMODDATE;

            #endregion private_variables

            #region Properties
            public string TRUCKTYPE
            {
                get { return _TRUCKTYPE; }
                set { _TRUCKTYPE = value; }
            }
            public string ESTSTACKVOL
            {
                get { return _ESTSTACKVOL; }
                set { _ESTSTACKVOL = value; }
            }
            public string ESTVOL
            {
                get { return _ESTVOL; }
                set { _ESTVOL = value; }
            }
            public string VEHCRTUSERID
            {
                get { return _VEHCRTUSERID; }
                set { _VEHCRTUSERID = value; }
            }
            public DateTime VEHCRTDATE
            {
                get { return _VEHCRTDATE; }
                set { _VEHCRTDATE = value; }
            }
            public string VEHMODUSERID
            {
                get { return _VEHMODUSERID; }
                set { _VEHMODUSERID = value; }
            }

            public DateTime VEHMODDATE
            {
                get { return _VEHMODDATE; }
                set { _VEHMODDATE = value; }
            }
            #endregion
            #endregion VehicleSW
        }

        public class clsBarge
        {
            #region Barge
            #region private_variables
            private string _TYPE;
            private decimal _VOL;
            private string _MANID;
            private string _BARGECRTUSERID;
            private DateTime _BARGECRTDATE;
            private string _BARGEMODUSERID;
            private DateTime _BARGEMODDATE;

            #endregion private_variables

            #region Properties
            public string TYPE
            {
                get { return _TYPE; }
                set { _TYPE = value; }
            }
            public decimal VOL
            {
                get { return _VOL; }
                set { _VOL = value; }
            }
            public string MANID
            {
                get { return _MANID; }
                set { _MANID = value; }
            }
            public string BARGECRTUSERID
            {
                get { return _BARGECRTUSERID; }
                set { _BARGECRTUSERID = value; }
            }
            public DateTime BARGECRTDATE
            {
                get { return _BARGECRTDATE; }
                set { _BARGECRTDATE = value; }
            }
            public string BARGEMODUSERID
            {
                get { return _BARGEMODUSERID; }
                set { _BARGEMODUSERID = value; }
            }

            public DateTime BARGEMODDATE
            {
                get { return _BARGEMODDATE; }
                set { _BARGEMODDATE = value; }
            }
            #endregion
            #endregion Barge
        }

        public class clsDepots
        {
            #region Depots
            #region private_variables
            private string _DEPOTCODE;
            private string _SECTOR;
            private decimal _MILLDIST;
            private string _DEPODESCRIPTION;
            #endregion private_variables

            #region Properties
            public string DEPOTCODE
            {
                get { return _DEPOTCODE; }
                set { _DEPOTCODE = value; }
            }
            public string SECTOR
            {
                get { return _SECTOR; }
                set { _SECTOR = value; }
            }
            public decimal MILLDIST
            {
                get { return _MILLDIST; }
                set { _MILLDIST = value; }
            }
            public string DEPODESCRIPTION
            {
                get { return _DEPODESCRIPTION; }
                set { _DEPODESCRIPTION = value; }
            }
            #endregion  Depots
            #endregion
        }
   
}
