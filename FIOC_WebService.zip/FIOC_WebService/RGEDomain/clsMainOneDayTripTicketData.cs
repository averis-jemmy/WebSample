﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsMainOneDayTripTicketData
    {
        public List<clsLoadingOneDayTripTicketData> LoadingOneDayTripTicketData = new List<clsLoadingOneDayTripTicketData>();
    }

    public class clsLoadingOneDayTripTicketData
    {
        #region private_variables
        private string _TRIPTICKETNO;
        private string _LOADINGPOINT;
        private string _STATUS;       

        #endregion private_variables

        #region Properties
        public string TRIPTICKETNO
        {
            get { return _TRIPTICKETNO; }
            set { _TRIPTICKETNO = value; }
        }
        public string LOADINGPOINT
        {
            get { return _LOADINGPOINT; }
            set { _LOADINGPOINT = value; }
        }
        public string STATUS
        {
            get { return _STATUS; }
            set { _STATUS = value; }
        }        
        #endregion
    }
}
