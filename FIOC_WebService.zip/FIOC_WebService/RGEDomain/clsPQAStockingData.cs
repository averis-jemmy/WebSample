﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsPQAStockingData
    {
        #region Stocking Details
        #region private_variables
        //private string mWONumber;
        //private string mCompartment;
        //private string mEstate;
        //private string mCompSlNo;
        private int mPlotSNo;
        private int mPlotNo;
        private int mPlotStockingNo;
        private int mTreePlotNo;        
        private int mPlotQdr;
        private int mPlotLine;
        private int mPlotL;
        private int mPlotDA;
        private int mPlotDU;
        private int mPlotVA;
        private int mPlotVU;
        private string mRemarks;

        #endregion private_variables

        #region Properties
        //public string WONumber
        //{
        //    get { return mWONumber; }
        //    set { mWONumber = value; }
        //}
        //public string Compartment
        //{
        //    get { return mCompartment; }
        //    set { mCompartment = value; }
        //}
        //public string Estate
        //{
        //    get { return mEstate; }
        //    set { mEstate = value; }
        //}

        //public string CompSlNo
        //{
        //    get { return mCompSlNo; }
        //    set { mCompSlNo = value; }
        //}
        public int PlotSNo
        {
            get { return mPlotSNo; }
            set { mPlotSNo = value; }
        }
        public int PlotNo
        {
            get { return mPlotNo; }
            set { mPlotNo = value; }
        }
        public int PlotStockingNo
        {
            get { return mPlotStockingNo; }
            set { mPlotStockingNo = value; }
        }
        public int TreePlotNo
        {
            get { return mTreePlotNo; }
            set { mTreePlotNo = value; }
        }
        public string Remarks
        {
            get { return mRemarks; }
            set { mRemarks = value; }
        }

        public int PlotQdr
        {
            get { return mPlotQdr; }
            set { mPlotQdr = value; }
        }

        public int PlotLine
        {
            get { return mPlotLine; }
            set { mPlotLine = value; }
        }

        public int PlotL
        {
            get { return mPlotL; }
            set { mPlotL = value; }
        }

        public int PlotDA
        {
            get { return mPlotDA; }
            set { mPlotDA = value; }
        }

        public int PlotDU
        {
            get { return mPlotDU; }
            set { mPlotDU = value; }
        }

        public int PlotVA
        {
            get { return mPlotVA; }
            set { mPlotVA = value; }
        }

        public int PlotVU
        {
            get { return mPlotVU; }
            set { mPlotVU = value; }
        }

        #endregion  Stocking Details
        #endregion
    }
}
