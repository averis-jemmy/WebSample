﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsInvPlot
    {
        private string _compslno;

        public string Compslno
        {
            get { return _compslno; }
            set { _compslno = value; }
        }

        private string _plotslno;

        public string Plotslno
        {
            get { return _plotslno; }
            set { _plotslno = value; }
        }
        private string _surveyslno;

        public string Surveyslno
        {
            get { return _surveyslno; }
            set { _surveyslno = value; }
        }
        private string _plotno;

        public string Plotno
        {
            get { return _plotno; }
            set { _plotno = value; }
        }
    }
}
