﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    [Serializable]
    public class clsTransStack
    {
        public clsPCSTrans objTrans = new clsPCSTrans();
        public clsPCSStack objStack = new clsPCSStack();
    }
   
}
