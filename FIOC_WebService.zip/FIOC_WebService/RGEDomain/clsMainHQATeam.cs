﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainHQATeam
    {
        public List<clsQATeam> HQATeamCodeList = new List<clsQATeam>();

    }
}
