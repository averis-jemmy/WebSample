﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsAuthToken
    {

        public clsAuthTokenDet AuthToken = new clsAuthTokenDet();
       
        
    }
    public class clsAuthTokenDet
    {

        private string _TokenID;

        public string TokenID
        {
            get { return _TokenID; }
            set { _TokenID = value; }
        }
        private string _DEVICEFOUND;

        public string DEVICEFOUND
        {
            get { return _DEVICEFOUND; }
            set { _DEVICEFOUND = value; }
        }
    }
}
