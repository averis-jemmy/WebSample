﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsRktLicense
    {
        private string _RKT_LIC_NO;

        public string RKT_LIC_NO
        {
            get { return _RKT_LIC_NO; }
            set { _RKT_LIC_NO = value; }
        }

        private string _BLOCK;

        public string BLOCK
        {
            get { return _BLOCK; }
            set { _BLOCK = value; }
        }
    }
}
