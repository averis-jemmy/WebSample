﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
  
    public class clsPCSStack
    {
        #region Private variables
        #region private_variables
        private string _PCSNO;
        private string _STACKNO;
        private string _L;
        private string _W;
        private string _H;
        private string _CF;
        private string _ETLStatus;
        private string _ProcessDate;
     
        #endregion private_variables
        #endregion Private variables

        #region Properties

        public string PCSNO
        {
            get { return _PCSNO; }
            set { _PCSNO = value; }
        }
        public string STACKNO
        {
            get { return _STACKNO; }
            set { _STACKNO = value; }
        }
      
        public string L
        {
            get { return _L; }
            set { _L = value; }
        }
        public string W
        {
            get { return _W; }
            set { _W= value; }
        }
        public string H
        {
            get { return _H; }
            set { _H= value; }
        }

       
        public string CF
        {
            get { return _CF; }
            set { _CF = value; }
        }

        public string ETLStatus
        {
            get { return _ETLStatus; }
            set { _ETLStatus = value; }
        }

        public string ProcessDate
        {
            get { return _ProcessDate; }
            set { _ProcessDate = value; }
        }
       
        #endregion 
    }
}
