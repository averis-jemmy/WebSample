﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsStockLoading
    {
        #region Stock Loading
        #region private_variables
        private string _COMPARTMENT;
        private decimal?  _STOCK;
        private string _TPK;
        
        #endregion private_variables

        #region Properties
        public string COMPARTMENT
        {
            get { return _COMPARTMENT; }
            set { _COMPARTMENT = value; }
        }
        public Nullable<decimal> STOCK
        {
            get { return _STOCK; }
            set { _STOCK = value; }
        }
        public string TPK
        {
            get { return _TPK; }
            set { _TPK = value; }
        }
    }
        #endregion  Stock Loading
        #endregion

}
