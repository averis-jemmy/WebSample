﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsRoad
    {
        private int _ID_ROAD;

        public int ID_ROAD
        {
            get { return _ID_ROAD; }
            set { _ID_ROAD = value; }
        }

        private string _ROAD;

        public string ROAD
        {
            get { return _ROAD; }
            set { _ROAD = value; }
        }
    }
}
