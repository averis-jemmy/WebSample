﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class PQARequest
    {
        public string TokenID { get; set; }
        public string DeviceID { get; set; }
        public PQADetail Detail { get; set; }
    }
    
    public class PQADetail
    {
        public Guid? CompartmentID { get; set; }
        public int CompSlno { get; set; }
        public string WoNumber { get; set; }
        public string FeatID { get; set; }
        public string PlantationSuperindent { get; set; }
        public string Fertilizer { get; set; }
        public string OperationType { get; set; }
        public string AssessorCode { get; set; }
        public string TotalPlotNo { get; set; }
        public int? TargetSpacing { get; set; }
        public decimal? QAPercentage { get; set; }
        public string CreatedBy { get; set; }
        public string WOStatus { get; set; }
        public decimal? TotalScore { get; set; }
        public DateTime QADate { get; set; }
        public List<PlotDetail> PlotDetails { get; set; }
        public List<PlotStockingSummary> PlotStockingSummaries { get; set; }
        public List<TpScore> Scores { get; set; }
    }

    public class TpScore
    {
        public string Parameter { get; set; }
        public int? Score { get; set; }
    }
    
    public class PlotDetail
    {
        public int PlotSlno { get; set; }
        public string PlotNo { get; set; }
        public string Remarks { get; set; }
        public List<PlotGPSDetail> PlotGpsDetails { get; set; }
        public List<HoleSizeDetail> HoleSizeDetails { get; set; }
        public List<PlotSpaceDetail> PlotSpaceDetails { get; set; }
        public List<PlotTreeDetail> PlotTreeDetails { get; set; }
        public List<PlotStockingDetail> PlotStockingDetails { get; set; }
    }
    
    public class PlotGPSDetail
    {
        public int TreeRowNo { get; set; }
        public decimal? GpsLatitude { get; set; }
        public decimal? GpsLongitude { get; set; }
    }
    
    public class HoleSizeDetail
    {
        public int TreeRowNo { get; set; }
        public string TreeNo1 { get; set; }
        public string TreeNo2 { get; set; }
        public string TreeNo3 { get; set; }
        public string TreeNo4 { get; set; }
        public string TreeNo5 { get; set; }
    }
    
    public class PlotSpaceDetail
    {
        public int TreeRowNo { get; set; }
        public decimal? BRI { get; set; }
        public decimal? IRI { get; set; }
    }
    
    public class PlotTreeDetail
    {
        public int TreeRowNo { get; set; }
        public string PropertyList { get; set; }
        public string SeedLotCodeList { get; set; }
        public string ImageNameList { get; set; }
        public string ImageDescription { get; set; }
    }
    
    public class PlotStockingDetail
    {
        public int TreeRowNo { get; set; }
        public int PlotStockingNo { get; set; }
        public int Qdr { get; set; }
        public int Line { get; set; }
        public int L { get; set; }
        public int DA { get; set; }
        public int DU { get; set; }
        public int VA { get; set; }
        public int VU { get; set; }
        public string Remarks { get; set; }
    }
    
    public class PlotStockingSummary
    {
        public int TotalPQAPlot { get; set; }
        public int TotalPQAStocking { get; set; }
        public decimal PlotSize { get; set; }
        public int Spacing { get; set; }
        public decimal AverageLive { get; set; }
        public decimal AverageDA { get; set; }
        public decimal AverageDU { get; set; }
        public decimal AverageVA { get; set; }
        public decimal AverageVU { get; set; }
        public decimal DAHa { get; set; }
        public decimal DUHa { get; set; }
        public decimal DeadPerHa { get; set; }
        public decimal VAHa { get; set; }
        public decimal VUHa { get; set; }
        public decimal VacantPerHa { get; set; }
        public decimal InitialPlanting { get; set; }
        public decimal IPHa { get; set; }
        public decimal LHa { get; set; }
        public decimal InitialStocking { get; set; }
        public decimal LiveStocking { get; set; }
        public decimal PlantingDensity { get; set; }
    }
}

