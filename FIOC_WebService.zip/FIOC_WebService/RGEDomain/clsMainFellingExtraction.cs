﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainFellingExtraction
    {
        public clsGetFellingExtraction WO_List = new clsGetFellingExtraction();
    }
}
