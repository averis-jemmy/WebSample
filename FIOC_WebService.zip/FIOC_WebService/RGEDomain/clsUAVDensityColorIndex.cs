﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsUAVDensityColorIndex
    {
        #region Private Variables & Public Properties
        private string _ExecID;

        public string ExecID
        {
            get { return _ExecID; }
            set { _ExecID = value; }
        }
        private string _ColorCode;

        public string ColorCode
        {
            get { return _ColorCode; }
            set { _ColorCode = value; }
        }
        private string _IndexValue;

        public string IndexValue
        {
            get { return _IndexValue; }
            set { _IndexValue = value; }
        }
        private int _MeanstockingValue;

        public int MeanstockingValue
        {
            get { return _MeanstockingValue; }
            set { _MeanstockingValue = value; }
        }
        #endregion  Private Variables & Public Properties
    }
}
