﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsTripTicketNoLoadedTime
    {
        //private string _STRIPTICKETNO;

        //public string STRIPTICKETNO
        //{
        //    get { return _STRIPTICKETNO; }
        //    set { _STRIPTICKETNO = value; }
        //}

        private string _TRIPTICKETNO;

        public string TRIPTICKETNO
        {
            get { return _TRIPTICKETNO; }
            set { _TRIPTICKETNO = value; }
        }

        private string _TrukType;

        public string TrukType
        {
            get { return _TrukType; }
            set { _TrukType = value; }
        }

        private DateTime _ARRIVALATUKDATETIME;

        public DateTime ARRIVALATUKDATETIME
        {
            get { return _ARRIVALATUKDATETIME; }
            set { _ARRIVALATUKDATETIME = value; }
        }

        //private DateTime _ARRIVALATUKLOADEDDATETIME;

        //public DateTime ARRIVALATUKLOADEDDATETIME
        //{
        //    get { return _ARRIVALATUKLOADEDDATETIME; }
        //    set { _ARRIVALATUKLOADEDDATETIME = value; }
        //}

        private string _POLICENO;

        public string POLICENO
        {
            get { return _POLICENO; }
            set { _POLICENO = value; }
        }

        private string _HAULERCONTRACTOR;

        public string HAULERCONTRACTOR
        {
            get { return _HAULERCONTRACTOR; }
            set { _HAULERCONTRACTOR = value; }
        }

        private string _ESTATE;

        public string ESTATE
        {
            get { return _ESTATE; }
            set { _ESTATE = value; }
        }

        private string _COMPNO;

        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }

        private string _LOADEDTIME;

        public string LOADEDTIME
        {
            get { return _LOADEDTIME; }
            set { _LOADEDTIME = value; }
        }

        
    }
}
