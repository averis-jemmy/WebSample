﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsResponseAuthToken
    {
        public clsResponseAuthTokenMessage ResponseMessage;
    }
    public class clsResponseAuthTokenMessage
    {
        private string _Status;

        public string Status
        {
            get { return _Status; }
            set { _Status = value; }
        }
        private string _ErrorMessage;

        public string ErrorMessage
        {
            get { return _ErrorMessage; }
            set { _ErrorMessage = value; }
        }
        private string _TokenID;

        public string TokenID
        {
            get { return _TokenID; }
            set { _TokenID = value; }
        }
        private string _DeviceID;

        public string DeviceID
        {
            get { return _DeviceID; }
            set { _DeviceID = value; }
        }
    }
}
