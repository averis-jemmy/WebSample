﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsAuthTokenValidation
    {

        private bool _isValidToken;

        public bool IsValidToken
        { 
            get{
                return _isValidToken;
            }
            set {
                _isValidToken = value;
            }
        }

        private string _message;

        public string Message
        {
            get
            {
                return _message;
            }
            set
            {
                _message = value;
            }
        }

        private string _deviceFound;

        public string DeviceFound
        {
            get
            {
                return _deviceFound;
            }
            set
            {
                _deviceFound = value;
            }
        }

         private string _isTokenExists;

        public string IsTokenExists
        {
            get
            {
                return _isTokenExists;
            }
            set
            {
                _isTokenExists = value;
            }
        }
   
    
    }
}
