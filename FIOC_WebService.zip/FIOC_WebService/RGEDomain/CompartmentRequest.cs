﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class CompartmentRequest
    {
        public string TokenID { get; set; }
        public string DeviceID { get; set; }
        public CompartmentDetail Detail { get; set; }
    }
    
    public class CompartmentDetail
    {
        public Guid? CompartmentID { get; set; }
        public int CompSlno { get; set; }
        public string CompNo { get; set; }
        public string FeatID { get; set; }
        public List<StratumDetail> StratumDetails { get; set; }
        public List<SurveyDetail> SurveyDetails { get; set; }
    }
    
    public class StratumDetail
    {
        public int StratumNo { get; set; }
        public decimal? StratumHA { get; set; }
        public bool? IsBlankSpot { get; set; }
        public int NoOfPlots { get; set; }
    }
    
    public class SurveyDetail
    {
        public int SurveySlno { get; set; }
        public int PlotSlno { get; set; }
        public int TreeMapSlno { get; set; }
        public int? StratumNo { get; set; }
        public DateTime SurveyDate { get; set; }
        public string InventoryType { get; set; }
        public string PlotNo { get; set; }
        public string PlotSerialNo { get; set; }
        public string Complete { get; set; }
        public string TeamCode { get; set; }
        public string SurveyLineNo { get; set; }
        public string AzimuthPlotLine { get; set; }
        public string Remarks { get; set; }
        public string MaintenanceStatus { get; set; }
        public string Flooding { get; set; }
        public string SoilSampleCollected { get; set; }
        public string Name { get; set; }
        public string SCreatedBy { get; set; }
        public DateTime? SCreatedDate { get; set; }
        public string PCreatedBy { get; set; }
        public DateTime PCreatedDate { get; set; }
        public int? TotalLiveYellow { get; set; }
        public int? TotalDead { get; set; }
        public int? TotalHealthy { get; set; }
        public int? ErrorSurveySlno { get; set; }
        public decimal? PlotRadius { get; set; }
        public decimal? GpsLatitude { get; set; }
        public decimal? GpsLongitude { get; set; }
        public decimal? SamplePercentage { get; set; }
        public int? StartFrom { get; set; }
        public string TreeMap_Image { get; set; }
        public List<SurveyTreeMapDetail> SurveyTreeMapDetails { get; set; }
        public List<TreeDetail> TreeDetails { get; set; }
        public List<PlotSpacingDetail> PlotSpacingDetails { get; set; }
        public List<WeedCoverageDetail> WeedCoverageDetails { get; set; }
        public List<LeaveAreaIndexDetail> LeaveAreaIndexDetails { get; set; }
        public List<PlotCenterDistanceDetail> PlotCenterDistanceDetails { get; set; }
    }
    
    public class SurveyTreeMapDetail
    {
        public int Top { get; set; }
        public int Left { get; set; }
        public int TreeNumber { get; set; }
    }
    
    public class PlotSpacingDetail
    {
        public decimal? BRI { get; set; }
        public decimal? IRI { get; set; }
        public string BRITrees { get; set; }
        public string IRITrees { get; set; }
        public string Remarks { get; set; }
    }
    
    public class WeedCoverageDetail
    {
        public string Col { get; set; }
        public decimal? Val { get; set; }
    }
    
    public class LeaveAreaIndexDetail
    {
        public string Col { get; set; }
        public decimal? Val { get; set; }
    }
    
    public class PlotCenterDistanceDetail
    {
        public int TreeNo { get; set; }
        public decimal? Distance { get; set; }
    }
    
    public class TreeDetail
    {
        public int TreeSlno { get; set; }
        public int TreeNo { get; set; }
        public decimal? DBH { get; set; }
        public decimal? HCB { get; set; }
        public decimal? TopHeight { get; set; }
        public decimal? Height { get; set; }
        public decimal? X { get; set; }
        public decimal? Y { get; set; }
        public string StemCode { get; set; }
        public string TreeRemarks { get; set; }
        public string PropertyList { get; set; }
        public List<TreeImageDetail> TreeImageDetails { get; set; }
    }
    
    public class TreeImageDetail
    {
        public string ImageName { get; set; }
        public string Description { get; set; }
    }
}

