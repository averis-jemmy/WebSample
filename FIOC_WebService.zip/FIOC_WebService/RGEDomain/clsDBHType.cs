﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsDBHType
    {
        private string mSector;
        private string mInventoryType;
        private decimal? mMINHeight;
        private decimal? mMAXHeight;
        private decimal? mMINDBH;
        private decimal? mMAXDBH;

        public string Sector
        {
            get { return mSector; }
            set { mSector = value; }
        }
        public string InventoryType
        {
            get { return mInventoryType; }
            set { mInventoryType = value; }
        }
        public decimal? MINHeight
        {
            get { return mMINHeight; }
            set { mMINHeight = value; }
        }
        public decimal? MAXHeight
        {
            get { return mMAXHeight; }
            set { mMAXHeight = value; }
        }
        public decimal? MINDBH
        {
            get { return mMINDBH; }
            set { mMINDBH = value; }
        }
        public decimal? MAXDBH
        {
            get { return mMAXDBH; }
            set { mMAXDBH = value; }
        }
    }
}
