﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class TreeMapDetail
    {
        public int Top { get; set; }
        public int Left { get; set; }
        public int TreeNumber { get; set; }
        public List<TreeMapDamageDetail> DamageDetails { get; set; }

        public TreeMapDetail()
        {
            DamageDetails = new List<TreeMapDamageDetail>();
        }
    }
}
