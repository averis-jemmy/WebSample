﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsCloseAlert
    {

        private string id;
        private string alert_type;
        private string featid;
        private string start_date;
        private string end_date;
        private string gps_lat;
        private string gps_lon;
        private string exec_id;
        private string remark;
        private string imageName;
        private string crt_date;
        private string crt_userid;
        private string deviceID;
        private string mod_date;
        private string mod_userid;
        private string status;

        public string Alert_type { get { return alert_type; } set { alert_type = value; } }
        public string Featid { get { return featid; } set { featid = value; } }
        public string Start_date { get { return start_date; } set { start_date = value; } }
        public string End_date { get { return end_date; } set { end_date = value; } }
        public string Gps_lat { get { return gps_lat; } set { gps_lat = value; } }
        public string Gps_lon { get { return gps_lon; } set { gps_lon = value; } }
        public string Exec_id { get { return exec_id; } set { exec_id = value; } }
        public string Remark { get { return remark; } set { remark = value; } }
        public string ImageName { get { return imageName; } set { imageName = value; } }
        public string Crt_date { get { return crt_date; } set { crt_date = value; } }
        public string Crt_userid { get { return crt_userid; } set { crt_userid = value; } }
        public string DeviceID { get { return deviceID; } set { deviceID = value; } }
        public string Id { get { return id; } set { id = value; } }
        public string Mod_date { get { return mod_date; } set { mod_date = value; } }
        public string Mod_userid { get { return mod_userid; } set { mod_userid = value; } }
        public string Status { get { return status; } set { status = value; } }

        public override string ToString()
        {
            return string.Format("[CloseAlert: AlertType={0}, Featid={1}, StartDate={2}, EndDate={3}" +
                ",GPS_lat={4},GPS_lon={5},ExecId={6},Remark={7},ImageName={8},Crt_userid={9},mod_userid={10},Remark={11},Status={12},DeviceID={13}]",
                Alert_type, Featid, Start_date, End_date, Gps_lat, Gps_lon, Exec_id, Remark, ImageName, Crt_userid, Mod_userid, Remark, Status, DeviceID);
        }
    }
}
