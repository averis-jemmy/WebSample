﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class TreeMapHeader
    {
        public string InvType { get; set; }
        public string PlotNo { get; set; }
        public int StartFrom { get; set; }

        public string MaintenanceStatus { get; set; }
        public string Flooding { get; set; }
        public string SoilSampleCollected { get; set; }

        #region BRI-IRI
        public string AverageBRI { get; set; }
        public string AverageIRI { get; set; }

        public string BRITrees1 { get; set; }
        public string BRITrees2 { get; set; }
        public string BRITrees3 { get; set; }
        public string BRI1 { get; set; }
        public string BRI2 { get; set; }
        public string BRI3 { get; set; }
        public string IRITrees1 { get; set; }
        public string IRITrees2 { get; set; }
        public string IRITrees3 { get; set; }
        public string IRI1 { get; set; }
        public string IRI2 { get; set; }
        public string IRI3 { get; set; }
        public string SpacingRemarks1 { get; set; }
        public string SpacingRemarks2 { get; set; }
        public string SpacingRemarks3 { get; set; }
        #endregion

        #region Plot Center Distance
        public string PcdTreeNumber1 { get; set; }
        public string PcdTreeNumber2 { get; set; }
        public string PcdTreeNumber3 { get; set; }
        public string PcdTreeNumber4 { get; set; }
        public string PcdDistance1 { get; set; }
        public string PcdDistance2 { get; set; }
        public string PcdDistance3 { get; set; }
        public string PcdDistance4 { get; set; }
        #endregion

        public List<TreeMapDetail> Details { get; set; }

        public TreeMapHeader()
        {
            Details = new List<TreeMapDetail>();
        }
    }
}
