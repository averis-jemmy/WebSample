﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainInvTeam
    {
        public List<clsInvTeam> TeamCodeList = new List<clsInvTeam>();
    }
}
