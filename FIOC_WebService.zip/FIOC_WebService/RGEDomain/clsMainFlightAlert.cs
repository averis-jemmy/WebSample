﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsMainFlightAlert
    {
        public List<clsUAVAlert> AlertsList = new List<clsUAVAlert>();
        public List<clsUAVAlertOthers> AlertsListOthers = new List<clsUAVAlertOthers>();
        public List<clsResponseUAVFlight> FlightData = new List<clsResponseUAVFlight>();
        public List<clsUAVDensityColorIndex> UAVReferenceData = new List<clsUAVDensityColorIndex>();

    }
}
