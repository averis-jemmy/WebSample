﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
   public class clsMainCompartment
    {
       public List<ClsCompartment> Compartments = new List<ClsCompartment>();
    }
}
