﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsPQAStockingSummaryData
    {
        #region Stocking Details
        #region private_variables
        public int mtotalPlotPQA { get; set; }
        public int mtotalPlotPQAStocking { get; set; }
        public decimal mplotSize { get; set; }
        public int mspacing { get; set; }
        public decimal maverageLive { get; set; }
        public decimal maverageDA { get; set; }
        public decimal maverageDU { get; set; }
        public decimal maverageVA { get; set; }
        public decimal maverageVU { get; set; }
        public decimal mdaHa { get; set; }
        public decimal mduHa { get; set; }
        public decimal mdeadPerHa { get; set; }
        public decimal mvaHa { get; set; }
        public decimal mvuHa { get; set; }
        public decimal mvacantPerHa { get; set; }
        public decimal minitialPlanting { get; set; }
        public decimal mipHa { get; set; }
        public decimal mlHa { get; set; }
        public decimal minitialStocking { get; set; }
        public decimal mliveStocking { get; set; }
        public decimal mkerapatanTitikTanam { get; set; }
        //public string mcompartmentNo { get; set; }
        //public string mworkOrderNo { get; set; }
        //public string mestate { get; set; }
        //public string mCompSlNo { get; set; }

        public int totalPlotPQA
        {
            get
            {
                return mtotalPlotPQA;
            }

            set
            {
                mtotalPlotPQA = value;
            }
        }

        public int totalPlotPQAStocking
        {
            get
            {
                return mtotalPlotPQAStocking;
            }

            set
            {
                mtotalPlotPQAStocking = value;
            }
        }

        public decimal plotSize
        {
            get
            {
                return mplotSize;
            }

            set
            {
                mplotSize = value;
            }
        }

        public int spacing
        {
            get
            {
                return mspacing;
            }

            set
            {
                mspacing = value;
            }
        }

        public decimal averageLive
        {
            get
            {
                return maverageLive;
            }

            set
            {
                maverageLive = value;
            }
        }

        public decimal averageDA
        {
            get
            {
                return maverageDA;
            }

            set
            {
                maverageDA = value;
            }
        }

        public decimal averageDU
        {
            get
            {
                return maverageDU;
            }

            set
            {
                maverageDU = value;
            }
        }

        public decimal averageVA
        {
            get
            {
                return maverageVA;
            }

            set
            {
                maverageVA = value;
            }
        }

        public decimal averageVU
        {
            get
            {
                return maverageVU;
            }

            set
            {
                maverageVU = value;
            }
        }

        public decimal daHa
        {
            get
            {
                return mdaHa;
            }

            set
            {
                mdaHa = value;
            }
        }

        public decimal duHa
        {
            get
            {
                return mduHa;
            }

            set
            {
                mduHa = value;
            }
        }

        public decimal deadPerHa
        {
            get
            {
                return mdeadPerHa;
            }

            set
            {
                mdeadPerHa = value;
            }
        }

        public decimal vaHa
        {
            get
            {
                return mvaHa;
            }

            set
            {
                mvaHa = value;
            }
        }

        public decimal vuHa
        {
            get
            {
                return mvuHa;
            }

            set
            {
                mvuHa = value;
            }
        }

        public decimal vacantPerHa
        {
            get
            {
                return mvacantPerHa;
            }

            set
            {
                mvacantPerHa = value;
            }
        }

        public decimal initialPlanting
        {
            get
            {
                return minitialPlanting;
            }

            set
            {
                minitialPlanting = value;
            }
        }

        public decimal ipHa
        {
            get
            {
                return mipHa;
            }

            set
            {
                mipHa = value;
            }
        }

        public decimal lHa
        {
            get
            {
                return mlHa;
            }

            set
            {
                mlHa = value;
            }
        }

        public decimal initialStocking
        {
            get
            {
                return minitialStocking;
            }

            set
            {
                minitialStocking = value;
            }
        }

        public decimal liveStocking
        {
            get
            {
                return mliveStocking;
            }

            set
            {
                mliveStocking = value;
            }
        }

        public decimal kerapatanTitikTanam
        {
            get
            {
                return mkerapatanTitikTanam;
            }

            set
            {
                mkerapatanTitikTanam = value;
            }
        }

        //public string CompSlNo
        //{
        //    get { return mCompSlNo; }
        //    set { mCompSlNo = value; }
        //}

        //public string compartmentNo
        //{
        //    get
        //    {
        //        return mcompartmentNo;
        //    }

        //    set
        //    {
        //        mcompartmentNo = value;
        //    }
        //}

        //public string workOrderNo
        //{
        //    get
        //    {
        //        return mworkOrderNo;
        //    }

        //    set
        //    {
        //        mworkOrderNo = value;
        //    }
        //}

        //public string estate
        //{
        //    get
        //    {
        //        return mestate;
        //    }

        //    set
        //    {
        //        mestate = value;
        //    }
        //}

        #endregion  Stocking Details
        #endregion
    }
}
