﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class TreeMapHeaderComp
    {
        public string FeatID { get; set; }
        public List<TreeMapHeader> Headers { get; set; }

        public TreeMapHeaderComp()
        {
            Headers = new List<TreeMapHeader>();
        }
    }
}
