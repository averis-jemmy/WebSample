﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsUAVAlertColorIndex
    {
        #region Private Variables
        private string _AlertCode;
        private string _ColorCode;
        private string _IndexValue; 
        #endregion
        #region Properties
        public string AlertCode
        {
            get { return _AlertCode; }
            set { _AlertCode = value; }
        }


        public string ColorCode
        {
            get { return _ColorCode; }
            set { _ColorCode = value; }
        }


        public string IndexValue
        {
            get { return _IndexValue; }
            set { _IndexValue = value; }
        }
        #endregion Properties
    }
}
