﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsInventoryType
    {
        public string InventoryType { get; set; }
        public string AppGroup { get; set; }
    }
}
