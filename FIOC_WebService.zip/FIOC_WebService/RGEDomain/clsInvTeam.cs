﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsInvTeam
    {
        private string _TEAMCODE;

        public string TEAMCODE
        {
            get { return _TEAMCODE; }
            set { _TEAMCODE = value; }
        }

        private string _TEAMNAME;

        public string TEAMNAME
        {
            get { return _TEAMNAME; }
            set { _TEAMNAME = value; }
        }
    }


}
