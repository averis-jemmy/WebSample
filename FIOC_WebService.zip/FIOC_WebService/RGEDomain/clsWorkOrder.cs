﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsWorkOrder
    {
        #region WorkOrder
        #region private_variables
        private string _WONUMBER;
        private string _SECTOR;
        private string _FEATNO;
        private string _ESTATE;
        private string _CERTIFICATIONCODE;
        private string _NAME;
        private string _CONTCODE;
        private DateTime _WODATE;
        private string _FOREMANID;
        private string _SPVCODE;
        private string _COMPNO;
        private string _TypeOfWO;



        #endregion private_variables

        #region Properties
        public string WONUMBER
        {
            get { return _WONUMBER; }
            set { _WONUMBER = value; }
        }
        public string SECTOR
        {
            get { return _SECTOR; }
            set { _SECTOR = value; }
        }
        public string ESTATE
        {
            get { return _ESTATE; }
            set { _ESTATE = value; }
        }
        public string FEATNO
        {
            get { return _FEATNO; }
            set { _FEATNO = value; }
        }
        public string CERTIFICATIONCODE
        {
            get { return _CERTIFICATIONCODE; }
            set { _CERTIFICATIONCODE = value; }
        }
        public string NAME
        {
            get { return _NAME; }
            set { _NAME = value; }
        }
        public string CONTCODE
        {
            get { return _CONTCODE; }
            set { _CONTCODE = value; }
        }
        public DateTime WODATE
        {
            get { return _WODATE; }
            set { _WODATE = value; }
        }


        public string FOREMANID
        {
            get { return _FOREMANID; }
            set { _FOREMANID = value; }
        }


        public string SPVCODE
        {
            get { return _SPVCODE; }
            set { _SPVCODE = value; }
        }


        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }


        public string TypeOfWO
        {
            get { return _TypeOfWO; }
            set { _TypeOfWO = value; }
        }
    }
        #endregion  WorkOrder
        #endregion
    
}
