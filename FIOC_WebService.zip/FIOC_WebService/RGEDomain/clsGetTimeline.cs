﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsGetTimeline
    {

        private string mwo;
        private string mstartdate;
        private string mcprdate;
        private string mfirstdprdate;
        private string mlastdprdate;
        private string mestdate;

        public string WO
        {
            get { return mwo; }
            set { mwo = value; }
        }
        public string StartDate
        {
            get { return mstartdate; }
            set { mstartdate = value; }
        }

        public string CPRDate
        {
            get { return mcprdate; }
            set { mcprdate = value; }
        }

        public string FirstDPRDate
        {
            get { return mfirstdprdate; }
            set { mfirstdprdate = value; }
        }

        public string LastDPRDate
        {
            get { return mlastdprdate; }
            set { mlastdprdate = value; }
        }

        public string EstDate
        {
            get { return mestdate; }
            set { mestdate = value; }
        }

    }
}
