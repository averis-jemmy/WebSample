﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using RGEBal;
//using RGEDal;
namespace RGEDomain
{
    public class ClsCompartment
    {
        #region private_variables
        private string _CompSlno;

        private string _COMPNO;
        private string _Sector;
        private string _Estate;
        private string _Tot_HA;
        private string _SpeciesID;
        private string _CompImage;
        private string _FeatID;
        #endregion

        #region Properties
        public string CompSlno
        {
            get { return _CompSlno; }
            set { _CompSlno = value; }
        }
        public string COMPNO
        {
            get { return _COMPNO; }
            set { _COMPNO = value; }
        }
        public string Sector
        {
            get { return _Sector; }
            set { _Sector = value; }
        }
        public string Estate
        {
            get { return _Estate; }
            set { _Estate = value; }
        }
        public string Tot_HA
        {
            get { return _Tot_HA; }
            set { _Tot_HA = value; }
        }
        public string SpeciesID
        {
            get { return _SpeciesID; }
            set { _SpeciesID = value; }
        }

        public string CompImage
        {
            get { return _CompImage; }
            set { _CompImage = value; }
        }

        public string FeatID
        {
            get { return _FeatID; }
            set { _FeatID = value; }
        }

        public List<TreeMapHeader> TreeMapHistories { get; set; }
        #endregion



    }
}
