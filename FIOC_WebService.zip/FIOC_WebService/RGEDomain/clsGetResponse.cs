﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    #region Inv Response
    public class clsGetResponse
    {
        public clsGetResponseMessage ResponseMessage;
    }
    public class clsGetResponseMessage
    {

        private string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private clsMainCompartment _Response;


        public clsMainCompartment Response
        {
            get { return _Response; }
            set { _Response = value; }
        }
    }
    #endregion Inv Response

    #region Wood Supply Response
    public class clsWoodResponse
    {
        public clsWoodResponseMessage ResponseMessage;
    }
    public class clsWoodResponseMessage
    {
        private string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private clsMainWO _Response;


        public clsMainWO Response
        {
            get { return _Response; }
            set { _Response = value; }
        }
    }
    #endregion Wood Supply Response

    #region UAV Response
    public class clsUAVResponse
    {
        public clsUAVResponseMessage ResponseMessage;
    }
    public class clsUAVResponseMessage
    {
        private string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private clsMainUAVEstate _Response;


        public clsMainUAVEstate Response
        {
            get { return _Response; }
            set { _Response = value; }
        }
    }
    #endregion UAV Response

    #region PQA Response
    public class clsPQAResponse
    {
        public clsPQAResponseMessage ResponseMessage;
    }
    public class clsPQAResponseMessage
    {
        private string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private clsMainPQAWO _Response;


        public clsMainPQAWO Response
        {
            get { return _Response; }
            set { _Response = value; }
        }
    }
    #endregion PQA Response

    #region HQA Response
    public class clsHQAResponse
    {
        public clsHQAResponseMessage ResponseMessage;
    }
    public class clsHQAResponseMessage
    {
        private string _status;

        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }


        private string _errormessage;


        public string ErrorMessage
        {
            get { return _errormessage; }
            set { _errormessage = value; }
        }
        private clsMainHQAWO _Response;


        public clsMainHQAWO Response
        {
            get { return _Response; }
            set { _Response = value; }
        }
    }
    #endregion PQA Response
}
