﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGEDomain
{
    public class clsWeather
    {
        private int _ID_WEATHER;

        public int ID_WEATHER
        {
            get { return _ID_WEATHER; }
            set { _ID_WEATHER = value; }
        }

        private string _WEATHER;

        public string WEATHER
        {
            get { return _WEATHER; }
            set { _WEATHER = value; }
        }
    }
}
