﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
   public class clsContractors
    {
        #region private_variables
       //private string _CONTCODE;
       //private string _CONTTYPE;
       //private string _NAME;
       //private string _ADDRESS1;
       //private string _ADDRESS2;
       //private string _POSTBOX;
       //private string _POSTCODE;
       //private string _CITY;
       //private string _STATE;
       //private string _COUNTRY;
       //private string _TEL;
       //private string _FAX;
       //private string _CONTACT;

       //private string _ACTIVE;
       //private string _PCSUSE;
       //private string _SAPCONTCODE;
       //private string _WBHAULER;
       //private string _TAXCODE;
       //private string _CONTMANID;
       // private string _CRTUSERID;
       // private DateTime _CRTDATE;
       // private string _MODUSERID;
       // private DateTime _MODDATE;

        #endregion private_variables
    }
}
