﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsDamageType
    {
        private string damageType;
        private string isDead;
        private string pma06;

        public string DamageType
        {
            get { return damageType; }
            set { damageType = value; }
        }
        public string IsDead
        {
            get { return isDead; }
            set { isDead = value; }
        }
        public string PMA06
        {
            get { return pma06; }
            set { pma06 = value; }
        }        
    }
}
