﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsUAVAlert
    {
        #region Private Variables & Properties
        private string _AlertID;
        private string mFeatid, mStartdate, mRemark, mStatus;

        public string AlertID
        {
            get { return _AlertID; }
            set { _AlertID = value; }
        }
        private string _AlertType;

        public string AlertType
        {
            get { return _AlertType; }
            set { _AlertType = value; }
        }
        private string _AlertDescription;

        public string AlertDescription
        {
            get { return _AlertDescription; }
            set { _AlertDescription = value; }
        }
        private Double _GPSLat;

        public Double GPSLat
        {
            get { return _GPSLat; }
            set { _GPSLat = value; }
        }
        private Double _GPSLong;

        public Double GPSLong
        {
            get { return _GPSLong; }
            set { _GPSLong = value; }
        }
        private string _ExecID;

        public string ExecID
        {
            get { return _ExecID; }
            set { _ExecID = value; }
        }


        public string Featid { get { return mFeatid; } set { mFeatid = value; } }
        public string Startdate { get { return mStartdate; } set { mStartdate = value; } }
        public string Remark { get { return mRemark; } set { mRemark = value; } }
        public string Status { get { return mStatus; } set { mStatus = value; } }


        //private string _FlightID;

        //public string FlightID
        //{
        //    get { return _FlightID; }
        //    set { _FlightID = value; }
        //}
        #endregion Private Variables & Properties


    }
}
