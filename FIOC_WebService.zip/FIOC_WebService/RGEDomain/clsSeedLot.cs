﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RGEDomain
{
    public class clsSeedLot
    {  
        public string SEEDLOT_CODE { get; set; }
        public string SPECIESID { get; set; }
        public string SECTOR { get; set; }
    }
}
