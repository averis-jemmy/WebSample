﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using RGEDomain;


namespace RGEFiberOneService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IRGEService" in both code and config file together.
    [ServiceContract]
    public interface IRGEService
    {
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/LogDeviceInformation", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string LogDeviceInformation(string deviceID, string details);

        #region Inventory
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/FetchCompDataByInvType", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsGetResponse FetchCompDataByInvType(string inventoryType, string sector, string inventoryDate, string deviceID, string tokenId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/FetchTreeMapData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        List<TreeMapHeader> FetchTreeMapData(string compartmentNo, string featID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/FetchTreeMapDataList", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        List<TreeMapHeaderComp> FetchTreeMapDataList(List<string> featIDs);


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetInventoryReferenceData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainInvTeam GetInventoryReferenceData(string sector, string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SyncCompartment", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        InventoryResponseClass SyncCompartment(CompartmentRequest info);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertPlotSurvey", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        InventoryResponseClass InsertPlotSurvey(string SyncData);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertPlots", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        InventoryResponseClass InsertPlots(string SyncData);

        //Method to Get DBH Min & Max Values from Database. This method added on 28/05/2018
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetDBHType", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainDBHType GetDBHType();

        //To Get Inventory Types. Added by Jemmy on 05/06/2018.
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetInventoryTypes", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainInventoryType GetInventoryTypes();
        #endregion Inventory

        #region Wood Supply
        [OperationContract]
        [WebGet(UriTemplate = "/GetWODetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
        clsMainWO GetWODetails();

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetTripTicketDetailsBySector", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainTripTicket GetTripTicketDetailsBySector(string sector);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetRktLicensesBySector", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainRktLicense GetRktLicensesBySector(string sector, string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetRoadConditions", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainRoad GetRoadConditions(string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetWeatherConditions", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainWeather GetWeatherConditions(string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetTripTicketWithoutLoadedTime", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainTripTicketNoLoadedTime GetTripTicketWithoutLoadedTime(string sector, string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetWODetailsBySector", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsWoodResponse GetWODetailsBySector(string sector, string deviceID, string tokenId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/FetchStaticReferenceData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainRefData FetchStaticReferenceData(string sector, string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/FetchStaticReferenceDataMasterData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainRefData FetchStaticReferenceDataMasterData(string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/FetchStaticReferenceDataSectorData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainRefData FetchStaticReferenceDataSectorData(string sector, string deviceID);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetLoadingUnloadingWO", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainLoadingUnloadingWO GetLoadingUnloadingWO(string woNumber);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetFellingExtractionWO", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainFellingExtraction GetFellingExtractionWO(string woNumber);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SetArrivedDatetime", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string SetArrivedDatetime(string tripTicketNo, string status, string arrivedAtUKdatetime, string LoadingPoint);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SetLoadedArrivedDatetime", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string SetLoadedArrivedDatetime(string tripTicketNo, string status, string loadedArrivedAtUKdatetime);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertStackWODetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        //string InsertStackWODetails(string[] stackObj);
        ResponseClass InsertStackWODetails(string[] stackObj);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertTransWODetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        ResponseClass InsertTransWODetails(string transObj);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SetLhpStock", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string SetLhpStock(string sector, string depot, string license, string block, string species, int lhp, string createdDateTime, string user, string deviceId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SetEnviromentalValues", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string SetEnviromentalValues(string sector, string depot, string weather, string road, int equipGood, int equipBad, string createdDateTime, string user, string deviceId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetArriveNotArrivedata", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainStock GetArriveNotArrivedata(string sector);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetOneDayTripTicketData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainOneDayTripTicketData GetOneDayTripTicketData(string Sector);

        #endregion Wood Supply

        #region UAV
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetEstateForSector", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsUAVResponse GetEstateForSector(string sector, string deviceID, string tokenId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetCompartmentNoForEstate", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainUAVCompNo GetCompartmentNoForEstate(string sector, string estate);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetImagesForFilter", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainFlightAlert GetImagesForFilter(string featid, string flightStartdate, string flightEnddate);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetUAVReferenceData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainUAVReferenceData GetUAVReferenceData();

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SaveCloseAlert", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        ResponseClass SaveCloseAlert(string transObj);        
        #endregion UAV

        #region PQA

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetPQAWorkOrders", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsPQAResponse GetPQAWorkOrders(string sector, string dtReqStartDate, string dtReqEndDate, string deviceID, string tokenId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SyncPQAData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare)]
        PQAResponseClass SyncPQAData(PQARequest info);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertPQADetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        PQAResponseClass InsertPQADetails(string SyncData);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertPQAStocking", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        PQAResponseClass InsertPQAStocking(string SyncData);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertPQAStockingSummary", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        PQAResponseClass InsertPQAStockingSummary(string SyncData);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertPQAPlotDetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        PQAPlotResponseClass InsertPQAPlotDetails(string SyncData);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetTimelinePQAscore", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainGetTimeline GetTimeline(string wo);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetConfigurations", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        List<KeyValuePair<string, string>> GetConfigurations();

        #endregion PQA

        #region HQA
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetHQAWorkOrders", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsHQAResponse GetHQAWorkOrders(string sector, string dtReqStartDate, string dtReqEndDate, string deviceID, string tokenId);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetPQATeamDetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainHQATeam GetPQATeamDetails(string sector, string deviceID);


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/InsertHQADetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        //string InsertHQADetails(string SyncData);
        HQAResponseClass InsertHQADetails(string SyncData);

        //Smrithy Added-03-11-2015
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetHQARWATeamDetails", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainHQARWATeam GetHQARWATeamDetails(string sector, string deviceID);
        #endregion HQA

        #region Image Upload
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SaveImageUsingPost", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string SaveImageUsingPost(string fileName, string base64String);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/SaveTreeImages", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]

        string SaveTreeImages(string fileName, string appType, string base64String);
        #endregion Image Upload

        #region GetAuthTokenID

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetAuthTokenID", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsAuthToken GetAuthTokenID(string deviceID);
        #endregion GetAuthTokenID

        #region ValidateUserID
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/ValidateUserID", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsValidateUserID ValidateUserID(string userId);
        #endregion ValidateUserID

        #region Login
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/Login", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsUserDetail Login(string UserID, string Password, string AppName);
        #endregion

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/Test", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string Test(string SyncData);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetSectorData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainSector GetSectorData();

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetUserSectorList", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainUserSector GetUserSectorList(string AppName);

        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetDamageType", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainDamageType GetDamageType();

        //Added on 07/02/2018 By Soumitri for SEED LOT DATA
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "/GetSeedLotData", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        clsMainSeedLot GetSeedLotData();

        #region For Diagnosis
        [WebInvoke(Method = "POST", UriTemplate = "/TestDatabaseConnection", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.WrappedRequest)]
        string ConnectDatabase();
        #endregion
    }
}

   