﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.IO;
using RGEDomain;
using RGEBal;
using System.Web.Helpers;
using System.Web.Script.Serialization;
using System.Runtime.Serialization.Json;
using System.Threading;
using RGELog;
using Newtonsoft.Json;

namespace RGEFiberOneService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "RGEService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select RGEService.svc or RGEService.svc.cs at the Solution Explorer and start debugging.
    public class RGEService : IRGEService
    {
        public string Test(string SyncData)
        {
            return "test";
        }

        public string LogDeviceInformation(string deviceID, string details)
        {
            Log.Writelog(deviceID, "LogDeviceInformation details: " + details, "");
            return "test";
        }

        #region Methods

        #region Inventory
        #region GetInventoryReferenceData
        /// <summary>
        /// GetInventoryReferenceData
        /// </summary>
        /// <returns></returns>
        public clsMainInvTeam GetInventoryReferenceData(string sector, string deviceID)
        {
            //#Guaz: Function name is GETHQA but the actual function is to query the PQA Team Details."          
            Log.Writelog(deviceID, "GetInventoryReferenceData (TEAM CODE) - Sec: " + sector, "INVENTORY");

            clsMainInvTeam obMain = new clsMainInvTeam();
            List<clsInvTeam> lstInvTeam = new List<clsInvTeam>();
            BLInventory objBLInventory = new BLInventory();
            lstInvTeam = objBLInventory.GetInventoryReferenceData(sector);
            obMain.TeamCodeList = lstInvTeam;
            Log.Writelog(deviceID, "GetInventoryReferenceData (TEAM CODE) - Total record: " + lstInvTeam.Count, "INVENTORY");
            return obMain;
        }
        #endregion GetInventoryReferenceData

        #region GetSectorData
        /// <summary>
        /// GetSectorData
        /// </summary>
        /// <returns></returns>
        public clsMainSector GetSectorData()
        {
            clsMainSector obMain = new clsMainSector();
            List<clsSector> lstInvTeam = new List<clsSector>();
            BLInventory objBLInventory = new BLInventory();
            lstInvTeam = objBLInventory.GetSectorData();
            obMain.SectorList = lstInvTeam;
            return obMain;
        }
        #endregion GetSectorData

        #region GetUserSectorList
        /// <summary>
        /// GetUserSectorList
        /// </summary>
        /// <returns></returns>
        public clsMainUserSector GetUserSectorList(string AppName)
        {
            clsMainUserSector obMain = new clsMainUserSector();
            List<clsUserSector> lstInvTeam = new List<clsUserSector>();
            BLInventory objBLInventory = new BLInventory();
            lstInvTeam = objBLInventory.GetUserSectorList(AppName);
            obMain.SectorList = lstInvTeam;
            return obMain;
        }
        #endregion GetSectorData

        #region GetDamageType
        public clsMainDamageType GetDamageType()
        {
            clsMainDamageType obMain = new clsMainDamageType();
            List<clsDamageType> lstInvTeam = new List<clsDamageType>();
            BLInventory objBLInventory = new BLInventory();
            lstInvTeam = objBLInventory.GetDamageType();
            obMain.DamageTypeList = lstInvTeam;
            return obMain;
        }
        #endregion GetSectorData

        #region Sync Compartment
        public InventoryResponseClass SyncCompartment(CompartmentRequest info)
        {
            Log.WriteSynclog(JsonConvert.SerializeObject(info,
                new JsonSerializerSettings() { DateFormatHandling = DateFormatHandling.MicrosoftDateFormat }),
                "INVENTORY", info.DeviceID);

            clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
            objAuth = ValidateAuthToken(info.DeviceID, info.TokenID);
            Log.Writelog(info.DeviceID, "isValidToken--" + objAuth.IsValidToken.ToString(), "INVENTORY");
            if (objAuth.IsValidToken == true)
            {
                BLInventory objBLInventory = new BLInventory();
                return objBLInventory.SyncCompartment(info.Detail);
            }
            else
            {
                return new InventoryResponseClass()
                {
                    ResponseMessage = new InventoryResponseMessage()
                    {
                        CompartmentNo = string.Empty,
                        InvType = string.Empty,
                        FeatID = string.Empty,
                        ErrorMessage = objAuth.Message,
                        Status = string.Empty
                    }
                };

            }
        }
        #endregion

        #region InsertPlotSurvey
            public InventoryResponseClass InsertPlotSurvey(string SyncData)
        {
            string validateCompno = string.Empty;
            string validateInvType = string.Empty;
            InventoryResponseMessage objResponse = new InventoryResponseMessage();
            InventoryResponseClass objResponseClass = new InventoryResponseClass();
            string FeatID = string.Empty;
            BLInventory objBLInventory = new BLInventory();
            //Log.Writelog("In InsertPlotSurvey of RGEService", "INVENTORY");
            clsComparmentDet objCompartment = new clsComparmentDet();

            Log.Writelog(SyncData, "INVENTORY");
            string str = string.Empty;
            string deviceID = string.Empty;
            try
            {
                var invent = Json.Decode(SyncData);

                //string deviceID = string.Empty;
                string tokenId = string.Empty;

                deviceID = invent.Compartment.DeviceID;
                tokenId = invent.Compartment.TokenID;

                clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
                objAuth = ValidateAuthToken(deviceID, tokenId);
                //Log.Writelog("Device ID-- " + deviceID.ToString(), "INVENTORY");
                Log.Writelog(deviceID, "isValidToken--" + objAuth.IsValidToken.ToString(), "INVENTORY");
                if (objAuth.IsValidToken == true)
                {
                    objCompartment.COMPNO = invent.Compartment.COMPNO;
                    validateCompno = invent.Compartment.COMPNO;
                    objCompartment.CompSlno = invent.Compartment.CompSlno;
                    objCompartment.FeatID = invent.Compartment.FeatID;
                    FeatID = invent.Compartment.FeatID;

                    try
                    {
                        validateInvType = invent.Compartment.ComptInventoryType;
                    }
                    catch (Exception ex)
                    {
                        Log.Writelog(deviceID, ex.Message, "INVENTORY");
                        Log.WritePendinglog(SyncData, "INVENTORY");
                    }
                    // Find out if the survey is duplicated

                    // Insert the details
                    objResponse.CompartmentNo = string.Empty;

                    objResponse.InvType = string.Empty;
                    objResponse.FeatID = string.Empty;
                    objResponse.ErrorMessage = string.Empty;
                    objResponse.Status = string.Empty;
                    objResponseClass.ResponseMessage = objResponse;

                    objResponseClass = objBLInventory.InsertInventoryDetails(objCompartment);

                    //Adding TreeMap Header, Detail and Damage Details into List
                    List<TreeMapHeader> treeMapInfo = new List<TreeMapHeader>();
                    if (invent.Compartment.TREEMAP_HEADER != null)
                    {
                        int headerCount = invent.Compartment.TREEMAP_HEADER.Length;
                        if (headerCount > 0)
                        {
                            for (int i = 0; i < headerCount; i++)
                            {
                                //Adding TreeMap Header into TreeMap List
                                TreeMapHeader treeMapHeader = new TreeMapHeader();
                                treeMapHeader.InvType = invent.Compartment.TREEMAP_HEADER[i].InvType;
                                treeMapHeader.PlotNo = invent.Compartment.TREEMAP_HEADER[i].PlotNo;
                                treeMapHeader.StartFrom = invent.Compartment.TREEMAP_HEADER[i].StartFrom;

                                treeMapHeader.Details = new List<TreeMapDetail>();
                                if (invent.Compartment.TREEMAP_HEADER[i].TREEMAP_DETAIL != null)
                                {
                                    int detailCount = invent.Compartment.TREEMAP_HEADER[i].TREEMAP_DETAIL.Length;
                                    if (detailCount > 0)
                                    {
                                        for (int j = 0; j < detailCount; j++)
                                        {
                                            //Adding TreeMap Details into TreeMap List
                                            TreeMapDetail treeMapDetail = new TreeMapDetail();
                                            treeMapDetail.TreeNumber = invent.Compartment.TREEMAP_HEADER[i].TREEMAP_DETAIL[j].TreeNumber;
                                            treeMapDetail.Top = invent.Compartment.TREEMAP_HEADER[i].TREEMAP_DETAIL[j].Top;
                                            treeMapDetail.Left = invent.Compartment.TREEMAP_HEADER[i].TREEMAP_DETAIL[j].Left;
                                            treeMapHeader.Details.Add(treeMapDetail);
                                        }
                                    }
                                }
                                treeMapInfo.Add(treeMapHeader);
                            }
                        }
                    }

                    //Insert / Update TreeMap Info
                    objBLInventory.InsertOrUpdateInventoryTreeMap(treeMapInfo, objCompartment.COMPNO, objCompartment.FeatID);

                    Log.Writelog(deviceID, "InsertPlotSurvey - out from - InsertInventoryDetails" + objResponseClass.ResponseMessage.ToString(), "INVENTORY");
                    // Uma - Jan - 06 -2015
                    // The feat id is passed in argument 

                    /*bool boolValidateDuplicateSurvey = objBLInventory.ValidateDuplicateSurvey(FeatID,validateCompno, validateInvType);

                    if (boolValidateDuplicateSurvey == false)
                    {
                        objResponseClass = objBLInventory.InsertInventoryDetails(objCompartment);

                        if (str == "SAVED")
                        {
                            objResponse.CompartmentNo = validateCompno;
                            objResponse.InvType = validateInvType;
                            objResponse.ErrorMessage = "";
                            objResponse.Status = "Successfully Saved";
                            objResponseClass.ResponseMessage = objResponse;
                            str = "Successfully Saved";
                        }

                    } // end of if --- if the survey is saved for the first time
                    else
                    {
                        Log.WritePendinglog(SyncData, "INVENTORY");
                        //If the survey is duplicated
                        objResponse.CompartmentNo = validateCompno;
                        objResponse.InvType = validateInvType;
                        objResponse.FeatID = FeatID;
                        objResponse.ErrorMessage = "You can not insert duplicate survey";
                        objResponse.Status = "Exist";
                        objResponseClass.ResponseMessage = objResponse;
                        str = "Duplicate survey";

                    }*/
                } // end if isValidToken

                else
                {
                    // if token is invalid 
                    Log.WritePendinglog(SyncData, "INVENTORY");
                    objResponse.CompartmentNo = "";
                    objResponse.InvType = "";
                    objResponse.FeatID = "";
                    objResponse.ErrorMessage = objAuth.Message;
                    objResponse.Status = "";
                    objResponseClass.ResponseMessage = objResponse;

                }

                Log.Writelog(deviceID, str, "INVENTORY");
                Log.Writelog(deviceID, "InsertPlotSurvey - Response error message " + objResponseClass.ResponseMessage.ErrorMessage, "INVENTORY");
                Log.Writelog(deviceID, "InsertPlotSurvey - Response status message " + objResponseClass.ResponseMessage.Status, "INVENTORY");
            }
            catch (Exception ex)
            {
                Log.WritePendinglog("<START>", "INVENTORY");
                Log.WritePendinglog(SyncData, "INVENTORY");
                Log.WritePendinglog("<END>", "INVENTORY");
                Log.WritePendinglog(ex.Message, "INVENTORY");
                Log.WritePendinglog(ex.InnerException.ToString(), "INVENTORY");
                Log.Writelog(deviceID, ex.Message, "INVENTORY");
                Log.Writelog(deviceID, ex.InnerException.ToString(), "INVENTORY");
            }
            //Added for Pending logs
            if (objResponseClass.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "INVENTORY");
                Log.WritePendinglog(SyncData, "INVENTORY");
                Log.WritePendinglog("<END>", "INVENTORY");

            }
            return objResponseClass;
        }
        #endregion InsertPlotSurvey

        #region InsertPlotSurvey
        public InventoryResponseClass InsertPlots(string SyncData)
        {
            string validateCompno = string.Empty;
            string validateInvType = string.Empty;
            InventoryResponseMessage objResponse = new InventoryResponseMessage();
            InventoryResponseClass objResponseClass = new InventoryResponseClass();
            clsPlotSurveyDet objPlotSurveyDet;
            List<clsPlotSpacing> lstPlotSpacing = new List<clsPlotSpacing>();
            List<clsWeedCoverage> lstWeedCoverage = new List<clsWeedCoverage>();
            List<clsLAI> lstLai = new List<clsLAI>();
            List<clsTreeSurvey> lstTreeSurvey = new List<clsTreeSurvey>();
            List<clsTreeImage> lstTreeImages = new List<clsTreeImage>();
            List<clsPlotSurveyDet> lst = new List<clsPlotSurveyDet>();
            //Added By Smrithy -05-11-2015
            List<clsPlotCenterDistance> lstPlotDistance = new List<clsPlotCenterDistance>();
            string FeatID = string.Empty;

            BLInventory objBLInventory = new BLInventory();
            // Log.Writelog("In InsertPlots of RGEService", "INVENTORY");
            clsComparmentDet objCompartment = new clsComparmentDet();

            Log.Writelog(SyncData, "INVENTORY");
            string str = string.Empty;
            string deviceID = string.Empty;
            try
            {
                var invent = Json.Decode(SyncData);
                var invCompartment =
                // Insert the details
                objResponse.CompartmentNo = string.Empty;
                objResponse.InvType = string.Empty;
                objResponse.FeatID = string.Empty;
                objResponse.ErrorMessage = string.Empty;
                objResponse.Status = string.Empty;
                objResponseClass.ResponseMessage = objResponse;

                // Uma - Jan - 06 -2015
                // The feat id is passed in argument 
                int i = invent.Plot.Length;
                for (int j = 0; j < i; j++)
                {
                    //TokenID
                    //string deviceID = string.Empty;
                    string tokenId = string.Empty;
                    string compSlNo = string.Empty;

                    deviceID = invent.Plot[j].DeviceID;
                    tokenId = invent.Plot[j].TokenID;
                    compSlNo = invent.Plot[j].CompSlno;

                    clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
                    objAuth = ValidateAuthToken(deviceID, tokenId);
                    //Log.Writelog("Device ID-- " + deviceID.ToString(), "INVENTORY");
                    Log.Writelog(deviceID, "isValidToken--" + objAuth.IsValidToken.ToString(), "INVENTORY");
                    Log.Writelog(deviceID, "CompSlno--" + compSlNo, "INVENTORY");

                    if (objAuth.IsValidToken == true || compSlNo != string.Empty)
                    {
                        objPlotSurveyDet = new clsPlotSurveyDet();
                        objPlotSurveyDet.AzimuthPlotLine = invent.Plot[j].AzimuthPlotLine;
                        objPlotSurveyDet.COMPLETE = invent.Plot[j].COMPLETE;
                        objPlotSurveyDet.Flooding = invent.Plot[j].Flooding;
                        objPlotSurveyDet.Keyedinby = "3";
                        objPlotSurveyDet.MaintainenceStatus = invent.Plot[j].MaintainenceStatus;
                        objPlotSurveyDet.Name = invent.Plot[j].Name;
                        objPlotSurveyDet.PCreatedBy = invent.Plot[j].PCreatedBy;
                        objPlotSurveyDet.PCreatedDate = invent.Plot[j].PCreatedDate;
                        objPlotSurveyDet.PRemarks = invent.Plot[j].PRemarks;

                        try
                        {
                            objPlotSurveyDet.StratumNo = invent.Plot[j].StratumNo != null ? int.Parse(invent.Plot[j].StratumNo) : -1;
                        }
                        catch
                        {
                            objPlotSurveyDet.StratumNo = -1;
                        }

                        try
                        {
                            objPlotSurveyDet.StratumHa = invent.Plot[j].StratumHa != null ? decimal.Parse(invent.Plot[j].StratumHa) : -1;
                        }
                        catch
                        {
                            objPlotSurveyDet.StratumHa = -1;
                        }

                        try
                        {
                            objPlotSurveyDet.StratumIsBlankSpot = invent.Plot[j].StratumIsBlankSpot != null ? Convert.ToBoolean(int.Parse(invent.Plot[j].StratumIsBlankSpot)) : false;
                        }
                        catch
                        {
                            objPlotSurveyDet.StratumIsBlankSpot = false;
                        }

                        objPlotSurveyDet.PlotCenterXDirection = invent.Plot[j].PlotCenterXDirection;
                        objPlotSurveyDet.PlotCenterYdirection = invent.Plot[j].PlotCenterYdirection;
                        objPlotSurveyDet.PlotNo = invent.Plot[j].PlotNo;
                        objPlotSurveyDet.PlotRadius = invent.Plot[j].PlotRadius;
                        objPlotSurveyDet.Plotcenterlat = invent.Plot[j].Plotcenterlat;
                        objPlotSurveyDet.Plotcenterlong = invent.Plot[j].Plotcenterlong;
                        objPlotSurveyDet.Plotcenterlat = invent.Plot[j].Plotcenterlat;
                        objPlotSurveyDet.SAPID = invent.Plot[j].SAPID;

                        //this is not required by mobile team
                        objPlotSurveyDet.CompSlno = invent.Plot[j].CompSlno;
                        objPlotSurveyDet.SCreatedBy = invent.Plot[j].SCreatedBy;
                        objPlotSurveyDet.SCreatedDate = DateTime.Now.ToString();
                        try
                        {
                            objPlotSurveyDet.PlotSerialNo = invent.Plot[j].PlotSerialNo;
                        }
                        catch (Exception ex) { Log.Writelog(ex.Message, "INVENTORY"); }
                        objPlotSurveyDet.SInventoryType = invent.Plot[j].SInventoryType;
                        objPlotSurveyDet.SModifiedBy = invent.Plot[j].SModifiedBy;
                        objPlotSurveyDet.SModifiedDate = invent.Plot[j].SModifiedDate;
                        objPlotSurveyDet.SRemarks = invent.Plot[j].SRemarks;
                        objPlotSurveyDet.SamplePercentage = invent.Plot[j].SamplePercentage;
                        objPlotSurveyDet.SoilSampleCollected = invent.Plot[j].SoilSampleCollected;
                        objPlotSurveyDet.SurGPSLat = invent.Plot[j] != null ? ToLongString(invent.Plot[j].SurGPSLat) : invent.Plot[j].SurGPSLat;
                        objPlotSurveyDet.SurGPSLong = invent.Plot[j].SurGPSLong;
                        objPlotSurveyDet.SurveyDate = invent.Plot[j].SurveyDate;
                        objPlotSurveyDet.SurveyLineNo = invent.Plot[j].SurveyLineNo;
                        objPlotSurveyDet.SurveyNo = invent.Plot[j].SurveyNo;
                        objPlotSurveyDet.TeamCode = invent.Plot[j].TeamCode;
                        objPlotSurveyDet.TotalHealthy = invent.Plot[j].TotalHealthy;
                        objPlotSurveyDet.TotalLiveYellow = invent.Plot[j].TotalLiveYellow;
                        objPlotSurveyDet.TotalDead = invent.Plot[j].TotalDead;
                        validateInvType = invent.Plot[j].SInventoryType;
                        lst.Add(objPlotSurveyDet);
                        int ctr = invent.Plot[j].PlotSpacing.Length;

                        //Plot spacing
                        for (int k = 0; k < ctr; k++)
                        {
                            clsPlotSpacing obj = new clsPlotSpacing();
                            obj.PlotNo = invent.Plot[j].PlotNo;
                            obj.BRI = invent.Plot[j].PlotSpacing[k].BRI;
                            obj.IRI = invent.Plot[j].PlotSpacing[k].IRI;
                            obj.BRITREES = invent.Plot[j].PlotSpacing[k].BRITREES;
                            obj.IRITREES = invent.Plot[j].PlotSpacing[k].IRITREES;
                            obj.TREEREMARKS = invent.Plot[j].PlotSpacing[k].SPACING_TREEREMARKS;
                            lstPlotSpacing.Add(obj);
                            obj = null;
                        }
                        //Weed Coverage
                        ctr = 0;
                        ctr = invent.Plot[j].WeedCoverage.Length;
                        var cwArr = invent.Plot[j].WeedCoverage[0];
                        foreach (var cs in cwArr)
                        {
                            clsWeedCoverage wcObj = new clsWeedCoverage();
                            wcObj.PlotNo = invent.Plot[j].PlotNo;
                            wcObj.Col = cs.Key;
                            wcObj.Val = cs.Value;
                            lstWeedCoverage.Add(wcObj);
                            wcObj = null;
                        }
                        //LAI
                        ctr = 0;
                        ctr = invent.Plot[j].LAI.Length;
                        var LaiArr = invent.Plot[j].LAI[0];
                        foreach (var cs in LaiArr)
                        {
                            clsLAI laiObj = new clsLAI();
                            laiObj.PlotNo = invent.Plot[j].PlotNo;
                            laiObj.Col = cs.Key;
                            laiObj.Val = cs.Value;
                            lstLai.Add(laiObj);
                            laiObj = null;
                        }
                        //Tree survey details    
                        ctr = 0;
                        ctr = invent.Plot[j].Trees.Length;
                        for (int k = 0; k < ctr; k++)
                        {
                            clsTreeSurvey obj = new clsTreeSurvey();
                            obj.PlotNo = invent.Plot[j].PlotNo;
                            obj.COMPNO = invent.Plot[j].COMPNO;
                            obj.DBH = invent.Plot[j].Trees[k].DBH;
                            obj.HCB = invent.Plot[j].Trees[k].HCB;
                            obj.StemCode = invent.Plot[j].Trees[k].StemCode;
                            //Added by Soumitri on 28/05/2018 for the Remarks column on the Tree Details
                            obj.TreeRemarks = invent.Plot[j].Trees[k].TreeRemarks;
                            obj.TInventoryType = invent.Plot[j].SInventoryType;
                            obj.X = invent.Plot[j].Trees[k].X;
                            obj.Y = invent.Plot[j].Trees[k].Y;
                            obj.TOPHEIGHT = invent.Plot[j].Trees[k].TopHeight;
                            obj.TreeNo = invent.Plot[j].Trees[k].TreeNo;
                            obj.TSHeight = invent.Plot[j].Trees[k].Height;
                            obj.TreeProperties = invent.Plot[j].Trees[k].PropertyList;
                            obj.ImageName = invent.Plot[j].Trees[k].imageNameList;

                            try
                            {
                                obj.ImageDescription = invent.Plot[j].Trees[k].ImageDescription;
                            }
                            catch (Exception ex)
                            {
                                Log.Writelog(deviceID, ex.Message, "INVENTORY");
                            }
                            lstTreeSurvey.Add(obj);
                            obj = null;
                        }
                        //Added by Smrithy -05-11-2015
                        ctr = 0;
                        try
                        {
                            ctr = invent.Plot[j].PlotCenterDistance.Length;
                        }
                        catch (Exception ex)
                        {
                            Log.Writelog(deviceID, "PlotcenterDistance not available" + ex.Message, "INVENTORY");
                        }
                        for (int h = 0; h < ctr; h++)
                        {
                            //PlotCenterDistance
                            clsPlotCenterDistance objPlotDistance = new clsPlotCenterDistance();
                            objPlotDistance.PlotNo = invent.Plot[j].PlotNo;
                            objPlotDistance.TreeNo = invent.Plot[j].PlotCenterDistance[h].TreeNo;
                            objPlotDistance.Distance = invent.Plot[j].PlotCenterDistance[h].Distance;
                            lstPlotDistance.Add(objPlotDistance);
                            objPlotDistance = null;
                        }

                        objResponseClass = objBLInventory.InsertInventoryPlots(lst, lstPlotSpacing, lstTreeSurvey, lstTreeImages, lstPlotDistance, lstWeedCoverage, compSlNo, lstLai);

                        if (str == "SAVED")
                        {
                            objResponse.CompartmentNo = validateCompno;
                            objResponse.InvType = validateInvType;

                            objResponse.ErrorMessage = "";
                            objResponse.Status = "Successfully Saved";
                            objResponseClass.ResponseMessage = objResponse;
                            str = "Successfully Saved";
                        }

                        Log.Writelog(deviceID, "InsertPlots - Response error message " + objResponseClass.ResponseMessage.ErrorMessage, "INVENTORY");
                        Log.Writelog(deviceID, "InsertPlots - Response status message " + objResponseClass.ResponseMessage.Status, "INVENTORY");

                    }
                }

            }
            catch (Exception ex)
            {
                Log.Writelog(deviceID, ex.Message, "INVENTORY");
                Log.Writelog(deviceID, ex.StackTrace, "INVENTORY");
                Log.WritePendinglog("<START>", "INVENTORY");
                Log.WritePendinglog(SyncData, "INVENTORY");
                Log.WritePendinglog("<END>", "INVENTORY");
                Log.WritePendinglog(ex.InnerException.ToString(), "INVENTORY");
                Log.Writelog(deviceID, ex.Message, "INVENTORY");
                Log.Writelog(deviceID, ex.InnerException.ToString(), "INVENTORY");

            }
            //Added for Pending logs
            if (objResponseClass.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "INVENTORY");
                Log.WritePendinglog(SyncData, "INVENTORY");
                Log.WritePendinglog("<END>", "INVENTORY");

            }
            return objResponseClass;
        }
        #endregion InsertPlotSurvey

        #region FetchCompartmentData

        public clsGetResponse FetchCompDataByInvType(string inventoryType, string sector, string inventoryDate, string deviceID, string tokenId)
        {
            // Application : Inventory
            Log.Writelog(deviceID, " In FetchCompDataByInvType of RGEService.svc.cs - Inventory type " + inventoryType + " sector - " + sector + " inventoryDate -  " + inventoryDate, "INVENTORY");
            clsGetResponse objInvResponse = new clsGetResponse();
            clsGetResponseMessage objInvResponseMsg = new clsGetResponseMessage();
            List<ClsCompartment> lstCompartment = new List<ClsCompartment>();
            clsMainCompartment objMainComp = new clsMainCompartment();
            BLInventory objBLInventory = new BLInventory();

            try
            {

                //Log.Writelog("Fetching the data ..........");
                //TokenID

                clsAuthTokenValidation obj = new clsAuthTokenValidation();
                obj = ValidateAuthToken(deviceID, tokenId);
                if (obj.IsValidToken == true)
                {
                    lstCompartment = objBLInventory.FetchCompDataByInvType(inventoryType, sector, Convert.ToDateTime(inventoryDate));
                    // Log.Writelog("Assigning to objMainComp.Compartments");
                    objMainComp.Compartments = lstCompartment;

                    objInvResponseMsg.Status = "Success";
                    objInvResponseMsg.ErrorMessage = "";


                    objInvResponseMsg.Response = objMainComp;
                    objInvResponse.ResponseMessage = objInvResponseMsg;
                }
                else
                {
                    objInvResponseMsg.Status = "Error";
                    objInvResponseMsg.ErrorMessage = obj.Message;
                    objInvResponseMsg.Response = objMainComp;
                    objInvResponse.ResponseMessage = objInvResponseMsg;
                }

            }
            catch (Exception e)
            {
                Log.Writelog(deviceID, e.Message, "INVENTORY");
                Log.Writelog(deviceID, e.InnerException.ToString(), "INVENTORY");
            }
            return objInvResponse;
        }
        #endregion FetchCompartmentData

        #region FetchTreeMapData
        public List<TreeMapHeader> FetchTreeMapData(string compartmentNo, string featID)
        {
            // Application : Inventory
            Log.Writelog("In FetchTreeMapData of RGEService.svc.cs - Compartment No :" + compartmentNo + " - FeatID :" + featID, "INVENTORY");
            List<TreeMapHeader> lstTreeMap = new List<TreeMapHeader>();
            BLInventory objBLInventory = new BLInventory();

            try
            {
                lstTreeMap = objBLInventory.FetchTreeMapData(featID);
            }
            catch (Exception e)
            {
                Log.Writelog(e.Message, "INVENTORY");
                Log.Writelog(e.InnerException.ToString(), "INVENTORY");
            }
            return lstTreeMap;
        }

        public List<TreeMapHeaderComp> FetchTreeMapDataList(List<string> featIDs)
        {
            // Application : Inventory
            Log.Writelog("In FetchTreeMapDataList of RGEService.svc.cs", "INVENTORY");
            List<TreeMapHeaderComp> lstTreeMapList = new List<TreeMapHeaderComp>();
            BLInventory objBLInventory = new BLInventory();

            try
            {
                foreach (var featID in featIDs)
                {
                    TreeMapHeaderComp comp = new TreeMapHeaderComp();
                    comp.FeatID = featID;
                    comp.Headers = objBLInventory.FetchTreeMapData(featID);
                    lstTreeMapList.Add(comp);
                }
            }
            catch (Exception e)
            {
                Log.Writelog(e.Message, "INVENTORY");
                Log.Writelog(e.InnerException.ToString(), "INVENTORY");
            }
            return lstTreeMapList;
        }
        #endregion FetchTreeMapData

        //Added on 28/05/2018 By Soumitri for DBH Master Types for MIN & MAX Values
        #region GetDBHType
        public clsMainDBHType GetDBHType()
        {
            clsMainDBHType obMain = new clsMainDBHType();
            List<clsDBHType> lstInvDBHTypes = new List<clsDBHType>();
            BLInventory objBLInventory = new BLInventory();
            lstInvDBHTypes = objBLInventory.GetDBHType();
            obMain.DBHTypeList = lstInvDBHTypes;
            return obMain;
        }
        #endregion GetDBHType

        #region GetInventoryTypes
        public clsMainInventoryType GetInventoryTypes()
        {
            clsMainInventoryType main = new clsMainInventoryType();
            List<clsInventoryType> lstInvTypes = new List<clsInventoryType>();
            BLInventory objBLInventory = new BLInventory();
            lstInvTypes = objBLInventory.GetInventoryTypes();
            main.InventoryTypeList = lstInvTypes;

            return main;
        }
        #endregion

        #endregion Inventory

        #region Wood Supply
        #region GetTripTicketDetailsBySector
        /// <summary>
        /// Fetching the trip truck details by passing the sector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>

        public clsMainTripTicket GetTripTicketDetailsBySector(string sector)
        {
            //Application : Wood Supply

            clsMainTripTicket obj = new clsMainTripTicket();
            List<clsTripTicket> lstTripData = new List<clsTripTicket>();
            BLInventory objBLInventory = new BLInventory();
            lstTripData = objBLInventory.GetTripTicketDetailsBySector(sector);
            obj.GetTripData = lstTripData;
            return obj;
        }
        #endregion GetTripTicketDetailsBySector

        #region GetRktLicenses
        public clsMainRktLicense GetRktLicensesBySector(String sector, String deviceID)
        {
            clsMainRktLicense obj = new clsMainRktLicense();
            List<clsRktLicense> lstRktLicense = new List<clsRktLicense>();

            BLInventory objBLInventory = new BLInventory();
            lstRktLicense = objBLInventory.GetRktLicensesBySector(sector);
            obj.FinalRktLicense = lstRktLicense;
            return obj;
        }
        #endregion GetRktLicenses

        #region GetRoadConditions
        public clsMainRoad GetRoadConditions(String deviceID)
        {
            clsMainRoad obj = new clsMainRoad();
            List<clsRoad> lstRoadConditions = new List<clsRoad>();

            BLInventory objBLInventory = new BLInventory();
            lstRoadConditions = objBLInventory.GetRoadConditions();
            obj.RoadConditions = lstRoadConditions;
            return obj;
        }
        #endregion GetRoadConditions

        #region GetWeather
        public clsMainWeather GetWeatherConditions(String deviceID)
        {
            clsMainWeather obj = new clsMainWeather();
            List<clsWeather> lstWeatherConditions = new List<clsWeather>();

            BLInventory objBLInventory = new BLInventory();
            lstWeatherConditions = objBLInventory.GetWeatherConditions();
            obj.Weathers = lstWeatherConditions;
            return obj;
        }
        #endregion GetWeather

        #region GetTripTicketWithoutLoadedTime
        public clsMainTripTicketNoLoadedTime GetTripTicketWithoutLoadedTime(String sector, String deviceID)
        {
            clsMainTripTicketNoLoadedTime obj = new clsMainTripTicketNoLoadedTime();
            List<clsTripTicketNoLoadedTime> lstTripTicketNoLoadedTime = new List<clsTripTicketNoLoadedTime>();

            BLInventory objBLInventory = new BLInventory();
            lstTripTicketNoLoadedTime = objBLInventory.GetTripTicketWithoutLoadedTime(sector);
            obj.TripTicketsNoLoadedTime = lstTripTicketNoLoadedTime;

            Log.Writelog(deviceID, "GetTripTicketWithoutLoadedTime - result count" + lstTripTicketNoLoadedTime.Count, "WOODSUPPLY");
            return obj;
        }
        #endregion GetTripTicketWithoutLoadedTime

        #region FetchStaticReferenceData
        public clsMainRefData FetchStaticReferenceData(string sector, string deviceID)
        {
            //Application:  Wood supply

            //Log.Writelog("In BL layer Fetching static reference data for wood supply app", "WOODSUPPLY");
            Log.Writelog(deviceID, "In BL layer Fetching static reference data for wood supply app", "WOODSUPPLY");
            Log.Writelog(deviceID, "In BL layer Fetching static reference data for wood supply app; sector: " + sector, "WOODSUPPLY");
            clsMainRefData objMainRef = new clsMainRefData();
            clsGetReferencedData objGetRef = new clsGetReferencedData();
            BLInventory objBLInventory = new BLInventory();
            if (sector != "")
            {
                //Contr
                List<clsContactors> lstCont = new List<clsContactors>();
                lstCont = objBLInventory.FetchContactorsData(sector);
                objGetRef.Contractors = lstCont;

                // Conver
                List<clsConversions> lstConv = new List<clsConversions>();
                lstConv = objBLInventory.FetchConversionsData(sector);
                objGetRef.Conversions = lstConv;

                //VehicleSw
                List<clsVehicleSw> lstVeh = new List<clsVehicleSw>();
                lstVeh = objBLInventory.FetchVehicleSwData(sector);
                objGetRef.VehicleSW = lstVeh;

            }

            //Barge
            List<clsBarge> lstBarge = new List<clsBarge>();
            lstBarge = objBLInventory.FetchBargeData();
            objGetRef.Barge = lstBarge;

            //Depots
            List<clsDepots> lstDepots = new List<clsDepots>();
            lstDepots = objBLInventory.FetchDepoData();
            objGetRef.Depots = lstDepots;


            objMainRef.referencedata = objGetRef;

            Log.Writelog(deviceID, "In BL layer Fetching static reference data for wood supply app - completed", "WOODSUPPLY");
            return objMainRef;
        }
        #endregion FetchStaticReferenceData

        #region FetchStaticReferenceData_master_data
        public clsMainRefData FetchStaticReferenceDataMasterData(string deviceID)
        {
            //Log.Writelog("In BL layer Fetching static reference data for wood supply app", "WOODSUPPLY");
            Log.Writelog(deviceID, "BL FetchStaticReferenceDataMasterData", "WOODSUPPLY");
            clsMainRefData objMainRef = new clsMainRefData();
            clsGetReferencedData objGetRef = new clsGetReferencedData();
            BLInventory objBLInventory = new BLInventory();

            //Barge
            List<clsBarge> lstBarge = new List<clsBarge>();
            lstBarge = objBLInventory.FetchBargeData();
            objGetRef.Barge = lstBarge;

            //Depots
            List<clsDepots> lstDepots = new List<clsDepots>();
            lstDepots = objBLInventory.FetchDepoData();
            objGetRef.Depots = lstDepots;
            objMainRef.referencedata = objGetRef;

            Log.Writelog(deviceID, "BL FetchStaticReferenceDataMasterData - completed", "WOODSUPPLY");
            return objMainRef;
        }
        #endregion FetchStaticReferenceData_master_data

        #region FetchStaticReferenceData_sector_data
        public clsMainRefData FetchStaticReferenceDataSectorData(string sector, string deviceID)
        {
            Log.Writelog(deviceID, "BL FetchStaticReferenceDataSectorData; sector: " + sector, "WOODSUPPLY");
            clsMainRefData objMainRef = new clsMainRefData();
            clsGetReferencedData objGetRef = new clsGetReferencedData();
            BLInventory objBLInventory = new BLInventory();

            //Contr
            List<clsContactors> lstCont = new List<clsContactors>();
            lstCont = objBLInventory.FetchContactorsData(sector);
            objGetRef.Contractors = lstCont;

            // Conver
            List<clsConversions> lstConv = new List<clsConversions>();
            lstConv = objBLInventory.FetchConversionsData(sector);
            objGetRef.Conversions = lstConv;

            //VehicleSw
            List<clsVehicleSw> lstVeh = new List<clsVehicleSw>();
            lstVeh = objBLInventory.FetchVehicleSwData(sector);
            objGetRef.VehicleSW = lstVeh;

            objMainRef.referencedata = objGetRef;

            Log.Writelog(deviceID, "BL FetchStaticReferenceDataSectorData - completed", "WOODSUPPLY");
            return objMainRef;
        }
        #endregion FetchStaticReferenceData_sector_data

        #region GetWODetails

        public clsMainWO GetWODetails()
        {
            //Application : 

            clsMainWO objWO = new clsMainWO();
            List<clsWorkOrder> lstWOData = new List<clsWorkOrder>();
            BLInventory objBLInventory = new BLInventory();
            lstWOData = objBLInventory.GetWODetails();
            objWO.GetWOrkOrder = lstWOData;
            return objWO;
        }
        public clsWoodResponse GetWODetailsBySector(string sector, string deviceID, string tokenId)
        {

            clsMainWO objWO = new clsMainWO();
            BLInventory objBLInventory = new BLInventory();
            clsWoodResponse objWoodResponse = new clsWoodResponse();
            clsWoodResponseMessage objWoodRespMessage = new clsWoodResponseMessage();
            Log.Writelog("GetWODetailsBySector", "WOODSUPPLY");
            try
            {
                //TokenID

                clsAuthTokenValidation obj = new clsAuthTokenValidation();
                obj = ValidateAuthToken(deviceID, tokenId);

                if (obj.IsValidToken == true)
                {
                    clsWorkOrder objWork = new clsWorkOrder();
                    List<clsWorkOrder> lstWOData = new List<clsWorkOrder>();

                    lstWOData = objBLInventory.GetWODetailsBySector(sector);

                    objWO.GetWOrkOrder = lstWOData;
                    objWoodRespMessage.Status = "Success";
                    objWoodRespMessage.ErrorMessage = "";
                    objWoodRespMessage.Response = objWO;
                    objWoodResponse.ResponseMessage = objWoodRespMessage;
                }
                else
                {
                    objWoodRespMessage.Status = "Error";
                    objWoodRespMessage.ErrorMessage = obj.Message;
                    objWoodRespMessage.Response = objWO;
                    objWoodResponse.ResponseMessage = objWoodRespMessage;
                }
            }
            catch (Exception ex)
            {


                Log.Writelog("GetWODetailsBySector Method : " + ex.Message, "WOODSUPPLY");

            }
            return objWoodResponse;
        }
        #endregion GetWODetails

        #region GetLoadingUnloadingWO

        public clsMainLoadingUnloadingWO GetLoadingUnloadingWO(string woNumber)
        {
            //Application : Wood Supply


            clsMainLoadingUnloadingWO objMain = new clsMainLoadingUnloadingWO();
            clsLoadingUnloadingWO obj = new clsLoadingUnloadingWO();
            List<clsLoadingWO> lstloadingWO = new List<clsLoadingWO>();
            BLInventory objBLInventory = new BLInventory();
            lstloadingWO = objBLInventory.GetLoadingWO(woNumber);
            obj.LoadingWO = lstloadingWO;

            List<clsUnloadingWO> lstUnloadingWO = new List<clsUnloadingWO>();
            lstUnloadingWO = objBLInventory.GetUnLoadingWO(woNumber);
            //obj = new clsLoadingUnloadingWO();
            obj.UnLoadingWO = lstUnloadingWO;
            objMain.WO_List = obj;
            return objMain;
        }

        #endregion GetLoadingUnloadingWO

        #region GetFellingExtractionWO

        public clsMainFellingExtraction GetFellingExtractionWO(string woNumber)
        {
            clsMainFellingExtraction objMain = new clsMainFellingExtraction();
            clsGetFellingExtraction obj = new clsGetFellingExtraction();
            List<clsFellingData> lstFellingWO = new List<clsFellingData>();
            BLInventory objBLInventory = new BLInventory();
            lstFellingWO = objBLInventory.GetFellingWO(woNumber);
            obj.FellingWO = lstFellingWO;

            List<clsExtractingData> lstExtractingWO = new List<clsExtractingData>();
            lstExtractingWO = objBLInventory.GetExtractionWO(woNumber);
            //obj = new clsLoadingUnloadingWO();
            obj.ExtractionWO = lstExtractingWO;
            objMain.WO_List = obj;
            return objMain;
        }

        #endregion GetFellingExtractionWO

        #region SetArrivedDatetime
        /// <summary>
        /// To update TW_TRIP_TICKET_DATA table with status and arrivedAtUKdatetime
        /// </summary>
        /// <param name="tripTicketNo"></param>
        /// <param name="status"></param>
        /// <param name="arrivedAtUKdatetime"></param>
        /// <returns></returns>
        public string SetArrivedDatetime(string tripTicketNo, string status, string arrivedAtUKdatetime, string LoadingPoint)
        {
            BLInventory objBLInventory = new BLInventory();
            //return objBLInventory.SetArrivedDatetime(Convert.ToInt32(tripTicketNo), status, arrivedAtUKdatetime);   //Todo: Guaz: to comment out once db is updated to varchar
            return objBLInventory.SetArrivedDatetime(tripTicketNo, status, arrivedAtUKdatetime, LoadingPoint);
        }
        #endregion SetArrivedDatetime

        #region SetLoadedArrivedDatetime
        /// <summary>
        /// To update TW_TRIP_TICKET_DATA table with status and arrivedAtUKdatetime
        /// </summary>
        /// <param name="tripTicketNo"></param>
        /// <param name="status"></param>
        /// <param name="loadedArrivedAtUKdatetime"></param>
        /// <returns></returns>
        public string SetLoadedArrivedDatetime(string tripTicketNo, string status, string loadedArrivedAtUKdatetime)
        {
            BLInventory objBLInventory = new BLInventory();
            //return objBLInventory.SetLoadedArrivedDatetime(Convert.ToInt32(tripTicketNo), status, loadedArrivedAtUKdatetime);       //Todo: Guaz: to comment out once db is updated to varchar
            return objBLInventory.SetLoadedArrivedDatetime(tripTicketNo, status, loadedArrivedAtUKdatetime);
        }
        #endregion SetLoadedArrivedDatetime


        #region InsertStackWODetails
        public ResponseClass InsertStackWODetails(string[] stackObj)
        {
            // public string InsertStackWODetails(string[] stackObj)
            // Application : Wood Supply
            // This method is used to insert the stack details.
            //uma

            string strSave = "  in InsertStackWODetails of RGEService.cs";
            Log.Writelog(strSave, "WOODSUPPLY");
            int ctr = stackObj.Length;
            ResponseClass objResponse = new ResponseClass();
            ResponseMessage objResponseMessage = new ResponseMessage();
            string strPCSNo = string.Empty;
            try
            {
                for (int i = 0; i < ctr; i++)
                {
                    Log.Writelog(stackObj[i], "WOODSUPPLY");
                }

                //List<testclsWOStack> resultStack = new List<testclsWOStack>();
                BLInventory objBLInventory = new BLInventory();

                //resultStack = ReadSetWorkOrderStack2(stackObj);

                List<clsPCSStack> lstSatckDetails = new List<clsPCSStack>();
                clsPCSStack objStackDetails;

                if (ctr > 0)
                {
                    for (int i = 0; i < ctr; i++)
                    {


                        var resstack = Json.Decode(stackObj[i]);


                        objStackDetails = new clsPCSStack();
                        objStackDetails.PCSNO = resstack.PCSNO;
                        strPCSNo = resstack.PCSNO;
                        objStackDetails.STACKNO = Convert.ToString(resstack.STACKNO);
                        objStackDetails.L = Convert.ToString(resstack.L);
                        objStackDetails.H = Convert.ToString(resstack.H);
                        objStackDetails.W = Convert.ToString(resstack.W);
                        objStackDetails.CF = Convert.ToString(resstack.CF);
                        //objStackDetails.ETLStatus = resstack.ETLStatus;
                        //objStackDetails.ProcessDate = resstack.ProcessDate;
                        if (strPCSNo.Trim().Length > 0)
                        {
                            if (Convert.ToInt32(strPCSNo) > 0)
                            {
                                lstSatckDetails.Add(objStackDetails);
                            }
                        }
                        objStackDetails = null;
                        resstack = null;

                    }
                }
                //strSave = objBLInventory.InsertStackWODetails(lstSatckDetails, strSave);
                objResponse = objBLInventory.InsertStackWODetails(lstSatckDetails, strSave);
            }
            catch (Exception ex)
            {
                Log.Writelog(ex.Message, "WOODSUPPLY");
                Log.Writelog(ex.InnerException.ToString(), "WOODSUPPLY");

                //strSave = ex.Message.ToString();
                objResponseMessage.PcsNo = strPCSNo;

                objResponseMessage.Status = "Error";

                objResponseMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();

                objResponse.ResponseMessage = objResponseMessage;

            }
            //return strSave;
            return objResponse;
        }
        #endregion InsertStackWODetails

        #region InsertTransWODetails
        /// <summary>
        /// InsertTransWODetails
        /// </summary>
        /// <param name="transObj"></param>
        /// <returns></returns>
        public ResponseClass InsertTransWODetails(string transObj)
        {
            string RGEWOODLogFilePath = System.Configuration.ConfigurationManager.AppSettings["RGEWOODLogFilePath"];
            ResponseClass responseobject = new ResponseClass();
            Log.Writelog("In InsertTransWODetails of RGEService.svc.cs", "WOODSUPPLY");
            Log.Writelog("----------------------", "WOODSUPPLY");
            Log.Writelog(transObj, "WOODSUPPLY");
            Log.Writelog("----------------------", "WOODSUPPLY");
            string strPCSNO = string.Empty;

            // Uma - October 27 - 2015 commented the Readsetworkordertrans as serial no was blank

            // testclsWOTrans objResultTrans = new testclsWOTrans();
            BLInventory objBLInventory = new BLInventory();
            var objResultTrans = Json.Decode(transObj);
            //objResultTrans = ReadSetWorkOrderTrans(transObj);

            // uma Nov 27 2015 adding authentication token validation

            //TokenID

            clsAuthTokenValidation objAuth = new clsAuthTokenValidation();


            try
            {
                if (objResultTrans != null)
                {
                    objAuth = ValidateAuthToken(objResultTrans.DeviceID, objResultTrans.TokenID);
                    //isValidToken = ValidateAuthToken(objResultTrans.DeviceID, objResultTrans.TokenID);
                    Log.Writelog("Device ID-- " + objResultTrans.DeviceID.ToString(), "WOODSUPPLY");
                    Log.Writelog("isValidToken--" + objResultTrans.TokenID.ToString(), "WOODSUPPLY");
                }

                clsPCSTrans objTransDetails = new clsPCSTrans();

                if (objAuth.IsValidToken == true)
                {

                    if (objResultTrans != null)
                    {
                        objTransDetails.PCSNO = objResultTrans.PCSNO;
                        objTransDetails.SERIALNO = objResultTrans.SERIALNO;
                        objTransDetails.HAULCONT = objResultTrans.HAULCONT;
                        objTransDetails.REGISTRATION = objResultTrans.REGISTRATION;
                        objTransDetails.DRIVER = objResultTrans.DRIVER;
                        objTransDetails.TRANSDATE = objResultTrans.TRANSDATE;
                        objTransDetails.ROADNO = objResultTrans.ROADNO;
                        objTransDetails.LOADER = objResultTrans.LOADER;
                        objTransDetails.LOADCONT = objResultTrans.LOADCONT;
                        objTransDetails.LOADSTART = objResultTrans.LOADSTART;
                        objTransDetails.LOADSTOP = objResultTrans.LOADSTOP;
                        objTransDetails.SCALER = objResultTrans.SCALER;
                        objTransDetails.AGE = objResultTrans.AGE;
                        objTransDetails.DEPOTCODE = objResultTrans.DEPOTCODE;
                        objTransDetails.FAKTUR = objResultTrans.FAKTUR;
                        objTransDetails.TRIPTICKET = objResultTrans.TRIPTICKET;
                        objTransDetails.DEPOTBLOCKNO = objResultTrans.DEPOTBLOCKNO;
                        objTransDetails.MACHINELNO = objResultTrans.MACHINELNO;
                        objTransDetails.SOLIDVOL = objResultTrans.SOLIDVOL;
                        objTransDetails.PCSTYPE = objResultTrans.PCSTYPE;
                        objTransDetails.SOLIDADJ = objResultTrans.SOLIDADJ;
                        objTransDetails.CLOSED = objResultTrans.CLOSED;
                        objTransDetails.APOBLOCKLOC = objResultTrans.APOBLOCKLOC;
                        objTransDetails.DATEISSUE = objResultTrans.DATEISSUE;
                        objTransDetails.FELLCONT = objResultTrans.FELLCONT;
                        objTransDetails.BARGINGCONT = objResultTrans.BARGINGCONT;
                        objTransDetails.UNLOADCONT = objResultTrans.UNLOADCONT;
                        objTransDetails.UNLOADEQMTTOT = objResultTrans.UNLOADEQMTTOT;
                        objTransDetails.UNLOADSTART = objResultTrans.UNLOADSTART;
                        objTransDetails.UNLOADSTOP = objResultTrans.UNLOADSTOP;
                        objTransDetails.EXTRACTIONCONT = objResultTrans.EXTRACTIONCONT;
                        objTransDetails.EXTRACTIONEQMTTOT = objResultTrans.EXTRACTIONEQMTTOT;
                        objTransDetails.LOADEQMTTOT = objResultTrans.LOADEQMTTOT;
                        objTransDetails.DEBARKED = objResultTrans.DEBARKED;
                        objTransDetails.SVVSTACK = objResultTrans.SVVSTACK;
                        objTransDetails.SVVVOL = objResultTrans.SVVVOL;
                        objTransDetails.SVVTRUCKTYPE = objResultTrans.SVVTRUCKTYPE;
                        objTransDetails.SVVESTSTACKVOL = objResultTrans.SVVESTSTACKVOL;
                        objTransDetails.SVVESTVOL = objResultTrans.SVVESTVOL;
                        objTransDetails.EMPTYDEPART = objResultTrans.EMPTYDEPART;
                        objTransDetails.EMPTYARRIVAL = objResultTrans.EMPTYARRIVAL;
                        objTransDetails.EMPTYBARGELOADED = objResultTrans.EMPTYBARGELOADED;
                        objTransDetails.EMPTYBARGETYPE = objResultTrans.EMPTYBARGETYPE;
                        objTransDetails.EMPTYTOTVOL = objResultTrans.EMPTYTOTVOL;
                        objTransDetails.EMPTYBARGEEMPTY = objResultTrans.EMPTYBARGEEMPTY;
                        objTransDetails.EMPTYBARGEVOL = objResultTrans.EMPTYBARGEVOL;
                        objTransDetails.LOADEDDEPART = objResultTrans.LOADEDDEPART;
                        objTransDetails.LOADEDARRIVAL = objResultTrans.LOADEDARRIVAL;
                        objTransDetails.LOADEDNOOFBARGE = objResultTrans.LOADEDNOOFBARGE;
                        objTransDetails.LOADEDBARGETYPE = objResultTrans.LOADEDBARGETYPE;
                        objTransDetails.LOADEDTOTVOL = objResultTrans.LOADEDTOTVOL;
                        objTransDetails.LOADEDBARGEVOL = objResultTrans.LOADEDBARGEVOL;
                        objTransDetails.CANALNO = objResultTrans.CANALNO;
                        objTransDetails.TUGBOATOPR = objResultTrans.TUGBOATOPR;
                        objTransDetails.TUGBOATID = objResultTrans.TUGBOATID;
                        objTransDetails.NOTES = objResultTrans.NOTES;
                        objTransDetails.KMIN = objResultTrans.KMIN;
                        objTransDetails.KMOUT = objResultTrans.KMOUT;
                        objTransDetails.MACHINEUNO = objResultTrans.MACHINEUNO;
                        objTransDetails.CRTUSERID = objResultTrans.CRTUSERID;
                        objTransDetails.CRTDATE = objResultTrans.CRTDATE;
                        objTransDetails.MODUSERID = objResultTrans.MODUSERID;
                        objTransDetails.MODDATE = objResultTrans.MODDATE;
                        objTransDetails.NETWEIGHT = objResultTrans.NETWEIGHT;
                        objTransDetails.DESTINATION = objResultTrans.DESTINATION;
                        objTransDetails.PORTID = objResultTrans.PORTID;
                        objTransDetails.WOLOADING = objResultTrans.WOLOADING;
                        objTransDetails.WOUNLOAD = objResultTrans.WOUNLOAD;
                        objTransDetails.WOEXTRACTION = objResultTrans.WOEXTRACTION;
                        objTransDetails.WOFELLING = objResultTrans.WOFELLING;
                        objTransDetails.WOLANGSIR = objResultTrans.WOLANGSIR;
                        objTransDetails.WO = objResultTrans.WO;
                        objTransDetails.FELLDATE = objResultTrans.FELLDATE;
                        objTransDetails.LANGSIRCONT = objResultTrans.LANGSIRCONT;
                        objTransDetails.TICKETBARGING = objResultTrans.TICKETBARGING;
                        objTransDetails.FAKTURAIR = objResultTrans.FAKTURAIR;
                        objTransDetails.DIAMETERTYPE = objResultTrans.DIAMETERTYPE;
                        objTransDetails.MUATANKAYU = objResultTrans.MUATANKAYU;
                        objTransDetails.DICEKBY = objResultTrans.DICEKBY;
                        objTransDetails.TANGGALDATE = objResultTrans.TANGGALDATE;
                        objTransDetails.REMARK = objResultTrans.REMARK;
                        objTransDetails.ETLStatus = objResultTrans.ETLStatus;
                        objTransDetails.ProcessDate = objResultTrans.ProcessDate;
                        //Added By Smrithy -06-11-2015
                        objTransDetails.Loadingforeman = objResultTrans.loadingforeman;
                        objTransDetails.Checkedbydispatcher = objResultTrans.checkedbydispatcher;
                        objTransDetails.Loadingoperator = objResultTrans.loadingoperator;
                    }

                    ResponseClass responseobj = objBLInventory.InsertTransWODetails(objTransDetails);
                    responseobject = responseobj;
                } // end of  isValidToken == true

                else
                {
                    //if token is invalid
                    Log.WritePendinglog("<START>", "WOODSUPPLY");
                    Log.WritePendinglog(transObj, "WOODSUPPLY");
                    Log.WritePendinglog("<END>", "WOODSUPPLY");
                    responseobject.ResponseMessage.ErrorMessage = objAuth.Message;
                    responseobject.ResponseMessage.PcsNo = "";
                    responseobject.ResponseMessage.Status = "Fail";
                    responseobject.ResponseMessage.WO = "";


                }
                Log.Writelog("Response error message " + responseobject.ResponseMessage.ErrorMessage, "WOODSUPPLY");
                Log.Writelog("Response status message " + responseobject.ResponseMessage.Status, "WOODSUPPLY");
            }
            catch
            {
                Log.WritePendinglog("<START>", "WOODSUPPLY");
                Log.WritePendinglog(transObj, "WOODSUPPLY");
                Log.WritePendinglog("<END>", "WOODSUPPLY");
            }
            //Added for Pending logs
            if (responseobject.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "WOODSUPPLY");
                Log.WritePendinglog(transObj, "WOODSUPPLY");
                Log.WritePendinglog("<END>", "WOODSUPPLY");

            }
            return responseobject;
        }
        #endregion InsertTransWODetails

        #region Set LHP stock
        public string SetLhpStock(string sector, string depot, string license, string block, string species,
            int lhp, string createdDateTime, string user, string deviceId)
        {
            Log.Writelog("SetLhpStock = " + sector + " : " + depot + " : " + license + " : " + block + " : " + lhp + " : " + user + " : " + deviceId, "WOODSUPPLY");
            BLInventory objBLInventory = new BLInventory();
            string ret = objBLInventory.SetLhpStock(sector, depot, license, block, species,
            lhp, createdDateTime, user, deviceId);
            return ret;
        }
        #endregion Set LHP stock

        #region Set Enviromental Values
        public string SetEnviromentalValues(string sector, string depot, string weather,
            string road, int equipGood, int equipBad, string createdDateTime, string user, string deviceId)
        {
            Log.Writelog("SetEnviromentalValues = " + sector + " : " + depot + " : " + weather + " : " + road + " : " +
                equipGood + " : " + equipBad + " : " + user + " : " + deviceId, "WOODSUPPLY");
            BLInventory objBLInventory = new BLInventory();
            string ret = objBLInventory.SetEnviromentalValues(sector, depot, weather, road, equipGood,
            equipBad, createdDateTime, user, deviceId);
            return ret;
        }
        #endregion Set Enviromental Values

        public clsMainStock GetArriveNotArrivedata(string sector)
        {
            //Application : 

            clsMainStock objStock = new clsMainStock();
            List<clsStockLoading> lstStockData = new List<clsStockLoading>();
            BLInventory objBLInventory = new BLInventory();
            lstStockData = objBLInventory.GetArriveNotArrivedata(sector);
            objStock.GetStockDetails = lstStockData;
            return objStock;
        }

        public clsMainOneDayTripTicketData GetOneDayTripTicketData(string Sector)
        {
            //Application : Wood Supply
            clsMainOneDayTripTicketData objMain = new clsMainOneDayTripTicketData();
            List<clsLoadingOneDayTripTicketData> lstLoadingOneDayTripTicketData = new List<clsLoadingOneDayTripTicketData>();
            BLInventory objBLInventory = new BLInventory();
            lstLoadingOneDayTripTicketData = objBLInventory.GetOneDayTripTicketData(Sector);
            objMain.LoadingOneDayTripTicketData = lstLoadingOneDayTripTicketData;
            return objMain;
        }

        #endregion Wood Supply

        #region UAV
        #region GetEstateForSector
        /// <summary>
        /// GetEstateForSector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public clsUAVResponse GetEstateForSector(string sector, string deviceID, string tokenId)
        {
            // Application : UAV

            Log.Writelog("in GetEstateForSector " + sector, "UAV");
            clsMainUAVEstate objMainEstate = new clsMainUAVEstate();
            List<clsGetEstateForSector> lstEstates = new List<clsGetEstateForSector>();
            BLInventory objBLInventory = new BLInventory();
            clsUAVResponse objUAVResponse = new clsUAVResponse();
            clsUAVResponseMessage objUAvRespMessage = new clsUAVResponseMessage();
            try
            {
                //TokenID

                clsAuthTokenValidation obj = new clsAuthTokenValidation();
                obj = ValidateAuthToken(deviceID, tokenId);
                if (obj.IsValidToken == true)
                {
                    lstEstates = objBLInventory.GetEstateForSector(sector);
                    objMainEstate.Estates = lstEstates;
                    objUAvRespMessage.Status = "Success";
                    objUAvRespMessage.ErrorMessage = "";
                    objUAvRespMessage.Response = objMainEstate;
                    objUAVResponse.ResponseMessage = objUAvRespMessage;
                }
                else
                {
                    objUAvRespMessage.Status = "Error";
                    objUAvRespMessage.ErrorMessage = obj.Message;
                    objUAvRespMessage.Response = objMainEstate;
                    objUAVResponse.ResponseMessage = objUAvRespMessage;
                }
            }
            catch (Exception ex)
            {


                Log.Writelog("GetEstateForSector Method : " + ex.Message + "|", "UAV");

            }
            return objUAVResponse;
        }
        #endregion GetEstateForSector

        #region GetCompartmentNoForEstate

        public clsMainUAVCompNo GetCompartmentNoForEstate(string sector, string estate)
        {
            // Application : UAV

            clsMainUAVCompNo objMainCompNo = new clsMainUAVCompNo();
            List<clsGetCompartNoforEstate> lstCompNo = new List<clsGetCompartNoforEstate>();
            BLInventory objBLInventory = new BLInventory();
            lstCompNo = objBLInventory.GetCompartmentNoForEstate(sector, estate);
            objMainCompNo.Compartments = lstCompNo;
            return objMainCompNo;
        }
        #endregion GetCompartmentNoForEstate


        #region GetImagesForFilter
        /// <summary>
        /// GetImagesForFilter
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public clsMainFlightAlert GetImagesForFilter(string featid, string flightStartdate, string flightEnddate)
        {
            // Application : UAV
            DateTime startData = Convert.ToDateTime(flightStartdate);
            DateTime endData = Convert.ToDateTime(flightEnddate);

            clsMainFlightAlert objMain = new clsMainFlightAlert();


            List<clsUAVAlert> lstAlert = new List<clsUAVAlert>();
            BLInventory objBLInventory = new BLInventory();
            lstAlert = objBLInventory.GetUAVAlertData(featid, startData, endData);
            objMain.AlertsList = lstAlert;

            List<clsUAVAlertOthers> lstAlertOthers = new List<clsUAVAlertOthers>();
            lstAlertOthers = objBLInventory.GetUAVAlertOthersData(featid);
            objMain.AlertsListOthers = lstAlertOthers;

            List<clsUAVFlight> lstFlight = new List<clsUAVFlight>();
            List<clsResponseUAVFlight> lstResponseFlight = new List<clsResponseUAVFlight>();

            lstFlight = objBLInventory.GetImagesForFlightFilter(featid, startData, endData);

            foreach (var s in lstFlight)
            {
                clsResponseUAVFlight ResponseFlight = new clsResponseUAVFlight();
                ResponseFlight.FlightID = s.FlightID;
                ResponseFlight.Flightdate = s.Flightdate;
                ResponseFlight.FEATID = s.FEATID;
                ResponseFlight.Species = s.Species;
                ResponseFlight.TreeCount = s.TreeCount;
                ResponseFlight.AreaSize = s.AreaSize;
                ResponseFlight.Stocking = s.Stocking;
                ResponseFlight.ProcessedImagePath = s.ProcessedImagePath;
                ResponseFlight.KMLFilePath = s.KMLFilePath;
                ResponseFlight.ExecID = s.ExecID;
                ResponseFlight.Starttime = s.Starttime.ToString();
                ResponseFlight.Endtime = s.Endtime.ToString();
                ResponseFlight.ESTDATE = s.ESTDATE;
                ResponseFlight.Age = s.Age;
                ResponseFlight.Contractor = s.Contractor;
                ResponseFlight.Assisten = s.Assisten;
                ResponseFlight.SEEDLOTID = s.SEEDLOTID;
                ResponseFlight.SPACING = s.SPACING;
                ResponseFlight.EastCord = s.EastCord;
                ResponseFlight.WestCord = s.WestCord;
                ResponseFlight.NorthCord = s.NorthCord;
                ResponseFlight.SouthCord = s.SouthCord;
                ResponseFlight.ImageType = s.ImageType;
                ResponseFlight.LowTreshold = s.LowTreshold;
                ResponseFlight.HighTreshold = s.HighTreshold;

                lstResponseFlight.Add(ResponseFlight);
            }
            objMain.FlightData = lstResponseFlight;

            List<clsUAVDensityColorIndex> lstDensity = new List<clsUAVDensityColorIndex>();
            lstDensity = objBLInventory.GetUAVDensityRefData(featid, startData, endData);
            objMain.UAVReferenceData = lstDensity;

            return objMain;
        }


        #endregion GetImagesForFilter

        #region GetUAVReferenceData
        /// <summary>
        /// GetUAVReferenceData
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="estate"></param>
        /// <returns></returns>
        public clsMainUAVReferenceData GetUAVReferenceData()
        {
            // Application : UAV

            clsMainUAVReferenceData objMainReference = new clsMainUAVReferenceData();
            List<clsUAVAlertColorIndex> lstReference = new List<clsUAVAlertColorIndex>();
            BLInventory objBLInventory = new BLInventory();
            lstReference = objBLInventory.GetUAVReferenceData();
            objMainReference.ReferenceData = lstReference;
            return objMainReference;
        }
        #endregion GetUAVReferenceData

        public ResponseClass SaveCloseAlert(string transObj)
        {
            ResponseClass responseobject = new ResponseClass();
            BLInventory objBLInserDBDetails = new BLInventory();
            try
            {
                Log.Writelog("<------------------- Save details to the database Started ------------------->", "UAV");
                Log.Writelog("Step - 1: Decode JSON Format Started. Current JSON - " + transObj, "UAV");
                var objResultTrans = Json.Decode(transObj);
                Log.Writelog("Step - 1.1: Decode JSON Format Completed. Current JSON - " + objResultTrans, "UAV");
                clsCloseAlert objTransDetails = new clsCloseAlert();

                objTransDetails.Alert_type = objResultTrans.AlertType;
                objTransDetails.Featid = objResultTrans.Featid;
                objTransDetails.Start_date = objResultTrans.Start_Date;
                objTransDetails.Gps_lat = objResultTrans.GPS_Lat;
                objTransDetails.Gps_lon = objResultTrans.GPS_Lon;
                objTransDetails.Exec_id = objResultTrans.Exec_ID;
                objTransDetails.Remark = objResultTrans.Remark;
                objTransDetails.ImageName = objResultTrans.ImageName;

                objTransDetails.Crt_userid = objResultTrans.Crt_userid;
                objTransDetails.Mod_userid = objResultTrans.Mod_userid;
                objTransDetails.DeviceID = objResultTrans.DeviceId;
                objTransDetails.Status = objResultTrans.Status;

                Log.Writelog("Step - 2: JSON Format Details", "UAV");

                Log.Writelog("Step - 3: Insert Details to the database Started", "UAV");
                ResponseClass responseobj = objBLInserDBDetails.CloseAlert(objTransDetails);
                Log.Writelog("Step - 4: Insert Details to the database Finished. Status - " + responseobj.ResponseMessage.Status, "UAV");
                Log.Writelog("<------------------- Save details to the database Finished for (" + objResultTrans.UserName + ") ------------------->", "UAV");
                responseobject = responseobj;
            }
            catch (Exception ex)
            {
                Log.Writelog("Error " + ex.Message, "UAV");
            }
            return responseobject;
        }
        #endregion UAV

        #region PQA
        //add sigit
        #region GetTimeline
        public clsMainGetTimeline GetTimeline(string wo)
        {

            Log.Writelog("wo_number : " + wo);

            clsMainGetTimeline obMain = new clsMainGetTimeline();
            List<clsGetTimeline> lstGetTimeline = new List<clsGetTimeline>();
            BLInventory objBLInventory = new BLInventory();
            lstGetTimeline = objBLInventory.GetTimelineData(wo);
            obMain.GetTimelineList = lstGetTimeline;
            Log.Writelog("Wo_number: " + wo);
            return obMain;
        }
        #endregion GetTimeline

        #region GetPQAWorkOrders
        /// <summary>
        /// to get the PQA Work order
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="dtReqStartDate"></param>
        /// <param name="dtReqEndDate"></param>
        /// <returns></returns>
        public clsPQAResponse GetPQAWorkOrders(string sector, string dtReqStartDate, string dtReqEndDate, string deviceID, string tokenId)
        {
            // Application : PQA

            clsMainPQAWO objMainPQA = new clsMainPQAWO();
            List<clsPQAGetWorkOrders> lstPQAWO = new List<clsPQAGetWorkOrders>();
            BLInventory objBLInventory = new BLInventory();
            clsPQAResponse objPQAResponse = new clsPQAResponse();
            clsPQAResponseMessage objPQARespMessage = new clsPQAResponseMessage();
            //TokenID           
            clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
            objAuth = ValidateAuthToken(deviceID, tokenId);

            if (objAuth.IsValidToken == true)
            {   //#Guaz - capture the parameters used to query the PQA WO.
                Log.Writelog(deviceID, "GetPQAWorkOrders - Sec[" + sector + "] " +
                "ReqSD[" + Convert.ToDateTime(dtReqStartDate) + "] " +
                "ReqED[" + Convert.ToDateTime(dtReqEndDate) + "]", "PQA");

                lstPQAWO = objBLInventory.GetPQAWorkOrders(sector, Convert.ToDateTime(dtReqStartDate), Convert.ToDateTime(dtReqEndDate), deviceID);
                objMainPQA.GetPQAWorkOrders = lstPQAWO;

                objPQARespMessage.Status = "Success";
                objPQARespMessage.ErrorMessage = "";
                objPQARespMessage.Response = objMainPQA;
                objPQAResponse.ResponseMessage = objPQARespMessage;

                //#Guaz - summarize the return results
                Log.Writelog(deviceID, "GetPQAWorkOrders - Total WO: " + lstPQAWO.Count, "PQA");

                //#Guaz - meaningless information.
                /*Log.Writelog("printing the getpqawork orders.", "PQA");
                for (int j = 0; j < lstPQAWO.Count; j++)
                {
                    Log.Writelog(" j value is " + j.ToString() + " " + lstPQAWO[j].DateOfIssue.ToString(), "PQA");
                } */
            }
            else
            {
                Log.Writelog(deviceID, "GetPQAWorkOrders - IsValidToken: False", "PQA");
                objPQARespMessage.Status = "Error";
                objPQARespMessage.ErrorMessage = objAuth.Message;
                objPQARespMessage.Response = objMainPQA;
                objPQAResponse.ResponseMessage = objPQARespMessage;
            }
            return objPQAResponse;
        }
        #endregion GetPQAWorkOrders

        #region SyncPQAData
        public PQAResponseClass SyncPQAData(PQARequest info)
        {
            Log.WriteSynclog(JsonConvert.SerializeObject(info,
                new JsonSerializerSettings() { DateFormatHandling = DateFormatHandling.MicrosoftDateFormat }),
                "PQA", info.DeviceID);

            clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
            objAuth = ValidateAuthToken(info.DeviceID, info.TokenID);
            Log.Writelog(info.DeviceID, "isValidToken--" + objAuth.IsValidToken.ToString(), "PQA");
            if (objAuth.IsValidToken == true)
            {
                BLInventory objBLInventory = new BLInventory();
                return objBLInventory.SyncPQAData(info.Detail);
            }
            else
            {
                return new PQAResponseClass()
                {
                    ResponseMessage = new PQAResponseMessage()
                    {
                        WONUMBER = string.Empty,
                        ErrorMessage = objAuth.Message,
                        Status = string.Empty
                    }
                };

            }
        }
        #endregion

        #region InsertPQADetails
        /// <summary>
        /// InsertPQADetails
        /// </summary>
        /// <param name="SyncData"></param>w
        /// <returns></returns>
        public PQAResponseClass InsertPQADetails(string SyncData)
        {
            Log.Writelog("InsertPQADetails " + SyncData + "|", "PQA");
            BLInventory objBLInventory = new BLInventory();
            PQAResponseClass objResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();
            clsQARegister objQARegdata = new clsQARegister();
            clsPQACompartmentData objComp = new clsPQACompartmentData();
            List<clsScores> lstScores = new List<clsScores>();

            var varPQADet = Json.Decode(SyncData);

            string strSave = string.Empty;
            string WONUMBER = string.Empty;
            //TokenID
            string deviceID = string.Empty;
            string tokenId = string.Empty;

            try
            {
                deviceID = varPQADet.Compartment.DeviceID;
                tokenId = varPQADet.Compartment.TokenID;
                Log.Writelog(deviceID.ToString(), "InsertPQADetails", "PQA");

                clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
                objAuth = ValidateAuthToken(deviceID, tokenId);

                //Log.Writelog("InsertPQADetails -- isValidToken--" + objAuth.IsValidToken.ToString(), "PQA");
                if (objAuth.IsValidToken == true)
                {
                    if (varPQADet != null)
                    {
                        WONUMBER = varPQADet.Compartment.WO_NUMBER;

                        objComp.FeatID = varPQADet.Compartment.FeatID;
                        objComp.PlantationSuperindent = varPQADet.Compartment.PlantationSuperintendent;
                        objComp.Fertilizer = varPQADet.Compartment.Fertilizer;
                        objComp.OperationType = varPQADet.Compartment.OperationType;
                        objComp.WONUMBER = varPQADet.Compartment.WO_NUMBER;
                        objComp.CRTUSERID = varPQADet.Compartment.CRTUSERID;
                        objComp.CRTDATE = varPQADet.Compartment.CRTDATE;
                        objComp.MODUSERID = varPQADet.Compartment.MODUSERID;
                        objComp.TargetSpacing = Convert.ToInt32(varPQADet.Compartment.TARGETSPACING);
                        objComp.QAPercentage = Convert.ToDecimal(varPQADet.Compartment.QA_PERCENTAGE);
                        objComp.AssessorCode = varPQADet.Compartment.ASSESSORCODE;
                        objComp.SAPID = varPQADet.Compartment.SAPID;
                        objComp.TotalPlotNo = varPQADet.TotalPlotNo;
                        objComp.CompSlno = varPQADet.CompSlno;
                        objComp.QADATE = varPQADet.Compartment.QADATE;
                        objQARegdata.TotalScore = varPQADet.Compartment.TotalScore;
                        objQARegdata.WOSTATUS = varPQADet.Compartment.WO_STATUS;

                        if (varPQADet.Scores != null)
                        {
                            int scoreCount = varPQADet.Scores.Length;
                            if (scoreCount > 0)
                            {
                                for (int i = 0; i < scoreCount; i++)
                                {
                                    clsScores objScores = new clsScores();
                                    objScores.Parameter = varPQADet.Scores[i].Parameter;
                                    objScores.Score = varPQADet.Scores[i].Score;
                                    lstScores.Add(objScores);
                                }
                            }
                        }

                        //Log.Writelog("In RGE service... calling objBLInventory.InsertPQADetails", "PQA");
                        Log.Writelog(deviceID.ToString(), "Enter to objBLInventory.InsertPQADetails", "PQA");
                        objResponse = objBLInventory.InsertPQADetails(objComp, objQARegdata, lstScores, deviceID.ToString());
                        Log.Writelog(deviceID.ToString(), "Out from objBLInventory.InsertPQADetails", "PQA");

                        objComp = null;
                        objQARegdata = null;
                        lstScores = null;
                    }

                }
                else
                {
                    Log.WritePendinglog("<START>", "PQA");
                    Log.WritePendinglog(SyncData, "PQA");
                    Log.WritePendinglog("<END>", "PQA");
                    objPQARespMessage.Status = "Error";
                    objPQARespMessage.WONUMBER = "";
                    objPQARespMessage.ErrorMessage = objAuth.Message;
                    objResponse.ResponseMessage = objPQARespMessage;
                    Log.Writelog(deviceID.ToString(), "isValidToken: False", "PQA");
                }
            }
            catch (Exception ex)
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");

                Log.Writelog(deviceID.ToString(), ex.Message, "PQA");
                Log.Writelog(deviceID.ToString(), ex.InnerException.ToString(), "PQA");
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = WONUMBER;
                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                objResponse.ResponseMessage = objPQARespMessage;
                Log.Writelog(deviceID.ToString(), "Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            }
            //Added for Pending logs
            if (objResponse.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");
            }

            // Log.Writelog("Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            Log.Writelog(deviceID.ToString(), "Response status message " + objResponse.ResponseMessage.Status, "PQA");
            return objResponse;
        }
        #endregion InsertPQADetails

        #region InsertPQAStocking
        /// <summary>
        /// InsertPQAStocking
        /// </summary>
        /// <param name="SyncData"></param>w
        /// <returns></returns>
        public PQAResponseClass InsertPQAStocking(string SyncData)
        {
            Log.Writelog("InsertPQAStocking " + SyncData + "|", "PQA");
            BLInventory objBLInventory = new BLInventory();
            PQAResponseClass objResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();
            clsPQAStockingData objStockingDetails = new clsPQAStockingData();
            List<clsPQAStockingData> lstPlotStocking = new List<clsPQAStockingData>();

            var varPQAStockDet = Json.Decode(SyncData);

            string strSave = string.Empty;
            string WONUMBER = string.Empty;
            //TokenID
            string _compSlNo = string.Empty;
            string tokenId = string.Empty;

            try
            {
                Log.Writelog(_compSlNo.ToString(), "InsertPQAStocking", "PQA");
                if (varPQAStockDet != null)
                {
                    _compSlNo = varPQAStockDet.CompSlno;
                }
                if (varPQAStockDet.Stocking != null)
                {
                    int stockingCount = varPQAStockDet.Stocking.Length;
                    if (stockingCount > 0)
                    {
                        for (int i = 0; i < stockingCount; i++)
                        {
                            clsPQAStockingData objPlotStocking = new clsPQAStockingData();
                            //objPlotStocking.WONumber = varPQAStockDet.Stocking[i].WorkOrderNo;
                            //objPlotStocking.Compartment = varPQAStockDet.Stocking[i].CompartmentNo;
                            //objPlotStocking.Estate = varPQAStockDet.Stocking[i].Estate;
                            //objPlotStocking.CompSlNo = varPQAStockDet.CompSlno;
                            objPlotStocking.PlotStockingNo = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotStockingNo);
                            objPlotStocking.PlotNo = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotNo);
                            objPlotStocking.TreePlotNo = Convert.ToInt32(varPQAStockDet.Stocking[i].TreePlotNo);
                            objPlotStocking.PlotQdr = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotQDR);
                            objPlotStocking.PlotLine = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotLine);
                            objPlotStocking.PlotL = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotL);
                            objPlotStocking.PlotDA = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotDA);
                            objPlotStocking.PlotDU = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotDU);
                            objPlotStocking.PlotVA = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotVA);
                            objPlotStocking.PlotVU = Convert.ToInt32(varPQAStockDet.Stocking[i].PlotVU);
                            lstPlotStocking.Add(objPlotStocking);
                        }
                    }
                }

                //Log.Writelog("In RGE service... calling objBLInventory.InsertPQAStocking", "PQA");
                Log.Writelog(_compSlNo.ToString(), "Enter to objBLInventory.InsertPQAStocking", "PQA");
                objResponse = objBLInventory.InsertPQAStocking(lstPlotStocking, _compSlNo.ToString());
                Log.Writelog(_compSlNo.ToString(), "Out from objBLInventory.InsertPQAStocking", "PQA");

                objStockingDetails = null;
                lstPlotStocking = null;
            }
            catch (Exception ex)
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");

                Log.Writelog(_compSlNo.ToString(), ex.Message, "PQA");
                Log.Writelog(_compSlNo.ToString(), ex.InnerException.ToString(), "PQA");
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = WONUMBER;
                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                objResponse.ResponseMessage = objPQARespMessage;
                Log.Writelog(_compSlNo.ToString(), "Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            }
            //Added for Pending logs
            if (objResponse.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");
            }

            // Log.Writelog("Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            Log.Writelog(_compSlNo.ToString(), "Response status message " + objResponse.ResponseMessage.Status, "PQA");
            return objResponse;
        }
        #endregion InsertPQADetails

        #region InsertPQAStockingSummary
        /// <summary>
        /// InsertPQAStocking
        /// </summary>
        /// <param name="SyncData"></param>w
        /// <returns></returns>
        public PQAResponseClass InsertPQAStockingSummary(string SyncData)
        {
            Log.Writelog("InsertPQAStockingSummary " + SyncData + "|", "PQA");
            BLInventory objBLInventory = new BLInventory();
            PQAResponseClass objResponse = new PQAResponseClass();
            PQAResponseMessage objPQARespMessage = new PQAResponseMessage();
            clsPQAStockingSummaryData objStockingSummary = new clsPQAStockingSummaryData();
            List<clsPQAStockingSummaryData> lstPlotStockingSummary = new List<clsPQAStockingSummaryData>();

            var varPQAStockSumm = Json.Decode(SyncData);

            string strSave = string.Empty;
            string WONUMBER = string.Empty;
            //TokenID
            string _compSlNo = string.Empty;
            string tokenId = string.Empty;

            try
            {
                Log.Writelog(_compSlNo.ToString(), "InsertPQAStockingSummary", "PQA");
                if (varPQAStockSumm != null)
                {
                    _compSlNo = varPQAStockSumm.CompSlno;
                }
                if (varPQAStockSumm.StockingSummary != null)
                {
                    int stockingSummaryCount = varPQAStockSumm.StockingSummary.Length;
                    if (stockingSummaryCount > 0)
                    {
                        for (int i = 0; i < stockingSummaryCount; i++)
                        {
                            clsPQAStockingSummaryData objPlotStockingSummary = new clsPQAStockingSummaryData();
                            //objPlotStockingSummary.workOrderNo = varPQAStockSumm.StockingSummary[i].WorkOrderNo;
                            //objPlotStockingSummary.compartmentNo = varPQAStockSumm.StockingSummary[i].CompartmentNo;
                            //objPlotStockingSummary.estate = varPQAStockSumm.StockingSummary[i].Estate;
                            //objPlotStockingSummary.CompSlNo = varPQAStockSumm.CompSlno;
                            objPlotStockingSummary.totalPlotPQA = Convert.ToInt32(varPQAStockSumm.StockingSummary[i].PlotPQA);
                            objPlotStockingSummary.totalPlotPQAStocking = Convert.ToInt32(varPQAStockSumm.StockingSummary[i].PQAStocking);
                            objPlotStockingSummary.plotSize = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].PlotSize);
                            objPlotStockingSummary.spacing = Convert.ToInt32(varPQAStockSumm.StockingSummary[i].Spacing);
                            objPlotStockingSummary.averageLive = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].AverageLive);
                            objPlotStockingSummary.averageDA = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].AverageDA);
                            objPlotStockingSummary.averageDU = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].AverageDU);
                            objPlotStockingSummary.averageVA = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].AverageVA);
                            objPlotStockingSummary.averageVU = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].AverageVU);
                            objPlotStockingSummary.daHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].DaHa);
                            objPlotStockingSummary.duHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].DuHa);
                            objPlotStockingSummary.deadPerHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].DeadPerHa);
                            objPlotStockingSummary.vaHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].VaHa);
                            objPlotStockingSummary.vuHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].VuHa);
                            objPlotStockingSummary.vacantPerHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].VacantPerHa);
                            objPlotStockingSummary.initialPlanting = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].InitialPlanting);
                            objPlotStockingSummary.ipHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].IpHa);
                            objPlotStockingSummary.lHa = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].LHa);
                            objPlotStockingSummary.initialStocking = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].InitialStocking);
                            objPlotStockingSummary.liveStocking = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].LiveStocking);
                            objPlotStockingSummary.kerapatanTitikTanam = Convert.ToDecimal(varPQAStockSumm.StockingSummary[i].KerapatanTitikTanam);

                            lstPlotStockingSummary.Add(objPlotStockingSummary);
                        }
                    }
                }

                //Log.Writelog("In RGE service... calling objBLInventory.InsertPQAStockingSummary", "PQA");
                Log.Writelog(_compSlNo.ToString(), "Enter to objBLInventory.InsertPQAStockingSummary", "PQA");
                objResponse = objBLInventory.InsertPQAStockingSummary(lstPlotStockingSummary, _compSlNo.ToString());
                Log.Writelog(_compSlNo.ToString(), "Out from objBLInventory.InsertPQAStockingSummary", "PQA");

                objStockingSummary = null;
                lstPlotStockingSummary = null;
            }
            catch (Exception ex)
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");

                Log.Writelog(_compSlNo.ToString(), ex.Message, "PQA");
                Log.Writelog(_compSlNo.ToString(), ex.InnerException.ToString(), "PQA");
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = WONUMBER;
                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                objResponse.ResponseMessage = objPQARespMessage;
                Log.Writelog(_compSlNo.ToString(), "Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            }
            //Added for Pending logs
            if (objResponse.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");
            }

            // Log.Writelog("Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            Log.Writelog(_compSlNo.ToString(), "Response status message " + objResponse.ResponseMessage.Status, "PQA");
            return objResponse;
        }
        #endregion InsertPQADetails

        public PQAPlotResponseClass InsertPQAPlotDetails(string SyncData)
        {
            Log.Writelog(SyncData, "PQA");
            BLInventory objBLInventory = new BLInventory();
            PQAPlotResponseClass objResponse = new PQAPlotResponseClass();
            PQAPlotResponseMessage objPQARespMessage = new PQAPlotResponseMessage();

            List<clsPlotData> lstPlotData = new List<clsPlotData>();
            List<clsPlotGPS> lstPlotGPS = new List<clsPlotGPS>();
            List<clsPlotHoleSize> lstHoleSize = new List<clsPlotHoleSize>();
            List<clsPlotSpace> lstPlotSpace = new List<clsPlotSpace>();
            List<clsTreeQADetails> lstTreeQA = new List<clsTreeQADetails>();

            var varPQADet = Json.Decode(SyncData);

            string strSave = string.Empty;
            string WONUMBER = string.Empty;
            //TokenID
            string deviceID = string.Empty;
            string tokenId = string.Empty;
            string compSlNo = string.Empty;
            try
            {
                deviceID = varPQADet.DeviceID;
                tokenId = varPQADet.TokenID;
                compSlNo = varPQADet.CompSlno;
                Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails", "PQA");
                clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
                objAuth = ValidateAuthToken(deviceID, tokenId);
                //Log.Writelog("Insert PQA PlotsDetails -- isValidToken--" + objAuth.IsValidToken.ToString(), "PQA");

                if (objAuth.IsValidToken == true || compSlNo != string.Empty)
                {
                    if (varPQADet != null)
                    {
                        clsPlotData objPlotData = new clsPlotData();

                        objPlotData.PLOTNO = varPQADet.Plot.PlotNo;
                        objPlotData.REMARKS = varPQADet.Plot.REMARKS;
                        objPlotData.PDCRTUSERID = varPQADet.Plot.PCreatedBy;
                        objPlotData.PDCRTDATE = varPQADet.Plot.PCreatedDate;
                        objPlotData.PDMODUSERID = varPQADet.Plot.PModifiedBy;
                        objPlotData.PDMODDATE = varPQADet.Plot.PModifiedDate;
                        lstPlotData.Add(objPlotData);

                        if (varPQADet.Plot.PlotSpacing != null)
                        {
                            int plotSpaceCount = varPQADet.Plot.PlotSpacing.Length;
                            if (plotSpaceCount > 0)
                            {
                                for (int k = 0; k < plotSpaceCount; k++)
                                {
                                    clsPlotSpace objPlotSpace = new clsPlotSpace();

                                    objPlotSpace.PlotNo = varPQADet.Plot.PlotNo;
                                    objPlotSpace.TreeRowNo = varPQADet.Plot.PlotSpacing[k].TreeRowNo;
                                    objPlotSpace.BRI = varPQADet.Plot.PlotSpacing[k].BRI;
                                    objPlotSpace.IRI = varPQADet.Plot.PlotSpacing[k].IRI;

                                    lstPlotSpace.Add(objPlotSpace);
                                    objPlotSpace = null;
                                }
                            }
                        }

                        if (varPQADet.Plot.PlotGPS != null)
                        {
                            int gpsCount = varPQADet.Plot.PlotGPS.Length;
                            if (gpsCount > 0)
                            {
                                for (int l = 0; l < gpsCount; l++)
                                {
                                    clsPlotGPS objPlotGPS = new clsPlotGPS();

                                    objPlotGPS.PlotNo = varPQADet.Plot.PlotNo;
                                    objPlotGPS.Treerowno = varPQADet.Plot.PlotGPS[l].TreeRowNo;
                                    objPlotGPS.GPSLat = (varPQADet.Plot.PlotGPS[l] != null) ? ToLongString(varPQADet.Plot.PlotGPS[l].Lat) : varPQADet.Plot.PlotGPS[l].Lat;
                                    objPlotGPS.GPSLONG = (varPQADet.Plot.PlotGPS[l] != null) ? ToLongString(varPQADet.Plot.PlotGPS[l].Long) : varPQADet.Plot.PlotGPS[l].Long;

                                    lstPlotGPS.Add(objPlotGPS);
                                    objPlotGPS = null;
                                }
                            }
                        }

                        if (varPQADet.Plot.HoleSize != null)
                        {
                            int holeCount = varPQADet.Plot.HoleSize.Length;
                            if (holeCount > 0)
                            {
                                for (int m = 0; m < holeCount; m++)
                                {
                                    clsPlotHoleSize objPlotHoleSize = new clsPlotHoleSize();

                                    objPlotHoleSize.PlotNo = varPQADet.Plot.PlotNo;
                                    objPlotHoleSize.TreeRowNo = varPQADet.Plot.HoleSize[m].TreeRowNo;
                                    objPlotHoleSize.TreeNo1 = varPQADet.Plot.HoleSize[m].TreeNo1;
                                    objPlotHoleSize.TreeNo2 = varPQADet.Plot.HoleSize[m].TreeNo2;
                                    objPlotHoleSize.TreeNo3 = varPQADet.Plot.HoleSize[m].TreeNo3;
                                    objPlotHoleSize.TreeNo4 = varPQADet.Plot.HoleSize[m].TreeNo4;
                                    objPlotHoleSize.TreeNo5 = varPQADet.Plot.HoleSize[m].TreeNo5;

                                    lstHoleSize.Add(objPlotHoleSize);
                                    objPlotHoleSize = null;
                                }
                            }
                        }

                        int treeCount = varPQADet.Plot.Trees.Length;
                        if (treeCount > 0)
                        {
                            for (int n = 0; n < treeCount; n++)
                            {
                                clsTreeQADetails objTree = new clsTreeQADetails();

                                objTree.PlotNo = varPQADet.Plot.PlotNo;
                                objTree.TreeRowno = varPQADet.Plot.Trees[n].TreeRowNo;
                                objTree.TreeNo = varPQADet.Plot.Trees[n].TreeNo;
                                objTree.PropertyList = varPQADet.Plot.Trees[n].PropertyList;
                                objTree.SeedLotCodeList = varPQADet.Plot.Trees[n].SeedLotCodeList;
                                try
                                {
                                    objTree.ImageNameList = varPQADet.Plot.Trees[n].ImageNameList;

                                    objTree.ImageDescription = varPQADet.Plot.Trees[n].ImageDescription;
                                }
                                catch (Exception ex)
                                {
                                    Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - " + ex.Message, "PQA");
                                }

                                lstTreeQA.Add(objTree);
                                objTree = null;
                            }
                        }


                        //Log.Writelog("In RGE service... calling objBLInventory.InsertPQAPlotDetails", "PQA");
                        Log.Writelog(deviceID.ToString(), "Enter to objBLInventory.InsertPQAPlotDetails", "PQA");
                        objResponse = objBLInventory.InsertPQAPlotDetails(lstPlotData, lstPlotGPS, lstHoleSize, lstPlotSpace, lstTreeQA, compSlNo, deviceID);
                        Log.Writelog(deviceID.ToString(), "Out from objBLInventory.InsertPQAPlotDetails", "PQA");
                        Log.Writelog(deviceID.ToString(), objResponse.ResponseMessage.ToString(), "PQA");
                        lstPlotData = null;
                        lstPlotGPS = null;
                        lstHoleSize = null;
                        lstPlotSpace = null;
                        lstTreeQA = null;

                    }
                }
                else
                {
                    // if token is invalid 
                    Log.WritePendinglog("<START>", "PQA");
                    Log.WritePendinglog(SyncData, "PQA");
                    Log.WritePendinglog("<END>", "PQA");
                    if (objAuth.IsValidToken == false)
                    {
                        objPQARespMessage.Status = "Error";
                        objPQARespMessage.WONUMBER = "";
                        objPQARespMessage.ErrorMessage = objAuth.Message;
                        objResponse.ResponseMessage = objPQARespMessage;
                        Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - isValidToken: False", "PQA");
                    }
                    else
                    {
                        objPQARespMessage.Status = "Error";
                        objPQARespMessage.WONUMBER = WONUMBER;
                        objPQARespMessage.ErrorMessage = "The Compartment Serial Number is empty";
                        objResponse.ResponseMessage = objPQARespMessage;
                        Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - " + objPQARespMessage.ErrorMessage, "PQA");
                    }


                }
            }
            catch (Exception ex)
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");

                Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - " + ex.Message, "PQA");
                Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - " + ex.InnerException.ToString(), "PQA");
                objPQARespMessage.Status = "Error";
                objPQARespMessage.WONUMBER = WONUMBER;
                objPQARespMessage.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                objResponse.ResponseMessage = objPQARespMessage;
                Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
                Log.Writelog(deviceID.ToString(), "InsertPQAPlotDetails - Response status message " + objResponse.ResponseMessage.Status, "PQA");
            }
            //Added for Pending logs
            if (objResponse.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "PQA");
                Log.WritePendinglog(SyncData, "PQA");
                Log.WritePendinglog("<END>", "PQA");

            }

            // Log.Writelog("Response error message " + objResponse.ResponseMessage.ErrorMessage, "PQA");
            // Log.Writelog("Response status message " + objResponse.ResponseMessage.Status, "PQA");
            return objResponse;
        }

        public List<KeyValuePair<string, string>> GetConfigurations()
        {
            List<KeyValuePair<string, string>> configs = new List<KeyValuePair<string, string>>();
            try
            {
                BLInventory objBLInventory = new BLInventory();
                configs = objBLInventory.GetConfigurations();
            }
            catch { }
            return configs;
        }

        #endregion PQA

        #region HQA
        #region GetHQAWorkOrders
        /// <summary>
        /// GetHQAWorkOrders
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="dtReqStartDate"></param>
        /// <param name="dtReqEndDate"></param>
        /// <returns></returns>
        public clsHQAResponse GetHQAWorkOrders(string sector, string dtReqStartDate, string dtReqEndDate, string deviceID, string tokenId)
        {
            clsMainHQAWO objMainHQA = new clsMainHQAWO();
            List<clsHQAGetWorkOrders> lstHQAWO = new List<clsHQAGetWorkOrders>();
            BLInventory objBLInventory = new BLInventory();
            clsHQAResponse objHQAResponse = new clsHQAResponse();
            clsHQAResponseMessage objHQARespMessage = new clsHQAResponseMessage();
            //TokenID           
            clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
            objAuth = ValidateAuthToken(deviceID, tokenId);

            if (objAuth.IsValidToken == true)
            {   //#Guaz - capture the parameters used to query the PQA WO.
                Log.Writelog(deviceID, "GetHQAWorkOrders - Sec[" + sector + "] " +
                "ReqSD[" + Convert.ToDateTime(dtReqStartDate) + "] " +
                "ReqED[" + Convert.ToDateTime(dtReqEndDate) + "]|", "HQA");

                lstHQAWO = objBLInventory.GetHQAWorkOrders(sector, Convert.ToDateTime(dtReqStartDate), Convert.ToDateTime(dtReqEndDate), deviceID);
                objMainHQA.GetHQAWorkOrders = lstHQAWO;

                objHQARespMessage.Status = "Success";
                objHQARespMessage.ErrorMessage = "";
                objHQARespMessage.Response = objMainHQA;
                objHQAResponse.ResponseMessage = objHQARespMessage;

                //#Guaz - summarize the return results
                Log.Writelog(deviceID, "GetHQAWorkOrders - Total WO: " + lstHQAWO.Count, "HQA");
            }
            else
            {
                Log.Writelog(deviceID, "GetHQAWorkOrders - IsValidToken: False", "HQA");
                objHQARespMessage.Status = "Error";
                objHQARespMessage.ErrorMessage = objAuth.Message;
                objHQARespMessage.Response = objMainHQA;
                objHQAResponse.ResponseMessage = objHQARespMessage;
            }
            return objHQAResponse;
        }
        #endregion GetHQAWorkOrders

        //Smrithy Added
        #region GetPQATeamDetails
        /// <summary>
        /// GetHQATeamDetails
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public clsMainHQATeam GetPQATeamDetails(string sector, string deviceID)
        {
            //#Guaz: Function name is GETHQA but the actual function is to query the PQA Team Details."          
            Log.Writelog(deviceID, "GetPQATeamDetails - Sec: " + sector, "PQA");

            clsMainHQATeam obMain = new clsMainHQATeam();
            List<clsQATeam> lstHQATeam = new List<clsQATeam>();
            BLInventory objBLInventory = new BLInventory();
            lstHQATeam = objBLInventory.GetPQATeamDetails(sector);
            obMain.HQATeamCodeList = lstHQATeam;
            Log.Writelog(deviceID, "GetPQATeamDetails - Total record: " + lstHQATeam.Count, "PQA");
            return obMain;
        }
        #endregion GetPQATeamDetails

        #region InsertHQADetails
        /// <summary>
        /// InsertPQADetails
        /// </summary>
        /// <param name="SyncData"></param>
        /// <returns></returns>


        public HQAResponseClass InsertHQADetails(string SyncData)
        {
            //public string InsertHQADetails(string SyncData)
            Log.Writelog(SyncData, "HQA");
            string strSave = string.Empty;
            HQAResponseClass objResponse = new HQAResponseClass();
            HQAResponseMessage objHQAResponseMsg = new HQAResponseMessage();
            string WONUMBER = string.Empty;


            BLInventory objBLInventory = new BLInventory();
            clsHQACompartment objComp = new clsHQACompartment();
            List<clsEAScores> lstEAScores = new List<clsEAScores>();
            List<clsHQAScores> lstHQAScores = new List<clsHQAScores>();
            List<clsHQATreeDetails> lstHQATree = new List<clsHQATreeDetails>();
            List<clsRWAPlotSData> lstRWAPlotData = new List<clsRWAPlotSData>();
            List<clsRWATreeDetails> lstRWATree = new List<clsRWATreeDetails>();
            List<clsScoreImages> lstScoreImage = new List<clsScoreImages>();
            var varHQADet = Json.Decode(SyncData);
            //TokenID


            string deviceID = string.Empty;
            string tokenId = string.Empty;
            deviceID = varHQADet.Compartment.DeviceID;
            tokenId = varHQADet.Compartment.TokenID;
            clsAuthTokenValidation objAuth = new clsAuthTokenValidation();
            objAuth = ValidateAuthToken(deviceID, tokenId);


            //Log.Writelog("Device ID-- " + deviceID.ToString(), "HQA");

            Log.Writelog(deviceID.ToString(), "InsertHQADetails", "HQA");
            if (objAuth.IsValidToken == true)
            {
                if (varHQADet != null)
                {
                    try
                    {
                        //objComp.CompSlno = varHQADet.Compartment.CompSlno;
                        objComp.WONUMBER = varHQADet.Compartment.WO_NUMBER;
                        objComp.FeatID = varHQADet.Compartment.FeatID;
                        objComp.HarvestingAskep = varHQADet.Compartment.HarvestingAskep;
                        objComp.PlanningAsst = varHQADet.Compartment.PlanningAsst;
                        objComp.VegetationType = varHQADet.Compartment.VegetationType;
                        objComp.Status = varHQADet.Compartment.Status;
                        objComp.TotalRWAPlots = varHQADet.Compartment.TotalRWAPlots;
                        objComp.TotalMerchantableWood = varHQADet.Compartment.TotalMerchantableWood;
                        objComp.HarvestingSystem = varHQADet.Compartment.HarvestingSystem;
                        objComp.TotalWasteWood = varHQADet.Compartment.TotalWasteWood;
                        objComp.AvgWood = varHQADet.Compartment.AvgWood;
                        objComp.TotalHQAPlots = varHQADet.Compartment.TotalHQAPlots;
                        objComp.AvgHQAScore = varHQADet.Compartment.AvgHQAScore;
                        objComp.Assessor = varHQADet.Compartment.Assessor;
                        objComp.CRTUSERID = varHQADet.Compartment.CRTUSERID;
                        objComp.CRTDATE = varHQADet.Compartment.CRTDATE;
                        objComp.MODUSERID = varHQADet.Compartment.MODUSERID;

                        //Added Smrithy QADATE-05-11-2015
                        objComp.QADATE = varHQADet.Compartment.QADATE;

                        //Inserting QA_Register Table--Smrithy Added -03-11-2015
                        // string strSaveHQARWAQADet = objBLInventory.InsertHQARWAQARegisterDetails(objComp);

                        if (varHQADet.Compartment.EAScores != null)
                        {
                            int eaScoreCount = varHQADet.Compartment.EAScores.Length;
                            if (eaScoreCount > 0)
                            {
                                for (int i = 0; i < eaScoreCount; i++)
                                {
                                    clsEAScores objEAScores = new clsEAScores();
                                    objEAScores.Parameter = varHQADet.Compartment.EAScores[i].Parameter;
                                    objEAScores.Score = varHQADet.Compartment.EAScores[i].Score;
                                    objEAScores.OilContaminationGPSLat = (varHQADet.Compartment.EAScores[i] != null) ? ToLongString(varHQADet.Compartment.EAScores[i].OilContaminationGPSLat) : varHQADet.Compartment.EAScores[i].OilContaminationGPSLat;
                                    objEAScores.OilContaminationGPSLong = varHQADet.Compartment.EAScores[i].OilContaminationGPSLong;
                                    objEAScores.Notes = varHQADet.Compartment.EAScores[i].Notes;
                                    objEAScores.Status = varHQADet.Compartment.EAScores[i].Status;
                                    lstEAScores.Add(objEAScores);
                                }

                            }
                        }
                        if (varHQADet.Compartment.HQASCORES != null)
                        {
                            int hqaScoreCount = varHQADet.Compartment.HQASCORES.Length;
                            if (hqaScoreCount > 0)
                            {
                                for (int i = 0; i < hqaScoreCount; i++)
                                {
                                    clsHQAScores objEAScores = new clsHQAScores();
                                    objEAScores.Parameter = varHQADet.Compartment.HQASCORES[i].Parameter;
                                    objEAScores.Score = varHQADet.Compartment.HQASCORES[i].Score;
                                    objEAScores.Type = varHQADet.Compartment.HQASCORES[i].Type;
                                    lstHQAScores.Add(objEAScores);
                                }

                            }
                        }
                        if (varHQADet.Compartment.HQAPlotData != null)
                        {
                            for (int hqaPlot = 0; hqaPlot < varHQADet.Compartment.HQAPlotData.Length; hqaPlot++)
                            {
                                int hqlPlotCount = varHQADet.Compartment.HQAPlotData[hqaPlot].TreeHQADetails.Length;
                                if (hqlPlotCount > 0)
                                {
                                    for (int i = 0; i < hqlPlotCount; i++)
                                    {
                                        clsHQATreeDetails objHQATreeDetails = new clsHQATreeDetails();
                                        //Smrithy Added -03-11-2015-HQASerialNo
                                        objHQATreeDetails.HQASerialNo = varHQADet.Compartment.HQAPlotData[hqaPlot].HQASerialNo;
                                        objHQATreeDetails.PlotNo = varHQADet.Compartment.HQAPlotData[hqaPlot].TreeHQADetails[i].PlotNo;
                                        objHQATreeDetails.CavityCount = varHQADet.Compartment.HQAPlotData[hqaPlot].TreeHQADetails[i].CavityCount;
                                        objHQATreeDetails.DebrisCount = varHQADet.Compartment.HQAPlotData[hqaPlot].TreeHQADetails[i].DebrisCount;
                                        //Added for Image Name & Desc
                                        objHQATreeDetails.ImageNameList = varHQADet.Compartment.HQAPlotData[hqaPlot].TreeHQADetails[i].ImageNameList;

                                        objHQATreeDetails.ImageDescription = varHQADet.Compartment.HQAPlotData[hqaPlot].TreeHQADetails[i].ImageDescription;

                                        lstHQATree.Add(objHQATreeDetails);
                                    }

                                }
                            }
                        }
                        //Added for Score Images
                        if (varHQADet.Compartment.ScoreImages != null)
                        {

                            int scoreImageCount = varHQADet.Compartment.ScoreImages.Length;
                            if (scoreImageCount > 0)
                            {
                                for (int i = 0; i < scoreImageCount; i++)
                                {
                                    clsScoreImages objScoreImage = new clsScoreImages();
                                    objScoreImage.Category = varHQADet.Compartment.ScoreImages[i].Category;
                                    objScoreImage.ImageName = varHQADet.Compartment.ScoreImages[i].ImageNameList;

                                    objScoreImage.ImageDescription = varHQADet.Compartment.ScoreImages[i].ImageDescription;
                                    objScoreImage.CRTUSERID = varHQADet.Compartment.ScoreImages[i].CRTUSERID;
                                    objScoreImage.CRTDATE = varHQADet.Compartment.ScoreImages[i].CRTDATE;
                                    objScoreImage.MODUSERID = varHQADet.Compartment.ScoreImages[i].MODUSERID;
                                    objScoreImage.MODDATE = varHQADet.Compartment.ScoreImages[i].MODDATE;
                                    lstScoreImage.Add(objScoreImage);
                                }

                            }

                        }
                        ////Score Images
                        int rwaPlotCount = varHQADet.Compartment.RWAPlotData.Length;
                        if (rwaPlotCount > 0)
                        {
                            for (int j = 0; j < rwaPlotCount; j++)
                            {

                                clsRWAPlotSData objRWAPlotData = new clsRWAPlotSData();
                                objRWAPlotData.PLOTNO = varHQADet.Compartment.RWAPlotData[j].PlotNo;
                                objRWAPlotData.REMARKS = varHQADet.Compartment.RWAPlotData[j].REMARKS;
                                objRWAPlotData.PlotGpsLat = (varHQADet.Compartment.RWAPlotData[j] != null) ? ToLongString(varHQADet.Compartment.RWAPlotData[j].PlotGpsLat) : varHQADet.Compartment.RWAPlotData[j].PlotGpsLat;
                                objRWAPlotData.PlotGpsLong = varHQADet.Compartment.RWAPlotData[j].PlotGpsLong;
                                objRWAPlotData.RecordedDate = varHQADet.Compartment.RWAPlotData[j].RecordedDate;
                                objRWAPlotData.CRTUSERID = varHQADet.Compartment.RWAPlotData[j].CRTUSERID;
                                objRWAPlotData.CRTDATE = varHQADet.Compartment.RWAPlotData[j].CRTDATE;
                                objRWAPlotData.MODUSERID = varHQADet.Compartment.RWAPlotData[j].MODUSERID;
                                objRWAPlotData.MODDATE = varHQADet.Compartment.RWAPlotData[j].MODDATE;
                                lstRWAPlotData.Add(objRWAPlotData);


                                //Need to add PLOTNO in clsRWATreeDetails 

                                if (varHQADet.Compartment.RWAPlotData[j].TreeRWADetails != null)
                                {
                                    int treeRWA = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails.Length;

                                    if (treeRWA > 0)
                                    {

                                        for (int k = 0; k < treeRWA; k++)
                                        {
                                            clsRWATreeDetails objRWATree = new clsRWATreeDetails();
                                            //uma Nov-26-2015
                                            //PlotNo is added to track the trees
                                            objRWATree.PlotNo = varHQADet.Compartment.RWAPlotData[j].PlotNo;
                                            objRWATree.TreeNo = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails[k].TreeNo;
                                            objRWATree.PropList = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails[k].PropList;
                                            objRWATree.Diameter = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails[k].Diameter;
                                            objRWATree.HeightLength = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails[k].HeightLength;
                                            objRWATree.ImageNameList = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails[k].ImageNameList;

                                            //Added for Image Desc
                                            objRWATree.ImageDescription = varHQADet.Compartment.RWAPlotData[j].TreeRWADetails[k].ImageDescription;
                                            lstRWATree.Add(objRWATree);
                                            objRWATree = null;
                                        }

                                    }
                                }



                            }


                        }

                        //Log.Writelog("In RGE service... calling objBLInventory.InsertPQADetails", "HQA");
                        //strSave = objBLInventory.InsertHQADetails(objComp, lstEAScores, lstHQAScores, lstHQATree, lstRWAPlotData, lstRWATree);
                        Log.Writelog(deviceID.ToString(), "Enter to objBLInventory.InsertHQADetails", "HQA");
                        objResponse = objBLInventory.InsertHQADetails(objComp, lstEAScores, lstHQAScores, lstHQATree, lstRWAPlotData, lstRWATree, lstScoreImage, deviceID);
                        Log.Writelog(deviceID.ToString(), "Out from objBLInventory.InsertHQADetails", "HQA");
                        //Log.Writelog(strSave, "HQA");
                        objComp = null;
                        lstEAScores = null;
                        lstHQAScores = null;
                        lstHQATree = null;
                        lstRWATree = null;
                        lstRWAPlotData = null;
                        lstScoreImage = null;

                    }

                    catch (Exception ex)
                    {
                        Log.WritePendinglog("<START>", "HQA");
                        Log.WritePendinglog(SyncData, "HQA");
                        Log.WritePendinglog("<END>", "HQA");
                        Log.Writelog(deviceID.ToString(), "InsertHQADetails - " + ex.Message, "HQA");
                        Log.Writelog(deviceID.ToString(), "InsertHQADetails - " + ex.InnerException.ToString(), "HQA");
                        //strSave = "The Transaction could not be completed";
                        objHQAResponseMsg.Status = "Error";
                        objHQAResponseMsg.WONUMBER = WONUMBER;
                        objHQAResponseMsg.ErrorMessage = "The Transaction could not be completed" + ex.InnerException.ToString();
                        objResponse.ResponseMessage = objHQAResponseMsg;
                        Log.Writelog(deviceID.ToString(), "InsertHQADetails - Response error message " + objResponse.ResponseMessage.ErrorMessage, "HQA");
                        Log.Writelog(deviceID.ToString(), "InsertHQADetails - Response status message " + objResponse.ResponseMessage.Status, "HQA");
                    }

                }
            }//End if TokenID
            else
            {
                // if token is invalid 
                Log.WritePendinglog("<START>", "HQA");
                Log.WritePendinglog(SyncData, "HQA");
                Log.WritePendinglog("<END>", "HQA");
                objHQAResponseMsg.WONUMBER = "";
                objHQAResponseMsg.ErrorMessage = objAuth.Message;
                objHQAResponseMsg.Status = "";
                objResponse.ResponseMessage = objHQAResponseMsg;
                Log.Writelog(deviceID.ToString(), "InsertHQADetails - isValidToken: False", "HQA");
            }

            // return strSave;

            //Added for Pending logs
            if (objResponse.ResponseMessage.Status.ToUpper() == "ERROR")
            {
                Log.WritePendinglog("<START>", "HQA");
                Log.WritePendinglog(SyncData, "HQA");
                Log.WritePendinglog("<END>", "HQA");

            }
            return objResponse;
        }
        #endregion InsertHQADetails

        //Smrithy Added-03-11-2015
        #region GetHQARWATeamDetails
        /// <summary>
        /// GetHQARWATeamDetails
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public clsMainHQARWATeam GetHQARWATeamDetails(string sector, string deviceID)
        {
            Log.Writelog(deviceID, "GetHQARWATeamDetails - Sector: " + sector, "HQA");
            clsMainHQARWATeam objMain = new clsMainHQARWATeam();
            List<clsHQARWATeam> lstHQARWATeam = new List<clsHQARWATeam>();
            BLInventory objBLInventory = new BLInventory();
            lstHQARWATeam = objBLInventory.GetHQARWATeamDetails(sector);
            objMain.HQARWATeamCodeList = lstHQARWATeam;
            Log.Writelog(deviceID, "GetHQARWATeamDetails - Total records: " + lstHQARWATeam.Count, "HQA");
            return objMain;
        }
        #endregion GetHQARWATeamDetails
        #endregion HQA

        #region Image Upload
        public string SaveImageUsingPost(string fileName, string base64String)
        {

            string str = string.Empty;
            if (!string.IsNullOrEmpty(base64String))
            {

                try
                {
                    // Log.Writelog("L1");
                    // Convert Base64 String to byte[]
                    byte[] imageBytes = Convert.FromBase64String(base64String);
                    // Log.Writelog("L2");
                    MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);
                    //Log.Writelog("L3");

                    // Convert byte[] to Image
                    ms.Write(imageBytes, 0, imageBytes.Length);
                    //Log.Writelog("L4");
                    System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
                    //Log.Writelog("L5");

                    string strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGETreeImagesPath"];
                    //Log.Writelog("The configuration path is " + strLogFile);
                    strLogFile = strLogFile + fileName;
                    //+ ".png";
                    //Log.Writelog("Full path with file " + strLogFile);
                    image.Save(strLogFile, System.Drawing.Imaging.ImageFormat.Jpeg);
                    //image.Save(System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "\\TreeImages\\" + fileName + ".png");
                    str = "saved image " + fileName;
                    //Log.Writelog("L6");
                    //str = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath + "attachments\\" + fileName;

                    //Log.Writelog("returned string is " + str);
                    //Log.Writelog(strLogFile);
                    //Log.Writelog("L7");
                }
                catch (Exception ex)
                {
                    // write("*****" + System.DateTime.Now.ToString() + "Error in SaveImageUsingPost method -" + ex.Message + ex.InnerException);
                    Log.Writelog(ex.Message);
                    Log.Writelog(ex.InnerException.ToString());
                    str = string.Empty;
                    str = "Error-" + ex.Message;
                }
            }


            return str;

        }


        public string SaveTreeImages(string fileName, string appType, string base64String)
        {
            string str = string.Empty;
            if (!string.IsNullOrEmpty(base64String))
            {
                try
                {
                    byte[] imageBytes = Convert.FromBase64String(base64String);
                    MemoryStream ms = new MemoryStream(imageBytes, 0, imageBytes.Length);

                    ms.Write(imageBytes, 0, imageBytes.Length);
                    System.Drawing.Image image = System.Drawing.Image.FromStream(ms, true);
                    string strLogFile = string.Empty;


                    if (appType.Trim().ToUpper() == "INV")
                    {
                        strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGETreeInventoryPath"];
                    }
                    if (appType.Trim().ToUpper() == "HQA")
                    {
                        strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGETreeHQAPath"];
                    }
                    if (appType.Trim().ToUpper() == "PQA")
                    {
                        strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGETreeImagesPath"];
                    }
                    if (appType.Trim().ToUpper() == "UAVCLOSELOOP")
                    {
                        strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGETreeUAVCloseLoopPath"];
                    }

                    strLogFile = strLogFile + fileName;
                    image.Save(strLogFile, System.Drawing.Imaging.ImageFormat.Jpeg);

                    str = "saved image " + fileName;
                }
                catch (Exception ex)
                {
                    Log.Writelog(ex.Message);
                    Log.Writelog(ex.InnerException.ToString());
                    str = string.Empty;
                    str = "Error-" + ex.Message;
                }
            }

            return str;

        }
        #endregion Image Upload

        #region GetAuthTokenID
        /// <summary>
        /// GetAuthTokenID
        /// </summary>
        /// <param name="deviceID"></param>
        /// <returns></returns>
        public clsAuthToken GetAuthTokenID(string deviceID)
        {
            Log.Writelog("In GetAuthTokenID - rgeservice " + deviceID, "");
            clsResponseAuthToken objResponse = new clsResponseAuthToken();
            clsResponseAuthTokenMessage objResponseMsg = new clsResponseAuthTokenMessage();
            clsAuthToken objAuth = new clsAuthToken();
            clsAuthTokenDet objAuthData = new clsAuthTokenDet();
            BLInventory objBLInventory = new BLInventory();
            objResponse = objBLInventory.GetAuthTokenID(deviceID);

            //objAuth.AuthToken = objAuthData;
            //  return objResponse;

            //return objResponse.ResponseMessage.TokenID;
            //clsAuthToken objAuth = new clsAuthToken();

            objAuth.AuthToken.TokenID = objResponse.ResponseMessage.TokenID.ToString();
            objAuth.AuthToken.DEVICEFOUND = objResponse.ResponseMessage.ErrorMessage;

            return objAuth;
        }


        //public bool ValidateAuthToken(string deviceID, string tokenID)
        //{


        //    string strValidateAuthToken = System.Configuration.ConfigurationManager.AppSettings["ValidateAuthToken"];
        //    bool isValidToken = false;

        //    if (strValidateAuthToken == "1")
        //    {
        //        BLInventory objBLInventory = new BLInventory();

        //        isValidToken = objBLInventory.ValidateAuthToken(deviceID, tokenID);
        //        Log.Writelog("in the validateauthtoken..." + deviceID.ToString() + " " + tokenID.ToString(), "");
        //        Log.Writelog("isValidToken is " + isValidToken.ToString());
        //    }
        //    else
        //    {
        //        Log.Writelog("in the validateauthtoken...the flag is false in web.config" + deviceID.ToString() + " " + tokenID.ToString(), "");
        //        isValidToken = true;
        //    }
        //    return isValidToken;

        //}


        public clsAuthTokenValidation ValidateAuthToken(string deviceID, string tokenID)
        {


            string strValidateAuthToken = System.Configuration.ConfigurationManager.AppSettings["ValidateAuthToken"];

            // if ValidateTokenExpiry is 1 , then you validate whether token is expired or not
            // if ValidateTokenExpiry is 0 , then dont check for expiry
            clsAuthTokenValidation obj = new clsAuthTokenValidation();
            int isExpiry = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["ValidateAuthToken"]);

            if (strValidateAuthToken == "1")
            {
                BLInventory objBLInventory = new BLInventory();

                obj = objBLInventory.ValidateAuthToken(deviceID, tokenID, isExpiry);
                Log.Writelog("in the validateauthtoken..." + deviceID.ToString() + " " + tokenID.ToString(), "");
                Log.Writelog("isValidToken is " + obj.IsValidToken.ToString() + " Message is " + obj.Message.ToString());
            }
            else
            {
                obj.IsValidToken = true;
                obj.DeviceFound = "1";
                obj.Message = "Success";
                obj.IsTokenExists = "1";
                Log.Writelog("in the validateauthtoken...the flag is false in web.config" + deviceID.ToString() + " " + tokenID.ToString() + "isValidToken is " + obj.IsValidToken.ToString() + " Message is " + obj.Message.ToString(), "");

            }
            return obj;

        }


        #endregion GetAuthTokenID

        //Added on 07/02/2018 By Soumitri for SEED LOT DATA
        #region GetSeedLotData
        /// <summary>
        /// GetSectorData
        /// </summary>
        /// <returns></returns>
        public clsMainSeedLot GetSeedLotData()
        {
            clsMainSeedLot obMain = new clsMainSeedLot();
            List<clsSeedLot> lstInvTeam = new List<clsSeedLot>();
            BLInventory objBLInventory = new BLInventory();
            lstInvTeam = objBLInventory.GetSeedLotData();
            obMain.SectorList = lstInvTeam;
            return obMain;
        }
        #endregion GetSeedLotData

        #region Login
        public clsValidateUserID ValidateUserID(string userId)
        {
            Log.Writelog("in the ValidateUserID..." + userId.ToString(), "");
            clsValidateUserID obj = new clsValidateUserID();
            BLInventory objBLInventory = new BLInventory();
            obj = objBLInventory.ValidateUserID(userId);
            Log.Writelog("IsValidUser is " + obj.IsValidUser.ToString(), "");
            return obj;
        }

        public clsUserDetail Login(string UserID, string Password, string AppName)
        {
            BLInventory objBLInventory = new BLInventory();
            var obj = objBLInventory.Login(UserID, Password, AppName);
            return obj;
        }
        #endregion

        public string ConnectDatabase()
        {
            return "Success";
        }

        private static string ToLongString(string input)
        {
            string str = input.ToUpper();

            // if string representation was collapsed from scientific notation, just return it:
            if (!str.Contains("E") || str == "") return str;

            bool negativeNumber = false;

            if (str[0] == '-')
            {
                str = str.Remove(0, 1);
                negativeNumber = true;
            }

            string sep = Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
            char decSeparator = sep.ToCharArray()[0];

            string[] exponentParts = str.Split('E');
            string[] decimalParts = exponentParts[0].Split(decSeparator);

            // fix missing decimal point:
            if (decimalParts.Length == 1) decimalParts = new string[] { exponentParts[0], "0" };

            int exponentValue = int.Parse(exponentParts[1]);

            string newNumber = decimalParts[0] + decimalParts[1];

            string result;

            if (exponentValue > 0)
            {
                result =
                    newNumber +
                    GetZeros(exponentValue - decimalParts[1].Length);
            }
            else // negative exponent
            {
                result =
                    "0" +
                    decSeparator +
                    GetZeros(exponentValue + decimalParts[0].Length) +
                    newNumber;

                result = result.TrimEnd('0');
            }

            if (negativeNumber)
                result = "-" + result;

            return result;
        }

        private static string GetZeros(int zeroCount)
        {
            if (zeroCount < 0)
                zeroCount = Math.Abs(zeroCount);

            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < zeroCount; i++) sb.Append("0");

            return sb.ToString();
        }
        #endregion Methods




    }


}
