﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using RGEBal;
namespace RGEFiberOneService
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Write("ASP.net V 4.5");

        }

        public async void writelog(String strMessage)
        {
            string strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGELogFilePath"];
            using (StreamWriter sw = new StreamWriter(strLogFile, true))
            {
                // sw.WriteLine(Convert.ToString(System.DateTime.Now) + "    " + strMessage);
                await sw.WriteAsync(Convert.ToString(System.DateTime.Now) + "    " + strMessage);
                sw.Close();
                sw.Dispose();
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            writelog("testing the print from asp.net application");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string str = "started";
            BLInventory objBLInventory = new BLInventory();
            //str = objBLInventory.TestDBConnection();
            Response.Write(str);
        }
    }
}