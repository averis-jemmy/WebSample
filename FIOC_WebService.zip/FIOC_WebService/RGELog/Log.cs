﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RGELog
{
    public static class Log
    {
        #region Writelog
        public static async void WriteSynclog(String strSyncMessage, string strAppType, string deviceID)
        {
            try
            {
                string strLogFolder = System.Configuration.ConfigurationManager.AppSettings["RGELogFilePath"];
                string filepath = string.Empty;

                if (!Directory.Exists(strLogFolder))
                {
                    Directory.CreateDirectory(strLogFolder);
                }
                strLogFolder += strAppType + "\\";
                if (!Directory.Exists(strLogFolder))
                {
                    Directory.CreateDirectory(strLogFolder);
                }
                strLogFolder += DateTime.Now.Year.ToString() + "\\";
                if (!Directory.Exists(strLogFolder))
                {
                    Directory.CreateDirectory(strLogFolder);
                }
                strLogFolder += DateTime.Now.Month.ToString() + "\\";
                if (!Directory.Exists(strLogFolder))
                {
                    Directory.CreateDirectory(strLogFolder);
                }
                strLogFolder += DateTime.Now.Day.ToString() + "\\";
                if (!Directory.Exists(strLogFolder))
                {
                    Directory.CreateDirectory(strLogFolder);
                }

                if(!string.IsNullOrEmpty(deviceID))
                    filepath = strLogFolder + DateTime.Now.ToString("HHmmss") + "-" + deviceID + ".log";
                else
                    filepath = strLogFolder + DateTime.Now.ToString("HHmmss") + ".log";

                if (File.Exists(filepath))
                {
                    using (StreamWriter sw = new StreamWriter(filepath))
                    {
                        await sw.WriteAsync(strSyncMessage);
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    StreamWriter sw = File.CreateText(filepath);
                    await sw.WriteAsync(strSyncMessage);
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch { }
        }

        public static async void Writelog(String strMessage)
        {
            try
            {
                string strLogFolder = System.Configuration.ConfigurationManager.AppSettings["RGELogFilePath"];
                string strLogFile = System.Configuration.ConfigurationManager.AppSettings["RgeLogFileName"];
                var filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                if (File.Exists(filepath))
                {
                    using (StreamWriter sw = new StreamWriter(filepath, true))
                    {
                        await sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + "    " + strMessage);
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    StreamWriter sw = File.CreateText(filepath);
                    await sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + "    " + strMessage);
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch { }
        }

        public static async void Writelog(String deviceID, String strMessage, string strApplication)
        {
            try
            {
                string strLogFile = String.Empty;
                string filepath = String.Empty;
                string strLogFolder = System.Configuration.ConfigurationManager.AppSettings["RGELogFilePath"];
                if (strApplication.Trim() == "INVENTORY")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEINVLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "WOODSUPPLY")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEWOODLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "PQA")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEPQALogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "HQA")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEHQALogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "UAV")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEUAVLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RgeLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }

                if (File.Exists(filepath))
                {
                    using (StreamWriter sw = new StreamWriter(filepath, true))
                    {
                        await sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + "|" + deviceID + "|RGEService.svc.cs|" + strMessage);
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    StreamWriter sw = File.CreateText(filepath);
                    await sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + "|" + deviceID + "|RGEService.svc.cs|" + strMessage);
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch { }
        }

        public static async void Writelog(String strMessage, string strApplication)
        {
            try
            {
                string strLogFile = String.Empty;
                string filepath = String.Empty;
                string strLogFolder = System.Configuration.ConfigurationManager.AppSettings["RGELogFilePath"];
                if (strApplication.Trim() == "INVENTORY")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEINVLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "WOODSUPPLY")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEWOODLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "PQA")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEPQALogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "HQA")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEHQALogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "UAV")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEUAVLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RgeLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }

                if (File.Exists(filepath))
                {
                    using (StreamWriter sw = new StreamWriter(filepath, true))
                    {
                        await sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + " |RGEService.svc.cs|" + strMessage);
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    StreamWriter sw = File.CreateText(filepath);
                    await sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + " |RGEService.svc.cs|" + strMessage);
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch { }
        }


        public static async void WritePendinglog(String strMessage, string strApplication)
        {
            try
            {
                string strLogFile = String.Empty;
                string filepath = String.Empty;
                string strLogFolder = System.Configuration.ConfigurationManager.AppSettings["RGEPendingFilePath"];
                if (strApplication.Trim() == "INVENTORY")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEINVPendingFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "WOODSUPPLY")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEWOODPendingFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }

                else if (strApplication.Trim() == "PQA")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEPQAPendingFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else if (strApplication.Trim() == "HQA")
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RGEHQAPendingFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }
                else
                {
                    strLogFile = System.Configuration.ConfigurationManager.AppSettings["RgePendingLogFileName"];
                    filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";
                }


                if (File.Exists(filepath))
                {
                    using (StreamWriter sw = new StreamWriter(filepath, true))
                    {
                        await sw.WriteAsync(Environment.NewLine + strMessage);
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    StreamWriter sw = File.CreateText(filepath);
                    await sw.WriteAsync(Environment.NewLine + strMessage);
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch { }
        }
        #endregion Writelog
    }
}
