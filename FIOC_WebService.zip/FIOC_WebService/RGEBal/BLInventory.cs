﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RGEDal;
using RGEDomain;

namespace RGEBal
{
    public class BLInventory
    {


        #region Methods

        #region Inventory
        #region FetchCompartmentData        #region FetchCompartmentData
        /// <summary>
        /// Fetching the compartment data with hardcoded parameters (for testing purpose)
        /// </summary>
        /// <returns></returns>
        public List<ClsCompartment> FetchCompartmentData()
        {
            List<ClsCompartment> lstCompartment = new List<ClsCompartment>();
            DLInventory objDLInventory = new DLInventory();
            lstCompartment = objDLInventory.FetchCompartmentData();
            return lstCompartment;
        }
        #endregion FetchCompartmentData

        #region FetchCompDataByInvType
        /// <summary>
        /// Fetching the compartment data by passing the inventoryType,sector and inventoryDate
        /// </summary>
        /// <param name="inventoryType"></param>
        /// <param name="sector"></param>
        /// <param name="inventoryDate"></param>
        /// <returns></returns>
        public List<ClsCompartment> FetchCompDataByInvType(string inventoryType, string sector, DateTime inventoryDate)
        {
            List<ClsCompartment> lstCompartment = new List<ClsCompartment>();
            DLInventory objDLInventory = new DLInventory();
            lstCompartment = objDLInventory.FetchCompDataByInvType(inventoryType, sector, inventoryDate);
            return lstCompartment;
        }
        #endregion FetchCompDataByInvType

        #region FetchTreeMapData
        /// <summary>
        /// Fetching the tree map data by passing the compartmentNo, featID
        /// </summary>
        /// <param name="compartmentNo"></param>
        /// <param name="featID"></param>
        /// <returns></returns>
        public List<TreeMapHeader> FetchTreeMapData(string featID)
        {
            List<TreeMapHeader> lstTreeMap = new List<TreeMapHeader>();
            DLInventory objDLInventory = new DLInventory();
            lstTreeMap = objDLInventory.FetchTreeMapData(featID);
            return lstTreeMap;
        }
        #endregion FetchTreeMapData

        #region InsertOrUpdateInventoryTreeMap
        /// <summary>
        /// Insert / Update the tree map data by passing the TreeMapHeaderList, compartmentNo, featID
        /// </summary>
        /// <param name="TreeMapHeaderList"></param>
        /// <param name="compartmentNo"></param>
        /// <param name="featID"></param>
        public InventoryResponseClass InsertOrUpdateInventoryTreeMap(List<TreeMapHeader> headers, string compartmentNo, string featID)
        {            
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertOrUpdateInventoryTreeMap(headers, compartmentNo, featID);            
        }
        #endregion InsertOrUpdateInventoryTreeMap

        //Smrithy Added
        #region GetInventoryReferenceData
        /// <summary>
        /// GetInventoryReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsInvTeam> GetInventoryReferenceData(string sector)
        {
            List<clsInvTeam> lstInvTeamDetails = new List<clsInvTeam>();
            DLInventory objDLInventory = new DLInventory();
            lstInvTeamDetails = objDLInventory.GetInventoryReferenceData(sector);
            return lstInvTeamDetails;
        }
        #endregion GetInventoryReferenceData

        #region GetSectorData
        /// <summary>
        /// GetInventoryReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsSector> GetSectorData()
        {
            List<clsSector> listOfSector = new List<clsSector>();
            DLInventory objDLInventory = new DLInventory();
            listOfSector = objDLInventory.GetSectorData();
            return listOfSector;
        }
        #endregion GetInventoryReferenceData

        #region GetUserSectorData
        /// <summary>
        /// GetInventoryReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsUserSector> GetUserSectorList(string AppName)
        {
            List<clsUserSector> listOfSector = new List<clsUserSector>();
            DLInventory objDLInventory = new DLInventory();
            listOfSector = objDLInventory.GetUserSectorList(AppName);
            return listOfSector;
        }
        #endregion GetInventoryReferenceData

        #region GetDamageType
        public List<clsDamageType> GetDamageType()
        {
            List<clsDamageType> listOfDamageType = new List<clsDamageType>();
            DLInventory objDLInventory = new DLInventory();
            listOfDamageType = objDLInventory.GetDamageType();
            return listOfDamageType;
        }
        #endregion GetInventoryReferenceData

        #region InsertInventoryDetails
        /// <summary>
        /// InsertInventoryDetails
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstPlotSurvey"></param>
        /// <param name="strSave"></param>
        /// <returns></returns>
        /// 
        public int InsertInventoryCompartment(clsComparmentDet objCompartment)
        {
            int compSlno = 0;
            try
            {
                DLInventory objDLInventory = new DLInventory();
                compSlno = objDLInventory.InsertInventoryCompartment(objCompartment);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return compSlno;
        }

        //validate the inventory survey
        public bool ValidateDuplicateSurvey(string featID , string validateCompno, string validateInvType)
        {
            // Uma - Jan - 06 -2015
            // The feat id is passed in argument 
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.ValidateDuplicateSurvey(featID,validateCompno, validateInvType);
        }

        public InventoryResponseClass SyncCompartment(CompartmentDetail objCompartment)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.SyncCompartment(objCompartment);
        }

        public InventoryResponseClass InsertInventoryDetails(clsComparmentDet objCompartment)
        {
            string strSave = string.Empty;
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertInventoryDetails(objCompartment);
        }

        public InventoryResponseClass InsertInventoryPlots(List<clsPlotSurveyDet> lstPlotSurvey, List<clsPlotSpacing> lstPlotSpacing,
   List<clsTreeSurvey> lstTreeSurvey, List<clsTreeImage> lstTreeImages, List<clsPlotCenterDistance> lstPlotDistance, List<clsWeedCoverage> lstWeedCoverage, string compSlNo, List<clsLAI> lstLai)
        {
            string strSave = string.Empty;
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertInventoryPlots(lstPlotSurvey, lstPlotSpacing, lstTreeSurvey, lstTreeImages, lstPlotDistance, lstWeedCoverage, compSlNo, lstLai);
        }
        #endregion InsertInventoryDetails

        //Added on 28/05/2018 By Soumitri for DBH Master Types for MIN & MAX Values
        #region GetDBHType
        public List<clsDBHType> GetDBHType()
        {
            List<clsDBHType> listOfDBHType = new List<clsDBHType>();
            DLInventory objDLInventory = new DLInventory();
            listOfDBHType = objDLInventory.GetDBHType();
            return listOfDBHType;
        }
        #endregion GetDBHType

        #region GetInventoryTypes
        public List<clsInventoryType> GetInventoryTypes()
        {
            List<clsInventoryType> lstInvTypes = new List<clsInventoryType>();
            DLInventory objDLInventory = new DLInventory();
            lstInvTypes = objDLInventory.GetInventoryTypes();
            return lstInvTypes;
        }
        #endregion GetInventoryTypes

        #endregion Inventory

        #region Wood Supply
        #region GetTripTicketDetailsBySector
        /// <summary>
        /// Fetching the trip truck details by passing the sector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsTripTicket> GetTripTicketDetailsBySector(string sector)
        {
            List<clsTripTicket> lstTripTicket = new List<clsTripTicket>();
            DLInventory objDLInventory = new DLInventory();
            lstTripTicket = objDLInventory.GetTripTicketDetailsBySector(sector);
            return lstTripTicket;
        }
        #endregion GetTripTicketDetailsBySector

        #region GetRktLicenses
        public List<clsRktLicense> GetRktLicensesBySector(string sector)
        {            
            List<clsRktLicense> lstRktLicense = new List<clsRktLicense>();
            DLInventory objDLInventory = new DLInventory();
            lstRktLicense = objDLInventory.GetRktLicensesBySector(sector);
            return lstRktLicense;
        }
        #endregion GetRktLicenses

        #region GetRoadConditions
        public List<clsRoad> GetRoadConditions()
        {
            List<clsRoad> lstRoadConditions = new List<clsRoad>();
            DLInventory objDLInventory = new DLInventory();
            lstRoadConditions = objDLInventory.GetRoadConditions();
            return lstRoadConditions;
        }
        #endregion GetRoadConditions

        #region GetWeather
        public List<clsWeather> GetWeatherConditions()
        {
            List<clsWeather> lstWeatherConditions = new List<clsWeather>();
            DLInventory objDLInventory = new DLInventory();
            lstWeatherConditions = objDLInventory.GetWeatherConditions();           
            return lstWeatherConditions;
        }
        #endregion GetWeather

        #region GetTripTicketWithoutLoadedTime
        public List<clsTripTicketNoLoadedTime> GetTripTicketWithoutLoadedTime(String sector)
        {
            List<clsTripTicketNoLoadedTime> lstTripTicketNoLoadedTime = new List<clsTripTicketNoLoadedTime>();
            DLInventory objDLInventory = new DLInventory();
            lstTripTicketNoLoadedTime = objDLInventory.GetTripTicketWithoutLoadedTime(sector);
            return lstTripTicketNoLoadedTime;            
        }
        #endregion GetTripTicketWithoutLoadedTime

        #region FetchStaticReferenceData
        #region FetchContactorsData
        /// <summary>
        /// Fetchig all the contractor data
        /// </summary>
        /// <returns></returns>
        public List<clsContactors> FetchContactorsData(string sector)
        {
            List<clsContactors> lstContData = new List<clsContactors>();
            DLInventory objDLInventory = new DLInventory();
            lstContData = objDLInventory.FetchContactorsData(sector);
            return lstContData;
        }
        #endregion FetchContactorsData

        #region FetchConversionsData
        /// <summary>
        ///  Fetchig all the Conversion data
        /// </summary>
        /// <returns></returns>
        public List<clsConversions> FetchConversionsData(string sector)
        {
            List<clsConversions> lstConverData = new List<clsConversions>();
            DLInventory objDLInventory = new DLInventory();
            lstConverData = objDLInventory.FetchConversionsData(sector);
            return lstConverData;
        }
        #endregion FetchConversionsData

        #region FetchVehicleSwData
        /// <summary>
        ///  Fetchig all the VehicleSVV data
        /// </summary>
        /// <returns></returns>
        public List<clsVehicleSw> FetchVehicleSwData(string sector)
        {
            List<clsVehicleSw> lstVehicle = new List<clsVehicleSw>();
            DLInventory objDLInventory = new DLInventory();
            lstVehicle = objDLInventory.FetchVehicleSwData(sector);
            return lstVehicle;
        }
        #endregion FetchVehicleSwData

        #region FetchBargeData
        /// <summary>
        ///  Fetchig all the Barge data
        /// </summary>
        /// <returns></returns>
        public List<clsBarge> FetchBargeData()
        {
            List<clsBarge> lstBarge = new List<clsBarge>();
            DLInventory objDLInventory = new DLInventory();
            lstBarge = objDLInventory.FetchBargeData();
            return lstBarge;
        }
        #endregion FetchBargeData

        #region FetchDepoData
        /// <summary>
        ///  Fetchig all the Depo data
        /// </summary>
        /// <returns></returns>
        public List<clsDepots> FetchDepoData()
        {
            List<clsDepots> lstDepo = new List<clsDepots>();
            DLInventory objDLInventory = new DLInventory();
            lstDepo = objDLInventory.FetchDepoData();
            return lstDepo;
        }
        #endregion FetchDepoData


        #endregion FetchStaticReferenceData

        #region GetWODetails

        #region GetWODetails
        /// <summary>
        /// Fetching the work order details
        /// </summary>
        /// <returns></returns>
        public List<clsWorkOrder> GetWODetails()
        {
            List<clsWorkOrder> lstWODetails = new List<clsWorkOrder>();
            DLInventory objDLInventory = new DLInventory();
            lstWODetails = objDLInventory.GetWODetails();
            return lstWODetails;
        }
        #endregion GetWODetails

        #region GetWODetailsBySector
        /// <summary>
        /// Getting the Work order details by passing sector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsWorkOrder> GetWODetailsBySector(string sector)
        {
            List<clsWorkOrder> lstWODetails = new List<clsWorkOrder>();
            DLInventory objDLInventory = new DLInventory();
            lstWODetails = objDLInventory.GetWODetailsBySector(sector);
            return lstWODetails;
        }
        #endregion GetWODetailsBySector
        #endregion GetWODetails


        #region GetLodingUnLoadingWO
        #region GetLoadingWO
        /// <summary>
        /// To fetch all the Loading WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsLoadingWO> GetLoadingWO(string woNumber)
        {
            List<clsLoadingWO> lstLoadingWO = new List<clsLoadingWO>();
            DLInventory objDLInventory = new DLInventory();
            lstLoadingWO = objDLInventory.GetLoadingWO(woNumber);
            return lstLoadingWO;
        }
        #endregion GetLoadingWO

        #region GetUnLoadingWO
        /// <summary>
        ///  To fetch all the Unloading WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsUnloadingWO> GetUnLoadingWO(string woNumber)
        {
            List<clsUnloadingWO> lstUnLoadingWO = new List<clsUnloadingWO>();
            DLInventory objDLInventory = new DLInventory();
            lstUnLoadingWO = objDLInventory.GetUnLoadingWO(woNumber);
            return lstUnLoadingWO;
        }
        #endregion GetUnLoadingWO
        #endregion GetLodingUnLoadingWO

        #region GetFellingExtractionWO
        #region GetFellingWO
        /// <summary>
        ///  To fetch all the felling WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsFellingData> GetFellingWO(string woNumber)
        {
            List<clsFellingData> lstFellingWO = new List<clsFellingData>();
            DLInventory objDLInventory = new DLInventory();
            lstFellingWO = objDLInventory.GetFellingWO(woNumber);
            return lstFellingWO;
        }
        #endregion GetFellingWO

        #region GetExtractionWO
        /// <summary>
        /// To fetch all the Extraction WO data from WO_register
        /// </summary>
        /// <param name="woNumber"></param>
        /// <returns></returns>
        public List<clsExtractingData> GetExtractionWO(string woNumber)
        {
            List<clsExtractingData> lstExtractionWO = new List<clsExtractingData>();
            DLInventory objDLInventory = new DLInventory();
            lstExtractionWO = objDLInventory.GetExtractionWO(woNumber);
            return lstExtractionWO;
        }
        #endregion GetExtractionWO
        #endregion GetFellingExtractionWO

        #region SetArrivedDatetime
        /// <summary>
        /// To update TW_TRIP_TICKET_DATA table with status and arrivedAtUKdatetime
        /// </summary>
        /// <param name="tripTicketNo"></param>
        /// <param name="status"></param>
        /// <param name="arrivedAtUKdatetime"></param>
        /// <returns></returns>
        //public string SetArrivedDatetime(int tripTicketNo, string status, string arrivedAtUKdatetime) //Todo: Guaz: to comment out once db is updated to varchar
        public string SetArrivedDatetime(string tripTicketNo, string status, string arrivedAtUKdatetime, string loadingPoint)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.SetArrivedDatetime(tripTicketNo, status, arrivedAtUKdatetime, loadingPoint);
        }
        #endregion SetArrivedDatetime

        #region SetLoadedArrivedDatetime
        /// <summary>
        /// To update TW_TRIP_TICKET_DATA table with status and arrivedAtUKdatetime
        /// </summary>
        /// <param name="tripTicketNo"></param>
        /// <param name="status"></param>
        /// <param name="loadedArrivedAtUKdatetime"></param>
        /// <returns></returns>
        //public string SetLoadedArrivedDatetime(int tripTicketNo, string status, string loadedArrivedAtUKdatetime) //Todo: Guaz: to comment out once db is updated to varchar
        public string SetLoadedArrivedDatetime(string tripTicketNo, string status, string loadedArrivedAtUKdatetime)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.SetLoadedArrivedDatetime(tripTicketNo, status, loadedArrivedAtUKdatetime);
        }
        #endregion SetLoadedArrivedDatetime


        #region InsertStackWODetails
        public ResponseClass InsertStackWODetails(List<clsPCSStack> lstSatck, string strSave)
        {
            //  public string InsertStackWODetails(List<clsPCSStack> lstSatck, string strSave)
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertStackWODetails(lstSatck, strSave);

        }
        #endregion InsertStackWODetails

        #region InsertTransWODetails
        public ResponseClass InsertTransWODetails(clsPCSTrans lstTrans)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertTransWODetails(lstTrans);

        }
        #endregion InsertTransWODetails

        public string SetLhpStock(string sector, string depot, string license, string block, string species, 
            int lhp, string createdDateTime, string user, string deviceId)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.SetLhpStock(sector, depot, license, block, species, 
            lhp, createdDateTime, user, deviceId);
        }

        public string SetEnviromentalValues(string sector, string depot, string weather, string road, int equipGood,
            int equipBad, string createdDateTime, string user, string deviceId)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.SetEnviromentalValues(sector, depot, weather, road, equipGood,
            equipBad, createdDateTime, user, deviceId);
        }

        #region GetArriveNotArrivedata
        /// <summary>
        /// Getting the Stock details
        /// </summary>
        public List<clsStockLoading> GetArriveNotArrivedata(string sector)
        {
            List<clsStockLoading> lstStockDetails = new List<clsStockLoading>();
            DLInventory objDLInventory = new DLInventory();
            lstStockDetails = objDLInventory.GetArriveNotArrivedata(sector);
            return lstStockDetails;
        }
        #endregion GetArriveNotArrivedata

        #region GetOneDayTripTicketData
        /// <summary>
        /// To fetch all the Loading WO data from WO_register
        /// </summary>
        /// <param name="Sector"></param>
        /// <returns></returns>
        public List<clsLoadingOneDayTripTicketData> GetOneDayTripTicketData(string Sector)
        {
            List<clsLoadingOneDayTripTicketData> lstLoadingData = new List<clsLoadingOneDayTripTicketData>();
            DLInventory objDLInventory = new DLInventory();
            lstLoadingData = objDLInventory.GetOneDayTripTicketData(Sector);
            return lstLoadingData;
        }
        #endregion GetOneDayTripTicketData

        #endregion Wood Supply

        #region PQA
        #region GetPQAWorkOrders
        /// <summary>
        /// GetPQAWorkOrders
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="dtReqStartDate"></param>
        /// <param name="dtReqEndDate"></param>
        /// <returns></returns>
        public List<clsPQAGetWorkOrders> GetPQAWorkOrders(string sector, DateTime dtReqStartDate, DateTime dtReqEndDate, string deviceID)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetPQAWorkOrders(sector, dtReqStartDate, dtReqEndDate, deviceID);


        }

        #endregion GetPQAWorkOrders

        #region SyncPQAData
        public PQAResponseClass SyncPQAData(PQADetail objCompartment)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.SyncPQAData(objCompartment);
        }
        #endregion

        #region InsertPQADetails
        public PQAResponseClass InsertPQADetails(clsPQACompartmentData objComp, clsQARegister objQARegdata, List<clsScores> lstScores, string deviceID)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertPQADetails(objComp, lstScores, objQARegdata, deviceID);
        }
        #endregion InsertPQADetails

        #region InsertPQAPlotDetails
        public PQAPlotResponseClass InsertPQAPlotDetails(List<clsPlotData> lstPlotData, List<clsPlotGPS> lstPlotGPS, List<clsPlotHoleSize> lstHoleSize, List<clsPlotSpace> lstPlotSpace, List<clsTreeQADetails> lstTreeQA, string compSlNo, string deviceID)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertPQAPlotDetails(lstPlotData, lstPlotGPS, lstHoleSize, lstPlotSpace, lstTreeQA, compSlNo, deviceID);
        }
        #endregion InsertPQAPlotDetails

        #region InsertPQAStocking
        public PQAResponseClass InsertPQAStocking(List<clsPQAStockingData> lstTreeStocking, string compSlNo)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertPQAStocking(lstTreeStocking, compSlNo);
        }
        #endregion InsertPQAStocking

        #region InsertPQAStockingSummary
        public PQAResponseClass InsertPQAStockingSummary(List<clsPQAStockingSummaryData> lstTreeStockingSummary, string compSlNo)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.InsertPQAStockingSummary(lstTreeStockingSummary, compSlNo);
        }
        #endregion InsertPQAStockingSummary

        //add sigit
        #region GetTimelinePQA
            public List<clsGetTimeline> GetTimelineData(string wo)
            {
                List<clsGetTimeline> lstTimelineDetails = new List<clsGetTimeline>();
                DLInventory objDLInventory = new DLInventory();
                lstTimelineDetails = objDLInventory.GetTimelineData(wo);
                return lstTimelineDetails;
            }
        #endregion GetTimelinePQA

        #region GetConfigurations
        public List<KeyValuePair<string, string>> GetConfigurations()
        {
            List<KeyValuePair<string, string>> configs = new List<KeyValuePair<string, string>>();
            DLInventory objDLInventory = new DLInventory();
            configs = objDLInventory.GetConfigurations();
            return configs;
        }
        #endregion GetConfigurations

        #endregion PQA

        #region UAV

        #region GetEstateForSector
        /// <summary>
        /// GetEstateForSector
        /// </summary>
        /// <param name="sector"></param>
        /// <returns></returns>
        public List<clsGetEstateForSector> GetEstateForSector(string sector)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetEstateForSector(sector);


        }

        #endregion GetEstateForSector

        #region GetCompartmentNoForEstate
        /// <summary>
        /// GetCompartmentNoForEstate
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="estate"></param>
        /// <returns></returns>
        public List<clsGetCompartNoforEstate> GetCompartmentNoForEstate(string sector, string estate)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetCompartmentNoForEstate(sector, estate);


        }

        #endregion GetCompartmentNoForEstate

        #region GetImagesForFilter
        #region GetImagesForFlightFilter
        /// <summary>
        /// GetImagesForFlightFilter
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public List<clsUAVFlight> GetImagesForFlightFilter(string featid, DateTime flightStartdate, DateTime flightEnddate)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetImagesForFlightFilter(featid, flightStartdate, flightEnddate);


        }

        #endregion GetImagesForFlightFilter

        #region GetUAVAlertData
        /// <summary>
        /// GetUAVAlertData
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public List<clsUAVAlert> GetUAVAlertData(string featid, DateTime flightStartdate, DateTime flightEnddate)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetUAVAlertData(featid, flightStartdate, flightEnddate);
        }
        #endregion GetUAVAlertData
        #endregion etImagesForFilter
        #region GetUAVDensityRefData
        /// <summary>
        /// GetUAVDensityRefData
        /// </summary>
        /// <param name="featid"></param>
        /// <returns></returns>
        public List<clsUAVDensityColorIndex> GetUAVDensityRefData(string featid, DateTime flightStartdate, DateTime flightEnddate)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetUAVDensityRefData(featid, flightStartdate, flightEnddate);


        }

        #endregion GetUAVDensityRefData

        #region GetUAVReferenceData
        /// <summary>
        /// GetUAVReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsUAVAlertColorIndex> GetUAVReferenceData()
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetUAVReferenceData();


        }


        #endregion GetUAVReferenceData

        public ResponseClass CloseAlert(clsCloseAlert dbDetails)
        {
            ResponseClass obj = new ResponseClass();
            DLInventory objDLInsertDBDetails = new DLInventory();
            obj = objDLInsertDBDetails.CloseAlert(dbDetails);
            return obj;
        }

        public List<clsUAVAlertOthers> GetUAVAlertOthersData(string featid)
        {
            DLInventory obj = new DLInventory();
            return obj.GetUAVAlertOthersData(featid);
        }
        #endregion UAV

        #region HQA
        #region GetHQAWorkOrders
        /// <summary>
        /// GetHQAWorkOrders
        /// </summary>
        /// <param name="sector"></param>
        /// <param name="dtReqStartDate"></param>
        /// <param name="dtReqEndDate"></param>
        /// <returns></returns>
        public List<clsHQAGetWorkOrders> GetHQAWorkOrders(string sector, DateTime dtReqStartDate, DateTime dtReqEndDate, string deviceID)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetHQAWorkOrders(sector, dtReqStartDate, dtReqEndDate, deviceID);


        }

        #endregion GetHQAWorkOrders

        //Smrithy Added
        #region GetPQATeamDetails
        /// <summary>
        /// GetHQATeamDetails
        /// </summary>
        /// <returns></returns>
        public List<clsQATeam> GetPQATeamDetails(string sector)
        {
            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetPQATeamDetails(sector);
        }
        #endregion GetPQATeamDetails

        #region InsertHQADetails
        /// <summary>
        /// InsertHQADetails
        /// </summary>
        /// <param name="objComp"></param>
        /// <param name="lstEAScores"></param>
        /// <param name="lstHQAScores"></param>
        /// <param name="lstHQATree"></param>
        /// <param name="lstRWAPlotData"></param>
        /// <param name="lstRWATree"></param>
        /// <returns></returns>
        public HQAResponseClass InsertHQADetails(clsHQACompartment objComp, List<clsEAScores> lstEAScores, List<clsHQAScores> lstHQAScores,
                                        List<clsHQATreeDetails> lstHQATree, List<clsRWAPlotSData> lstRWAPlotData, List<clsRWATreeDetails> lstRWATree, List<clsScoreImages> lstScoreImage, string deviceID)
        {
            //public string InsertHQADetails(clsHQACompartment objComp, List<clsEAScores> lstEAScores, List<clsHQAScores> lstHQAScores,
            //                            List<clsHQATreeDetails> lstHQATree, List<clsRWAPlotSData> lstRWAPlotData, List<clsRWATreeDetails> lstRWATree)
            string strSave = string.Empty;

            DLInventory objDLInventory = new DLInventory();
            //strSave = objDLInventory.InsertHQADetails(objComp, lstEAScores, lstHQAScores, lstHQATree, lstRWAPlotData, lstRWATree);
            return objDLInventory.InsertHQADetails(objComp, lstEAScores, lstHQAScores, lstHQATree, lstRWAPlotData, lstRWATree, lstScoreImage, deviceID);

            // return strSave;
        }
        #endregion InsertHQADetails

        //Smrithy Added-03-11-2015
        #region InsertHQARWAQARegisterDetails
        /// <summary>
        /// InsertHQARWAQARegisterDetails
        /// </summary>
        /// <param name="objComp"></param>
        /// <returns></returns>
        public string InsertHQARWAQARegisterDetails(clsHQACompartment objComp)
        {
            string strSave = string.Empty;
            try
            {
                DLInventory objDLInventory = new DLInventory();
                strSave = objDLInventory.InsertHQARWAQARegisterDetails(objComp);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return strSave;
        }
        #endregion InsertHQARWAQARegisterDetails

        //Smrithy Added-03-11-2015
        #region GetHQARWATeamDetails
        /// <summary>
        /// GetHQARWATeamDetails
        /// </summary>
        /// <returns></returns>
        public List<clsHQARWATeam> GetHQARWATeamDetails(string sector)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetHQARWATeamDetails(sector);


        }
        #endregion GetHQARWATeamDetails
        #endregion HQA

        //Added on 07/02/2018 By Soumitri for SEED LOT DATA
        #region GetSeedLotData
        /// <summary>
        /// GetInventoryReferenceData
        /// </summary>
        /// <returns></returns>
        public List<clsSeedLot> GetSeedLotData()
        {
            List<clsSeedLot> listOfSeedLot = new List<clsSeedLot>();
            DLInventory objDLInventory = new DLInventory();
            listOfSeedLot = objDLInventory.GetSeedLotData();
            return listOfSeedLot;
        }
        #endregion GetSeedLotData

        #region GetAuthTokenID
        /// <summary>
        /// GetAuthTokenID
        /// </summary>
        /// <param name="deviceID"></param>
        /// <returns></returns>

        public clsResponseAuthToken GetAuthTokenID(string deviceID)
        {

            DLInventory objDLInventory = new DLInventory();
            return objDLInventory.GetAuthTokenID(deviceID);

        }

        public clsAuthTokenValidation ValidateAuthToken(string deviceID, string tokenID, int isExpiry)
        {
            clsAuthTokenValidation obj = new clsAuthTokenValidation();           
            DLInventory objDLInventory = new DLInventory();
            obj = objDLInventory.ValidateAuthToken(deviceID, tokenID, isExpiry);
            return obj;
        }
        #endregion GetAuthTokenID

        #region Login
        public clsValidateUserID ValidateUserID(string userId)
        {
            clsValidateUserID obj = new clsValidateUserID();
            DLInventory objDLInventory = new DLInventory();
            obj = objDLInventory.ValidateUserID(userId);
            return obj;
        }

        public clsUserDetail Login(string UserID, string Password, string AppName)
        {
            DLInventory objDLInventory = new DLInventory();
            var obj = objDLInventory.Login(UserID, Password, AppName);
            return obj;
        }
        #endregion

        #endregion Methods

    }
}
